package buildup.analytics;

import android.app.Application;
import android.util.Log;
import java.util.Map;

public class LogAnalyticsReporter implements AnalyticsReporter {
    private static final String TAG;

    static {
        TAG = LogAnalyticsReporter.class.getSimpleName();
    }

    public void init(Application app) {
    }

    public void sendView(String screenName) {
        Log.i(TAG, String.format("page_view:%s", new Object[]{screenName}));
    }

    public void sendEvent(Map<String, String> paramMaps) {
        Log.i(TAG, String.format("Event with params: %s", new Object[]{paramMaps}));
    }

    public void sendHandledException(String tag, String message, Throwable exception) {
        Log.e(tag, message, exception);
    }
}
