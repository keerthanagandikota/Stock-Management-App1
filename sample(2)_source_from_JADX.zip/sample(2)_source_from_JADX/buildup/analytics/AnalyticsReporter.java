package buildup.analytics;

import android.app.Application;
import java.util.Map;

public interface AnalyticsReporter {
    public static final AnalyticsReporter NO_OP;

    /* renamed from: buildup.analytics.AnalyticsReporter.1 */
    static class C03211 implements AnalyticsReporter {
        C03211() {
        }

        public void init(Application app) {
        }

        public void sendView(String screenName) {
        }

        public void sendEvent(Map<String, String> map) {
        }

        public void sendHandledException(String tag, String message, Throwable exception) {
        }
    }

    void init(Application application);

    void sendEvent(Map<String, String> map);

    void sendHandledException(String str, String str2, Throwable th);

    void sendView(String str);

    static {
        NO_OP = new C03211();
    }
}
