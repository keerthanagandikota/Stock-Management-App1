package buildup.analytics;

public class NetworkResponse {
    private final String body;
    private final String statusCode;
    private final String url;

    public static class Builder {
        private String body;
        private String statusCode;
        private String url;

        public static Builder networkResponse() {
            return new Builder();
        }

        public Builder withUrl(String url) {
            this.url = url;
            return this;
        }

        public Builder withStatusCode(String statusCode) {
            this.statusCode = statusCode;
            return this;
        }

        public Builder withBody(String body) {
            this.body = body;
            return this;
        }

        public NetworkResponse build() {
            return new NetworkResponse();
        }
    }

    public String getUrl() {
        return this.url;
    }

    public String getStatusCode() {
        return this.statusCode;
    }

    public String getBody() {
        return this.body;
    }

    private NetworkResponse(Builder builder) {
        this.url = builder.url;
        this.statusCode = builder.statusCode;
        this.body = builder.body;
    }
}
