package buildup.analytics;

public final class BuildConfig {
    public static final String APPLICATION_ID = "buildup.analytics";
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "1.0";
}
