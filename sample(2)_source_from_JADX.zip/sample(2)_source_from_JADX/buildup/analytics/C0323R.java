package buildup.analytics;

/* renamed from: buildup.analytics.R */
public final class C0323R {

    /* renamed from: buildup.analytics.R.attr */
    public static final class attr {
    }

    /* renamed from: buildup.analytics.R.color */
    public static final class color {
    }

    /* renamed from: buildup.analytics.R.drawable */
    public static final class drawable {
    }

    /* renamed from: buildup.analytics.R.id */
    public static final class id {
        public static final int none = 2131623959;
    }

    /* renamed from: buildup.analytics.R.integer */
    public static final class integer {
    }

    /* renamed from: buildup.analytics.R.raw */
    public static final class raw {
    }

    /* renamed from: buildup.analytics.R.string */
    public static final class string {
    }

    /* renamed from: buildup.analytics.R.styleable */
    public static final class styleable {
    }
}
