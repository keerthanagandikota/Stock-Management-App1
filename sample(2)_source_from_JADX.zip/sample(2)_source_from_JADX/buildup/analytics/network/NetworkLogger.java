package buildup.analytics.network;

import buildup.analytics.NetworkResponse;

public interface NetworkLogger {
    void logRequest(String str, String str2);

    void logResponse(NetworkResponse networkResponse);
}
