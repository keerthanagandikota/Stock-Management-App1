package buildup.analytics.network;

import android.util.Log;
import buildup.analytics.NetworkResponse;
import java.util.HashMap;
import java.util.Map;

public class LogNetworkLogger implements NetworkLogger {
    private static final String NETWORK_REQUEST = "network_request";
    private static final String NETWORK_RESPONSE = "network_response";

    public void logRequest(String url, String httpMethod) {
        Map<String, String> paramsMap = new HashMap(2);
        paramsMap.put(NETWORK_REQUEST, url);
        paramsMap.put("http_method", httpMethod);
        Log.i(NETWORK_REQUEST, String.format("Request with params: %s", new Object[]{paramsMap}));
    }

    public void logResponse(NetworkResponse networkResponse) {
        Map<String, String> paramsMap = new HashMap(3);
        paramsMap.put(NETWORK_RESPONSE, networkResponse.getUrl());
        paramsMap.put("response_code", networkResponse.getStatusCode());
        paramsMap.put("response_body", networkResponse.getBody());
        Log.i(NETWORK_RESPONSE, String.format("Response with params: %s", new Object[]{paramsMap}));
    }
}
