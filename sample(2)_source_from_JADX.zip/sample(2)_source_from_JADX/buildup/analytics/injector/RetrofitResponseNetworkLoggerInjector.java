package buildup.analytics.injector;

import buildup.analytics.network.RetrofitResponseNetworkLogger;

public class RetrofitResponseNetworkLoggerInjector {
    public static RetrofitResponseNetworkLogger retrofitNetworkLogger() {
        return new RetrofitResponseNetworkLogger(NetworkLoggerInjector.networkLogger());
    }
}
