package buildup.analytics.injector;

import android.content.Context;
import buildup.analytics.AnalyticsReporter;
import buildup.analytics.LogAnalyticsReporter;

public class AnalyticsReporterInjector {
    private static final AnalyticsReporter LOG_ANALYTICS_REPORTER;

    static {
        LOG_ANALYTICS_REPORTER = new LogAnalyticsReporter();
    }

    public static AnalyticsReporter analyticsReporter() {
        return LOG_ANALYTICS_REPORTER;
    }

    public static AnalyticsReporter analyticsReporter(Context context) {
        return LOG_ANALYTICS_REPORTER;
    }
}
