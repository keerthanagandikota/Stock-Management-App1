package buildup;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import buildup.actions.Action;

public class MenuItem implements Parcelable {
    public static final Creator CREATOR;
    Action action;
    Class fragmentClass;
    int iconResource;
    String iconUrl;
    String label;

    /* renamed from: buildup.MenuItem.1 */
    static class C03161 implements Creator {
        C03161() {
        }

        public Object createFromParcel(Parcel parcel) {
            return new MenuItem().setLabel(parcel.readString()).setIcon(parcel.readInt()).setIconUrl(parcel.readString());
        }

        public Object[] newArray(int size) {
            return new MenuItem[size];
        }
    }

    public String getLabel() {
        return this.label;
    }

    public MenuItem setLabel(String label) {
        this.label = label;
        return this;
    }

    public int getIcon() {
        return this.iconResource;
    }

    public MenuItem setIcon(int imgRes) {
        this.iconResource = imgRes;
        return this;
    }

    public String getIconUrl() {
        return this.iconUrl;
    }

    public MenuItem setIconUrl(String iconUrl) {
        this.iconUrl = iconUrl;
        return this;
    }

    public Action getAction() {
        return this.action;
    }

    public MenuItem setAction(Action action) {
        this.action = action;
        return this;
    }

    public Class getFragmentClass() {
        return this.fragmentClass;
    }

    public MenuItem setFragmentClass(Class fragmentClass) {
        this.fragmentClass = fragmentClass;
        return this;
    }

    public String toString() {
        return this.label;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int flags) {
        parcel.writeString(this.label);
        parcel.writeInt(this.iconResource);
        parcel.writeString(this.iconUrl);
    }

    static {
        CREATOR = new C03161();
    }
}
