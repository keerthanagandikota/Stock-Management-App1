package buildup.validation;

import android.support.design.widget.TextInputLayout;
import android.view.View;

public abstract class TextValidator<T> implements Validator<T> {
    private final int mErrorMsgId;
    private final int mLayoutResId;
    private final View mView;

    public TextValidator(View rootView, int layoutResId, int errorMsgId) {
        this.mView = rootView;
        this.mLayoutResId = layoutResId;
        this.mErrorMsgId = errorMsgId;
    }

    public void setError(boolean show) {
        TextInputLayout layout = (TextInputLayout) this.mView.findViewById(this.mLayoutResId);
        if (show) {
            layout.setError(this.mView.getContext().getString(this.mErrorMsgId));
        } else {
            layout.setError(null);
        }
    }
}
