package buildup.validation;

import android.view.View;
import buildup.views.DateTimePicker;

public abstract class DateTimePickerValidator<T> implements Validator<T> {
    private final int mErrorMsgId;
    private final int mPickerId;
    private final View mView;

    public DateTimePickerValidator(View rootView, int pickerId, int errorMsgId) {
        this.mView = rootView;
        this.mPickerId = pickerId;
        this.mErrorMsgId = errorMsgId;
    }

    public void setError(boolean show) {
        DateTimePicker picker = (DateTimePicker) this.mView.findViewById(this.mPickerId);
        if (show) {
            picker.setError(this.mErrorMsgId);
        } else {
            picker.setError(null);
        }
    }
}
