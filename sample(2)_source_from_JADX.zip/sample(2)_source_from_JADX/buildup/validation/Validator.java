package buildup.validation;

public interface Validator<T> {
    void setError(boolean z);

    boolean validate(T t);
}
