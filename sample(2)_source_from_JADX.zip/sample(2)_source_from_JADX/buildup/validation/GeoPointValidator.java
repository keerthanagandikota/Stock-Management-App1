package buildup.validation;

import android.view.View;
import buildup.views.GeoPicker;

public abstract class GeoPointValidator<T> implements Validator<T> {
    private final int mMsgId;
    private final int mPickerId;
    private final View mView;

    public GeoPointValidator(View rootView, int viewId, int errorMsgId) {
        this.mView = rootView;
        this.mPickerId = viewId;
        this.mMsgId = errorMsgId;
    }

    public void setError(boolean show) {
        GeoPicker picker = (GeoPicker) this.mView.findViewById(this.mPickerId);
        if (show) {
            picker.setError(this.mMsgId);
        } else {
            picker.setError(null);
        }
    }
}
