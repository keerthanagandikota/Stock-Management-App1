package buildup.validation;

import android.view.View;
import buildup.views.ImagePicker;

public abstract class ImagePickerValidator<T> implements Validator<T> {
    private final int mErrorMsgId;
    private final int mPickerId;
    private final View mView;

    public ImagePickerValidator(View rootView, int pickerId, int errorMsgId) {
        this.mView = rootView;
        this.mPickerId = pickerId;
        this.mErrorMsgId = errorMsgId;
    }

    public void setError(boolean show) {
        ImagePicker picker = (ImagePicker) this.mView.findViewById(this.mPickerId);
        if (show) {
            picker.setError(this.mErrorMsgId);
        } else {
            picker.setError(null);
        }
    }
}
