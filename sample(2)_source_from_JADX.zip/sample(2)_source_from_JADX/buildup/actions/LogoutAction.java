package buildup.actions;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.util.LoginUtils;
import buildup.util.SecurePreferences;

public class LogoutAction implements Action {
    private Activity activity;
    private Class loginActivity;
    private SecurePreferences mSharedPreferences;

    public LogoutAction(SecurePreferences mSharedPreferences, Class loginActivity, Activity activity) {
        this.mSharedPreferences = mSharedPreferences;
        this.loginActivity = loginActivity;
        this.activity = activity;
    }

    public void execute(@NonNull Context context) {
        LoginUtils.logOut(this.mSharedPreferences, this.loginActivity, this.activity);
    }

    public boolean canDoExecute() {
        return true;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Log out").withTarget("Log out").build();
    }
}
