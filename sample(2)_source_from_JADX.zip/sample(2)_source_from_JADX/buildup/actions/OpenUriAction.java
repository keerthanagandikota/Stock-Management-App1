package buildup.actions;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.core.C0338R;
import io.buildup.pkg20170504080645.BuildConfig;

public class OpenUriAction implements Action {
    private final IntentLauncher intentLauncher;
    private Uri uri;

    public OpenUriAction(IntentLauncher intentLauncher, @NonNull String uri) {
        this.intentLauncher = intentLauncher;
        if (uri != null && !uri.equals(BuildConfig.FLAVOR)) {
            Uri parsedUri = Uri.parse(uri);
            if (parsedUri.getScheme() == null) {
                parsedUri = Uri.parse("http://" + uri);
            }
            this.uri = parsedUri;
        }
    }

    public void execute(@NonNull Context context) {
        this.intentLauncher.start(context, Intent.createChooser(new Intent("android.intent.action.VIEW", this.uri), context.getString(C0338R.string.open_url)));
    }

    public boolean canDoExecute() {
        return this.uri != null;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Open link").withTarget(this.uri.toString()).build();
    }
}
