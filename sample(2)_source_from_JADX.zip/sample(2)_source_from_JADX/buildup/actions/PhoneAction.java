package buildup.actions;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.core.C0338R;
import io.buildup.pkg20170504080645.BuildConfig;

public class PhoneAction implements Action {
    private final IntentLauncher intentLauncher;
    private String phoneNumber;

    public PhoneAction(IntentLauncher intentLauncher, String phoneNumber) {
        this.intentLauncher = intentLauncher;
        if (phoneNumber != null && !phoneNumber.equals(BuildConfig.FLAVOR)) {
            this.phoneNumber = phoneNumber;
        }
    }

    public void execute(@NonNull Context context) {
        this.intentLauncher.start(context, Intent.createChooser(new Intent("android.intent.action.DIAL", Uri.parse("tel:" + this.phoneNumber)), context.getString(C0338R.string.call)));
    }

    public boolean canDoExecute() {
        return this.phoneNumber != null;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Call to phone").withTarget(this.phoneNumber).build();
    }
}
