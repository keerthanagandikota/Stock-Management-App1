package buildup.actions;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;

public class NavigateToAction implements Action {
    private Parcelable item;
    private String parameterName;
    private Class target;

    public NavigateToAction(String parameterName, Class target, Parcelable item) {
        this.parameterName = parameterName;
        this.target = target;
        this.item = item;
    }

    public void execute(@NonNull Context context) {
        Intent intent = new Intent(context, this.target);
        if (this.item != null) {
            Bundle args = new Bundle();
            args.putParcelable(this.parameterName, this.item);
            intent.putExtras(args);
            context.startActivity(intent);
            return;
        }
        throw new IllegalStateException("You must set the parcelable item first");
    }

    public boolean canDoExecute() {
        return (this.parameterName == null || this.target == null || this.item == null) ? false : true;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Navigate to").withTarget(this.target.getName()).build();
    }
}
