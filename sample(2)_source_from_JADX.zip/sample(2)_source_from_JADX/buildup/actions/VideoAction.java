package buildup.actions;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.core.C0338R;
import io.buildup.pkg20170504080645.BuildConfig;

public class VideoAction implements Action {
    private final IntentLauncher intentLauncher;
    private String link;

    public VideoAction(IntentLauncher intentLauncher, String link) {
        if (!(link == null || link.equals(BuildConfig.FLAVOR))) {
            this.link = link;
        }
        this.intentLauncher = intentLauncher;
    }

    public void execute(@NonNull Context context) {
        this.intentLauncher.start(context, Intent.createChooser(new Intent("android.intent.action.VIEW", Uri.parse(this.link)), context.getString(C0338R.string.play_video)));
    }

    public boolean canDoExecute() {
        return this.link != null;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Play video").withTarget(this.link).build();
    }
}
