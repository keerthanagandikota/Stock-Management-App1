package buildup.actions;

import android.content.Context;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;

public interface Action {
    boolean canDoExecute();

    void execute(@NonNull Context context);

    @NonNull
    AnalyticsInfo getAnalyticsInfo();
}
