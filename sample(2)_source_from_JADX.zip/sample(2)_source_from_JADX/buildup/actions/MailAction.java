package buildup.actions;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.core.C0338R;
import io.buildup.pkg20170504080645.BuildConfig;

public class MailAction implements Action {
    private final IntentLauncher intentLauncher;
    private String mail;

    public MailAction(IntentLauncher intentLauncher, String mail) {
        this.intentLauncher = intentLauncher;
        if (mail != null && !mail.equals(BuildConfig.FLAVOR)) {
            if (mail.startsWith("mailto:")) {
                this.mail = mail;
            } else {
                this.mail = "mailto:" + mail;
            }
        }
    }

    public void execute(@NonNull Context context) {
        this.intentLauncher.start(context, Intent.createChooser(new Intent("android.intent.action.SENDTO", Uri.parse(this.mail)), context.getString(C0338R.string.send_email)));
    }

    public boolean canDoExecute() {
        return this.mail != null;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Send email").withTarget(this.mail).build();
    }
}
