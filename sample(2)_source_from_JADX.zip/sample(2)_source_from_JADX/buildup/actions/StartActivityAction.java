package buildup.actions;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;

public class StartActivityAction implements Action {
    private final Bundle bundle;
    private final Class clazz;
    private final int requestCode;

    public StartActivityAction(Class clazz) {
        this(clazz, 0);
    }

    public StartActivityAction(Class clazz, int requestCode) {
        this(clazz, null, requestCode);
    }

    public StartActivityAction(Class clazz, Bundle bundle) {
        this(clazz, bundle, 0);
    }

    public StartActivityAction(Class clazz, Bundle bundle, int requestCode) {
        this.clazz = clazz;
        this.bundle = bundle;
        this.requestCode = requestCode;
    }

    public void execute(@NonNull Context context) {
        Intent intent = new Intent(context, this.clazz);
        if (this.bundle != null) {
            intent.putExtras(this.bundle);
        }
        if (this.requestCode != 0) {
            ((Activity) context).startActivityForResult(intent, this.requestCode);
        } else {
            context.startActivity(intent);
        }
    }

    public boolean canDoExecute() {
        return true;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Start activity").withTarget(this.clazz.getSimpleName()).build();
    }
}
