package buildup.actions;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import buildup.analytics.model.AnalyticsInfo;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.core.C0338R;
import io.buildup.pkg20170504080645.BuildConfig;

public class MapsAction implements Action {
    private static final String MAPS_URL = "http://maps.google.com/maps?q=";
    private final IntentLauncher intentLauncher;
    private String uri;

    public MapsAction(IntentLauncher intentLauncher, String uri) {
        this.intentLauncher = intentLauncher;
        if (uri != null && !uri.equals(BuildConfig.FLAVOR)) {
            this.uri = MAPS_URL + uri;
        }
    }

    public void execute(@NonNull Context context) {
        this.intentLauncher.start(context, Intent.createChooser(new Intent("android.intent.action.VIEW", Uri.parse(this.uri)), context.getString(C0338R.string.find_on_map)));
    }

    public boolean canDoExecute() {
        return this.uri != null;
    }

    @NonNull
    public AnalyticsInfo getAnalyticsInfo() {
        return Builder.analyticsInfo().withAction("Find on map").withTarget(this.uri).build();
    }
}
