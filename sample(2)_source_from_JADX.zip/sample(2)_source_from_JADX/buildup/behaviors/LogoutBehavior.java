package buildup.behaviors;

import android.app.Activity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import buildup.actions.LogoutAction;
import buildup.core.C0338R;
import buildup.util.SecurePreferences;

public class LogoutBehavior extends NoOpBehavior {
    private Activity activity;
    private Class loginActivity;
    private SecurePreferences mSharedPreferences;

    /* renamed from: buildup.behaviors.LogoutBehavior.1 */
    class C03321 implements OnMenuItemClickListener {
        C03321() {
        }

        public boolean onMenuItemClick(MenuItem item) {
            new LogoutAction(LogoutBehavior.this.mSharedPreferences, LogoutBehavior.this.loginActivity, LogoutBehavior.this.activity).execute(LogoutBehavior.this.activity);
            return true;
        }
    }

    public LogoutBehavior(SecurePreferences mSharedPreferences, Class loginActivity, Activity activity) {
        this.mSharedPreferences = mSharedPreferences;
        this.loginActivity = loginActivity;
        this.activity = activity;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menu.add(C0338R.string.log_out).setOnMenuItemClickListener(new C03321());
    }
}
