package buildup.behaviors;

import android.view.MenuItem;
import buildup.analytics.AnalyticsReporter;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.injectors.ApplicationInjector;
import buildup.ui.Refreshable;

public class AnalyticsRefreshBehavior extends RefreshBehavior {
    private final AnalyticsReporter analyticsReporter;
    private final String datasource;

    public AnalyticsRefreshBehavior(Refreshable fragment, String datasource) {
        super(fragment);
        this.datasource = datasource;
        this.analyticsReporter = AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext());
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        boolean handled = super.onOptionsItemSelected(item);
        if (handled) {
            this.analyticsReporter.sendEvent(Builder.analyticsInfo().withAction("refresh").withDataSource(this.datasource).build().toMap());
        }
        return handled;
    }
}
