package buildup.behaviors;

import android.database.DataSetObserver;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import buildup.core.C0338R;
import buildup.ui.ListGridFragment;
import java.lang.ref.WeakReference;

public class SwipeRefreshBehavior extends NoOpBehavior implements OnRefreshListener {
    private SwipeRefreshLayout mSwipeRefreshLayout;
    private final WeakReference<ListGridFragment> mWeakFragment;

    /* renamed from: buildup.behaviors.SwipeRefreshBehavior.1 */
    class C03371 extends DataSetObserver {
        C03371() {
        }

        public void onChanged() {
            super.onChanged();
            SwipeRefreshBehavior.this.mSwipeRefreshLayout.setRefreshing(false);
        }
    }

    public SwipeRefreshBehavior(ListGridFragment<?> fragment) {
        this.mWeakFragment = new WeakReference(fragment);
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ListGridFragment fr = (ListGridFragment) this.mWeakFragment.get();
        if (fr != null) {
            this.mSwipeRefreshLayout = new SwipeRefreshLayout(fr.getActivity());
            this.mSwipeRefreshLayout.setOnRefreshListener(this);
            AbsListView listView = (AbsListView) view.findViewById(16908298);
            ViewGroup parent = (ViewGroup) listView.getParent();
            parent.removeView(listView);
            parent.addView(this.mSwipeRefreshLayout, 0);
            this.mSwipeRefreshLayout.addView(listView);
            this.mSwipeRefreshLayout.setColorSchemeResources(C0338R.color.material_deep_teal_500, C0338R.color.material_deep_teal_200, C0338R.color.material_blue_grey_800);
        }
    }

    public void onRefresh() {
        ListGridFragment fr = (ListGridFragment) this.mWeakFragment.get();
        if (fr != null) {
            fr.getAdapter().registerDataSetObserver(new C03371());
            fr.refresh();
        }
    }
}
