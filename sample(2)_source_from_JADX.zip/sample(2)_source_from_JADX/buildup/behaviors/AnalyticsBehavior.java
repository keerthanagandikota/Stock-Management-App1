package buildup.behaviors;

import buildup.analytics.AnalyticsReporter;
import buildup.analytics.model.AnalyticsInfo;

public class AnalyticsBehavior extends NoOpBehavior {
    private final AnalyticsReporter analyticsReporter;
    private final String pageName;

    public AnalyticsBehavior(AnalyticsReporter analyticsReporter, String pageName) {
        this.analyticsReporter = analyticsReporter;
        this.pageName = pageName;
    }

    public void onStart() {
        this.analyticsReporter.sendView(this.pageName);
    }

    public void onActionClick(AnalyticsInfo action) {
        this.analyticsReporter.sendEvent(action.toMap());
    }
}
