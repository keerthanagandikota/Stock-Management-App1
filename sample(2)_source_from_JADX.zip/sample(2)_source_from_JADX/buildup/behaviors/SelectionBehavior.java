package buildup.behaviors;

import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AbsListView.MultiChoiceModeListener;
import buildup.core.C0338R;
import buildup.ui.ListGridFragment;
import buildup.util.ColorUtils;
import java.util.ArrayList;
import java.util.List;

public class SelectionBehavior<T> extends NoOpBehavior {
    private final ListGridFragment fragment;
    private Callback<T> mCallback;
    private int mIconRes;
    private final int mTitleRes;
    private AbsListView mView;

    /* renamed from: buildup.behaviors.SelectionBehavior.1 */
    class C03351 implements MultiChoiceModeListener {
        C03351() {
        }

        public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
        }

        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuItem item = menu.add(SelectionBehavior.this.mTitleRes);
            if (SelectionBehavior.this.mIconRes != 0) {
                item.setIcon(SelectionBehavior.this.mIconRes);
                ColorUtils.tintIcon(item, C0338R.color.textBarColor, SelectionBehavior.this.fragment.getActivity());
            }
            return true;
        }

        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            if (SelectionBehavior.this.mCallback == null) {
                return false;
            }
            SelectionBehavior.this.mCallback.onSelected(getCheckedItems());
            mode.finish();
            return true;
        }

        public void onDestroyActionMode(ActionMode mode) {
        }

        private ArrayList<T> getCheckedItems() {
            SparseBooleanArray checked = SelectionBehavior.this.mView.getCheckedItemPositions();
            ArrayList<T> res = new ArrayList(checked.size());
            for (int i = 0; i < checked.size(); i++) {
                if (checked.get(checked.keyAt(i))) {
                    res.add(SelectionBehavior.this.fragment.getAdapter().getItem(checked.keyAt(i)));
                }
            }
            return res;
        }
    }

    public interface Callback<T> {
        void onSelected(List<T> list);
    }

    public SelectionBehavior(ListGridFragment<T> fr, int titleRes) {
        this.fragment = fr;
        this.mTitleRes = titleRes;
    }

    public SelectionBehavior(ListGridFragment<T> fr, int titleRes, int iconRes) {
        this.fragment = fr;
        this.mTitleRes = titleRes;
        this.mIconRes = iconRes;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        View lv = view.findViewById(16908298);
        if (lv instanceof AbsListView) {
            this.mView = (AbsListView) lv;
            this.mView.setChoiceMode(3);
            this.mView.setMultiChoiceModeListener(new C03351());
        }
    }

    public void setCallback(Callback<T> callback) {
        this.mCallback = callback;
    }
}
