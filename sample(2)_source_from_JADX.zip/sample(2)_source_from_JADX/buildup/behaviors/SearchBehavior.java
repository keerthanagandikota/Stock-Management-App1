package buildup.behaviors;

import android.support.v4.content.ContextCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.view.MenuItemCompat.OnActionExpandListener;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.support.v7.widget.SearchView.SearchAutoComplete;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import buildup.core.C0338R;
import buildup.injectors.ApplicationInjector;
import buildup.ui.Filterable;
import io.buildup.pkg20170504080645.BuildConfig;

public class SearchBehavior extends NoOpBehavior {
    Filterable mFilterable;
    SearchView searchView;

    /* renamed from: buildup.behaviors.SearchBehavior.1 */
    class C03331 implements OnQueryTextListener {
        C03331() {
        }

        public boolean onQueryTextSubmit(String s) {
            SearchBehavior.this.refreshSearch(s);
            return false;
        }

        public boolean onQueryTextChange(String s) {
            if (s.equals(BuildConfig.FLAVOR)) {
                SearchBehavior.this.refreshSearch(null);
            }
            return false;
        }
    }

    /* renamed from: buildup.behaviors.SearchBehavior.2 */
    class C03342 implements OnActionExpandListener {
        C03342() {
        }

        public boolean onMenuItemActionExpand(MenuItem menuItem) {
            return true;
        }

        public boolean onMenuItemActionCollapse(MenuItem menuItem) {
            SearchBehavior.this.refreshSearch(null);
            return true;
        }
    }

    public SearchBehavior(Filterable f) {
        this.mFilterable = f;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(C0338R.menu.search_menu, menu);
        MenuItem searchMenuItem = menu.findItem(C0338R.id.search);
        this.searchView = (SearchView) MenuItemCompat.getActionView(searchMenuItem);
        ((SearchAutoComplete) this.searchView.findViewById(C0338R.id.search_src_text)).setHintTextColor(ContextCompat.getColor(ApplicationInjector.getApplicationContext(), C0338R.color.hintSearchBarColor));
        if (this.searchView != null) {
            this.searchView.setOnQueryTextListener(new C03331());
            MenuItemCompat.setOnActionExpandListener(searchMenuItem, new C03342());
        }
    }

    public void refreshSearch(String newFilter) {
        this.mFilterable.onSearchTextChanged(newFilter);
    }
}
