package buildup.behaviors;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MenuItem.OnMenuItemClickListener;
import buildup.core.C0338R;
import buildup.util.ColorUtils;

public class ShareBehavior extends NoOpBehavior {
    Context mContext;
    private final ShareListener mListener;

    /* renamed from: buildup.behaviors.ShareBehavior.1 */
    class C03361 implements OnMenuItemClickListener {
        C03361() {
        }

        public boolean onMenuItemClick(MenuItem item) {
            ShareBehavior.this.mListener.onShare();
            return true;
        }
    }

    public interface ShareListener {
        void onShare();
    }

    public ShareBehavior(Context context, ShareListener listener) {
        this.mContext = context;
        this.mListener = listener;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        MenuItem item = menu.add(C0338R.string.share);
        item.setShowAsAction(2);
        item.setIcon(C0338R.drawable.abc_ic_menu_share_mtrl_alpha);
        ColorUtils.tintIcon(item, C0338R.color.textBarColor, this.mContext);
        item.setOnMenuItemClickListener(new C03361());
    }
}
