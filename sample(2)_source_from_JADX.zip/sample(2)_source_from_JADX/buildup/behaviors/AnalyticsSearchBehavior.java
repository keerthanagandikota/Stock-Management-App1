package buildup.behaviors;

import buildup.analytics.AnalyticsReporter;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.injectors.ApplicationInjector;
import buildup.ui.Filterable;

public class AnalyticsSearchBehavior extends SearchBehavior {
    private final AnalyticsReporter analyticsReporter;
    private final String datasource;

    public AnalyticsSearchBehavior(Filterable f, String datasource) {
        super(f);
        this.datasource = datasource;
        this.analyticsReporter = AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext());
    }

    public void refreshSearch(String newFilter) {
        super.refreshSearch(newFilter);
        this.analyticsReporter.sendEvent(Builder.analyticsInfo().withAction("search").withTarget(newFilter).withDataSource(this.datasource).build().toMap());
    }
}
