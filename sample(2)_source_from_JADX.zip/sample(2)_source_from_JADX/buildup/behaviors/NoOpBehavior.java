package buildup.behaviors;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import buildup.analytics.model.AnalyticsInfo;

public class NoOpBehavior implements Behavior {
    public void onStart() {
    }

    public void onResume() {
    }

    public void onPause() {
    }

    public void onStop() {
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        return false;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
    }

    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
        return false;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
    }

    public void onActionClick(AnalyticsInfo action) {
    }
}
