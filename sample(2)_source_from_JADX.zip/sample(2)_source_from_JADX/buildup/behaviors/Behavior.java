package buildup.behaviors;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import buildup.analytics.model.AnalyticsInfo;

public interface Behavior {
    void onActionClick(AnalyticsInfo analyticsInfo);

    void onActivityResult(int i, int i2, Intent intent);

    void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater);

    void onItemClick(AdapterView<?> adapterView, View view, int i, long j);

    boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long j);

    boolean onOptionsItemSelected(MenuItem menuItem);

    void onPause();

    void onResume();

    void onStart();

    void onStop();

    void onViewCreated(View view, Bundle bundle);
}
