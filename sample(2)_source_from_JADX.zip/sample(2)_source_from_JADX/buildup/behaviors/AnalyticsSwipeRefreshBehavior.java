package buildup.behaviors;

import buildup.analytics.AnalyticsReporter;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.analytics.model.AnalyticsInfo.Builder;
import buildup.injectors.ApplicationInjector;
import buildup.ui.ListGridFragment;

public class AnalyticsSwipeRefreshBehavior extends SwipeRefreshBehavior {
    private AnalyticsReporter analyticsReporter;

    public AnalyticsSwipeRefreshBehavior(ListGridFragment<?> fragment) {
        super(fragment);
        try {
            Class.forName("AnalyticsReporterInjector", false, ClassLoader.getSystemClassLoader());
            this.analyticsReporter = AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext());
        } catch (ClassNotFoundException e) {
            this.analyticsReporter = null;
        }
    }

    public void onRefresh() {
        super.onRefresh();
        if (this.analyticsReporter != null) {
            this.analyticsReporter.sendEvent(Builder.analyticsInfo().withAction("pullToRefresh").build().toMap());
        }
    }
}
