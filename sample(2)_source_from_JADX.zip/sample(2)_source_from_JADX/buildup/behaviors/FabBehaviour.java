package buildup.behaviors;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.NestedScrollView.OnScrollChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.OvershootInterpolator;
import buildup.core.C0338R;
import buildup.util.ColorUtils;

public class FabBehaviour extends NoOpBehavior implements OnClickListener {
    private boolean canBeAnimated;
    private int duration;
    private final boolean mAnimated;
    private FloatingActionButton mFab;
    private Fragment mFragment;
    private final OnClickListener mListener;
    private int mResource;

    /* renamed from: buildup.behaviors.FabBehaviour.1 */
    class C03251 implements OnScrollChangeListener {
        C03251() {
        }

        public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
            if (FabBehaviour.this.mFab == null) {
                return;
            }
            if (v.getChildAt(v.getChildCount() - 1).getBottom() - (v.getHeight() + v.getScrollY()) <= 0) {
                FabBehaviour.this.hideAccelerate();
            } else {
                FabBehaviour.this.showAccelerate();
            }
        }
    }

    /* renamed from: buildup.behaviors.FabBehaviour.2 */
    class C03262 extends AnimatorListenerAdapter {
        final /* synthetic */ View val$v;

        C03262(View view) {
            this.val$v = view;
        }

        public void onAnimationEnd(Animator animation) {
            FabBehaviour.this.mListener.onClick(this.val$v);
        }
    }

    /* renamed from: buildup.behaviors.FabBehaviour.3 */
    class C03273 extends AnimatorListenerAdapter {
        final /* synthetic */ AnimatorListener val$listener;

        C03273(AnimatorListener animatorListener) {
            this.val$listener = animatorListener;
        }

        public void onAnimationEnd(Animator animation) {
            FabBehaviour.this.mFab.setVisibility(8);
            this.val$listener.onAnimationEnd(animation);
        }
    }

    /* renamed from: buildup.behaviors.FabBehaviour.4 */
    class C03284 implements AnimatorListener {
        C03284() {
        }

        public void onAnimationStart(Animator animation) {
            FabBehaviour.this.canBeAnimated = false;
        }

        public void onAnimationEnd(Animator animation) {
            FabBehaviour.this.canBeAnimated = true;
        }

        public void onAnimationCancel(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }
    }

    /* renamed from: buildup.behaviors.FabBehaviour.5 */
    class C03295 implements AnimatorListener {
        C03295() {
        }

        public void onAnimationStart(Animator animation) {
        }

        public void onAnimationEnd(Animator animation) {
        }

        public void onAnimationCancel(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }
    }

    /* renamed from: buildup.behaviors.FabBehaviour.6 */
    class C03306 implements AnimatorListener {
        C03306() {
        }

        public void onAnimationStart(Animator animation) {
            FabBehaviour.this.canBeAnimated = false;
        }

        public void onAnimationEnd(Animator animation) {
            FabBehaviour.this.canBeAnimated = true;
        }

        public void onAnimationCancel(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }
    }

    /* renamed from: buildup.behaviors.FabBehaviour.7 */
    class C03317 implements AnimatorListener {
        C03317() {
        }

        public void onAnimationStart(Animator animation) {
        }

        public void onAnimationEnd(Animator animation) {
        }

        public void onAnimationCancel(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }
    }

    public FabBehaviour(Fragment fragment, int drawableResource, OnClickListener listener) {
        this(fragment, drawableResource, listener, false);
    }

    public FabBehaviour(Fragment fragment, int drawableResource, OnClickListener listener, boolean animated) {
        this.mFragment = fragment;
        this.mListener = listener;
        this.mResource = drawableResource;
        this.duration = fragment.getResources().getInteger(17694720);
        this.mAnimated = animated;
        this.canBeAnimated = true;
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setupFab(view);
    }

    private void setupFab(View view) {
        LayoutInflater.from(this.mFragment.getActivity()).inflate(C0338R.layout.fab, (ViewGroup) view);
        this.mFab = (FloatingActionButton) view.findViewById(C0338R.id.fab);
        this.mFab.setImageResource(this.mResource);
        if (this.mFab != null) {
            ColorUtils.tintIcon(this.mFab.getDrawable(), C0338R.color.textBarColor, this.mFragment.getActivity());
            this.mFab.setOnClickListener(this);
        }
        NestedScrollView nestedScrollView = (NestedScrollView) view.findViewById(C0338R.id.scrollView);
        if (nestedScrollView != null) {
            nestedScrollView.setOnScrollChangeListener(new C03251());
        }
    }

    public void onResume() {
        show(null);
    }

    public void onClick(View v) {
        hide(new C03262(v));
    }

    public void hide(AnimatorListener listener) {
        if (this.mAnimated) {
            this.mFab.animate().translationX(300.0f).setDuration((long) this.duration).setInterpolator(new AnticipateInterpolator()).setListener(new C03273(listener));
        } else {
            listener.onAnimationEnd(null);
        }
    }

    public void show(AnimatorListener listener) {
        if (this.mFab.getVisibility() != 8) {
            return;
        }
        if (this.mAnimated) {
            this.mFab.setVisibility(0);
            this.mFab.animate().translationX(0.0f).setDuration((long) this.duration).setInterpolator(new OvershootInterpolator()).setListener(listener).start();
            return;
        }
        this.mFab.setVisibility(0);
    }

    public void showAccelerate() {
        if (this.canBeAnimated) {
            this.mFab.animate().alpha(1.0f).translationY(0.0f).setDuration((long) this.duration).setInterpolator(new AccelerateInterpolator()).setListener(new C03284());
        }
    }

    public void hideAccelerate() {
        this.mFab.animate().cancel();
        this.mFab.animate().translationY(500.0f).setDuration((long) this.duration).setInterpolator(new AccelerateInterpolator()).setListener(new C03295());
    }

    public void showScale() {
        if (this.canBeAnimated) {
            this.mFab.animate().scaleX(1.0f).scaleY(1.0f).setDuration((long) this.duration).setInterpolator(new AccelerateInterpolator()).setListener(new C03306());
        }
    }

    public void hideScale() {
        this.mFab.animate().cancel();
        this.mFab.animate().setDuration((long) this.duration).scaleX(0.0f).scaleY(0.0f).setInterpolator(new AccelerateInterpolator()).setListener(new C03317());
    }
}
