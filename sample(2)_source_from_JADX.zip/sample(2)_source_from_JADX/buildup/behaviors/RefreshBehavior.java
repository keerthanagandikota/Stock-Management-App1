package buildup.behaviors;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import buildup.core.C0338R;
import buildup.ui.Refreshable;

public class RefreshBehavior extends NoOpBehavior {
    private Refreshable refreshable;

    public RefreshBehavior(Refreshable fragment) {
        this.refreshable = fragment;
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(C0338R.menu.refresh_menu, menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != C0338R.id.action_refresh) {
            return false;
        }
        this.refreshable.refresh();
        return true;
    }
}
