package buildup.navigation;

import buildup.adapters.TabItem;
import java.util.List;

public interface TabNavigation {
    List<TabItem> getTabItems();
}
