package buildup.navigation;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

public interface Navigation {
    SparseArray<Class<? extends Fragment>> getSectionFragmentClasses();
}
