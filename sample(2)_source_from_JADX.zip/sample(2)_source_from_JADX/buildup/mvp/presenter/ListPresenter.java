package buildup.mvp.presenter;

import buildup.core.C0338R;
import buildup.ds.CrudDatasource;
import buildup.ds.Datasource.Listener;
import buildup.mvp.view.CrudListView;
import java.util.List;

public class ListPresenter<T> extends BasePresenter implements ListCrudPresenter<T>, Listener<T> {
    private final CrudDatasource<T> crudDatasource;
    private final CrudListView<T> view;

    public ListPresenter(CrudDatasource<T> crudDatasource, CrudListView<T> view) {
        this.crudDatasource = crudDatasource;
        this.view = view;
    }

    public void deleteItem(T item) {
        this.crudDatasource.deleteItem(item, this);
    }

    public void deleteItems(List<T> items) {
        this.crudDatasource.deleteItems(items, this);
    }

    public void addForm() {
        this.view.showAdd();
    }

    public void editForm(T item, int position) {
        this.view.showEdit(item, position);
    }

    public void detail(T item, int position) {
        this.view.showDetail(item, position);
    }

    public void onSuccess(T t) {
        this.view.showMessage(C0338R.string.items_deleted);
        this.view.refresh();
    }

    public void onFailure(Exception e) {
        this.view.showMessage(C0338R.string.error_data_generic);
    }
}
