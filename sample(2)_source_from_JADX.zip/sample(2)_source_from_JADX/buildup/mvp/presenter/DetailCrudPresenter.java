package buildup.mvp.presenter;

public interface DetailCrudPresenter<T> extends Presenter {
    void deleteItem(T t);

    void editForm(T t);
}
