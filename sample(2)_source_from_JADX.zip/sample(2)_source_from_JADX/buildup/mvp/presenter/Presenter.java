package buildup.mvp.presenter;

public interface Presenter {
    void startPresenting();

    void stopPresenting();
}
