package buildup.mvp.presenter;

import java.util.List;

public interface ListCrudPresenter<T> extends Presenter {
    void addForm();

    void deleteItem(T t);

    void deleteItems(List<T> list);

    void detail(T t, int i);

    void editForm(T t, int i);
}
