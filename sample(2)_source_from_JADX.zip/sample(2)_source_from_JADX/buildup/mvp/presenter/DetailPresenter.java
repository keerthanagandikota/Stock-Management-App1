package buildup.mvp.presenter;

import buildup.core.C0338R;
import buildup.ds.CrudDatasource;
import buildup.ds.Datasource.Listener;
import buildup.mvp.view.DetailView;

public class DetailPresenter<T> extends BasePresenter implements DetailCrudPresenter<T>, Listener<T> {
    private final CrudDatasource<T> datasource;
    private final DetailView view;

    public DetailPresenter(CrudDatasource<T> datasource, DetailView view) {
        this.datasource = datasource;
        this.view = view;
    }

    public void deleteItem(T item) {
        this.datasource.deleteItem(item, this);
    }

    public void editForm(T t) {
        this.view.navigateToEditForm();
    }

    public void onSuccess(T t) {
        this.view.showMessage(C0338R.string.item_deleted, true);
        this.view.close(true);
    }

    public void onFailure(Exception e) {
        this.view.showMessage(C0338R.string.error_data_generic, true);
    }
}
