package buildup.mvp.presenter;

public abstract class BasePresenter implements Presenter {
    public void startPresenting() {
    }

    public void stopPresenting() {
    }
}
