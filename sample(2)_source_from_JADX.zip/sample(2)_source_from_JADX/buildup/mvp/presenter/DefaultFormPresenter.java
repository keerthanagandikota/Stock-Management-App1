package buildup.mvp.presenter;

import buildup.core.C0338R;
import buildup.ds.CrudDatasource;
import buildup.ds.Datasource.Listener;
import buildup.mvp.view.FormView;

public class DefaultFormPresenter<T> extends BaseFormPresenter<T> {
    private final CrudDatasource<T> datasource;

    private abstract class ShowingErrorOnFailureListener implements Listener<T> {
        private ShowingErrorOnFailureListener() {
        }

        public void onFailure(Exception e) {
            DefaultFormPresenter.this.view.showMessage(C0338R.string.error_data_generic, true);
        }
    }

    private class OnItemCreatedListener extends ShowingErrorOnFailureListener {
        private OnItemCreatedListener() {
            super(null);
        }

        public void onSuccess(T item) {
            DefaultFormPresenter.this.view.setItem(item);
            DefaultFormPresenter.this.view.showMessage(C0338R.string.item_created, true);
            DefaultFormPresenter.this.view.close(true);
        }
    }

    private class OnItemDeletedListener extends ShowingErrorOnFailureListener {
        private OnItemDeletedListener() {
            super(null);
        }

        public void onSuccess(T t) {
            DefaultFormPresenter.this.view.showMessage(C0338R.string.item_deleted, true);
            DefaultFormPresenter.this.view.close(true);
        }
    }

    private class OnItemUpdatedListener extends ShowingErrorOnFailureListener {
        private OnItemUpdatedListener() {
            super(null);
        }

        public void onSuccess(T item) {
            DefaultFormPresenter.this.view.setItem(item);
            DefaultFormPresenter.this.view.showMessage(C0338R.string.item_updated, true);
            DefaultFormPresenter.this.view.close(true);
        }
    }

    public DefaultFormPresenter(CrudDatasource<T> datasource, FormView<T> view) {
        super(view);
        this.datasource = datasource;
    }

    public void deleteItem(T item) {
        this.datasource.deleteItem(item, new OnItemDeletedListener());
    }

    public void save(T item) {
        if (validate(item)) {
            this.datasource.updateItem(item, new OnItemUpdatedListener());
        } else {
            this.view.showMessage(C0338R.string.correct_errors, false);
        }
    }

    public void create(T item) {
        if (validate(item)) {
            this.datasource.create(item, new OnItemCreatedListener());
        } else {
            this.view.showMessage(C0338R.string.correct_errors, false);
        }
    }
}
