package buildup.mvp.presenter;

import buildup.validation.Validator;

public interface FormPresenter<T> extends Presenter {
    void addValidator(int i, Validator<T> validator);

    void cancel();

    void create(T t);

    void deleteItem(T t);

    void save(T t);

    boolean validate(T t);
}
