package buildup.mvp.model;

public interface MutableIdentifiableBean extends IdentifiableBean {
    void setIdentifiableId(String str);
}
