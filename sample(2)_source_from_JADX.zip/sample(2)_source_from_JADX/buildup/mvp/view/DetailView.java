package buildup.mvp.view;

public interface DetailView {
    void close(boolean z);

    void navigateToEditForm();

    void refresh();

    void showMessage(int i, boolean z);
}
