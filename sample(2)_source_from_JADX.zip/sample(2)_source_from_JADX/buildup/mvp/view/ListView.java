package buildup.mvp.view;

public interface ListView<T> {
    void refresh();

    void showDetail(T t, int i);

    void showMessage(int i);
}
