package buildup.mvp.view;

public interface FormView<T> {
    void close(boolean z);

    void setItem(T t);

    void showMessage(int i, boolean z);
}
