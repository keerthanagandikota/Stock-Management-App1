package buildup.ui;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import buildup.adapters.TabItem;
import buildup.adapters.TabPagerAdapter;
import buildup.core.C0338R;
import buildup.navigation.TabNavigation;
import buildup.views.FixedScrollableCustomTabLayout;
import java.util.List;

public abstract class TabActivity extends AppCompatActivity implements TabNavigation {
    private List<TabItem> tabItems;
    private FixedScrollableCustomTabLayout tabLayout;
    private ViewPager viewPager;

    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0338R.layout.tab_activity);
        this.tabLayout = (FixedScrollableCustomTabLayout) findViewById(C0338R.id.main_tab_layout);
        this.viewPager = (ViewPager) findViewById(C0338R.id.main_view_pager);
        setSupportActionBar((Toolbar) findViewById(C0338R.id.toolbar));
        this.tabItems = getTabItems();
        setupTabs();
    }

    private void setupTabs() {
        this.viewPager.setAdapter(new TabPagerAdapter(getSupportFragmentManager(), this, this.tabItems));
        this.viewPager.setOffscreenPageLimit(this.tabItems.size());
        this.tabLayout.setupWithViewPager(this.viewPager);
        if (VERSION.SDK_INT >= 23) {
            this.tabLayout.setTabTextColors(getResources().getColor(C0338R.color.textBarColor, getTheme()), getResources().getColor(C0338R.color.textBarColor, getTheme()));
            this.tabLayout.setSelectedTabIndicatorColor(getResources().getColor(C0338R.color.textBarColor, getTheme()));
        } else {
            this.tabLayout.setTabTextColors(getResources().getColor(C0338R.color.textBarColor), getResources().getColor(C0338R.color.textBarColor));
            this.tabLayout.setSelectedTabIndicatorColor(getResources().getColor(C0338R.color.textBarColor));
        }
        for (int i = 0; i < this.tabLayout.getTabCount(); i++) {
            if (((TabItem) this.tabItems.get(i)).getPageIconRes() != null) {
                this.tabLayout.getTabAt(i).setIcon(((TabItem) this.tabItems.get(i)).getPageIconRes().intValue());
            }
        }
    }
}
