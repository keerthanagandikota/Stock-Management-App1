package buildup.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import buildup.core.C0338R;

public abstract class FilterActivity extends BaseActivity {
    protected abstract Fragment getFragment();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0338R.layout.filter_activity);
        Toolbar toolbar = (Toolbar) findViewById(C0338R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            if (isTaskRoot()) {
                getSupportActionBar().setDisplayHomeAsUpEnabled(false);
            } else {
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            }
        }
        if (savedInstanceState == null) {
            Bundle args = new Bundle();
            Bundle extras = getIntent().getExtras();
            if (extras != null) {
                args.putAll(extras);
            }
            Fragment fr = getFragment();
            fr.setArguments(args);
            getSupportFragmentManager().beginTransaction().add(C0338R.id.container, fr).commit();
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() != 16908332) {
            return super.onOptionsItemSelected(item);
        }
        finish();
        return true;
    }
}
