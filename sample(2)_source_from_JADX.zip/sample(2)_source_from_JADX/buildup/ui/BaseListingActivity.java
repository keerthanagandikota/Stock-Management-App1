package buildup.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import buildup.core.C0338R;
import buildup.util.FragmentUtils;

public abstract class BaseListingActivity extends BaseActivity {
    private FragmentManager mFragmentManager;
    Toolbar mToolbar;

    protected abstract Class<? extends Fragment> getFragmentClass();

    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(C0338R.layout.listing_activity);
        this.mFragmentManager = getSupportFragmentManager();
        this.mToolbar = (Toolbar) findViewById(C0338R.id.toolbar);
        if (this.mToolbar != null) {
            setSupportActionBar(this.mToolbar);
        }
        Class<? extends Fragment> mFragmentClass = getFragmentClass();
        if (mFragmentClass != null) {
            String tag = getClass().getName();
            if (this.mFragmentManager.findFragmentByTag(tag) == null) {
                this.mFragmentManager.beginTransaction().replace(C0338R.id.content_frame, FragmentUtils.instantiate(mFragmentClass, getIntent().getExtras()), tag).commit();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 100 && getResources().getBoolean(C0338R.bool.tabletLayout)) {
            Fragment fr = this.mFragmentManager.findFragmentByTag(getClass().getName());
            if (fr != null && (fr instanceof Refreshable)) {
                ((Refreshable) fr).refresh();
            }
        }
    }
}
