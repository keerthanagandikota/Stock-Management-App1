package buildup.ui;

import buildup.ds.filter.Filter;

public interface Filterable {
    void addFilter(Filter filter);

    void clearFilters();

    void onSearchTextChanged(String str);
}
