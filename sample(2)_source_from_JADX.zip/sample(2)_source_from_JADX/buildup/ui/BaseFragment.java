package buildup.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import buildup.actions.Action;
import buildup.behaviors.Behavior;
import buildup.mvp.presenter.Presenter;
import io.buildup.pkg20170504080645.BuildConfig;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class BaseFragment extends Fragment {
    protected List<Behavior> behaviors;
    protected Presenter presenter;

    /* renamed from: buildup.ui.BaseFragment.1 */
    class C03611 implements OnClickListener {
        final /* synthetic */ Action val$action;

        C03611(Action action) {
            this.val$action = action;
        }

        public void onClick(View v) {
            if (this.val$action.canDoExecute()) {
                this.val$action.execute(v.getContext());
                for (Behavior behavior : BaseFragment.this.behaviors) {
                    behavior.onActionClick(this.val$action.getAnalyticsInfo());
                }
            }
        }
    }

    public BaseFragment() {
        this.behaviors = new ArrayList();
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    public void onStart() {
        super.onStart();
        for (Behavior behavior : this.behaviors) {
            behavior.onStart();
        }
    }

    public void onResume() {
        super.onResume();
        if (this.presenter != null) {
            this.presenter.startPresenting();
        }
        for (Behavior b : this.behaviors) {
            b.onResume();
        }
    }

    public void onPause() {
        super.onPause();
        if (this.presenter != null) {
            this.presenter.stopPresenting();
        }
        for (Behavior b : this.behaviors) {
            b.onPause();
        }
    }

    public void onStop() {
        super.onStop();
        for (Behavior behavior : this.behaviors) {
            behavior.onStop();
        }
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        for (Behavior b : this.behaviors) {
            b.onViewCreated(view, savedInstanceState);
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        for (Behavior b : this.behaviors) {
            b.onCreateOptionsMenu(menu, inflater);
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        boolean managed = false;
        for (Behavior b : this.behaviors) {
            managed = managed || b.onOptionsItemSelected(item);
        }
        return managed;
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        for (Behavior b : this.behaviors) {
            b.onActivityResult(requestCode, resultCode, data);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        this.behaviors.clear();
    }

    public String dateToString(Date date) {
        if (date == null) {
            return BuildConfig.FLAVOR;
        }
        return DateFormat.getMediumDateFormat(getActivity()).format(date);
    }

    public String dateTimeToString(Date date) {
        if (date == null) {
            return BuildConfig.FLAVOR;
        }
        Activity activity = getActivity();
        return String.format("%s %s", new Object[]{DateFormat.getMediumDateFormat(activity).format(date), DateFormat.getTimeFormat(activity).format(date)});
    }

    public String dateToString(Long dateAsLong) {
        if (dateAsLong == null) {
            return BuildConfig.FLAVOR;
        }
        return dateToString(new Date(dateAsLong.longValue()));
    }

    public String dateTimeToString(Long dateAsLong) {
        if (dateAsLong == null) {
            return BuildConfig.FLAVOR;
        }
        return dateTimeToString(new Date(dateAsLong.longValue()));
    }

    public Behavior findTypeBehavior(Class<? extends Behavior> typeBehavior) {
        String behaviorName = typeBehavior.getSimpleName();
        for (Behavior b : this.behaviors) {
            if (b.getClass().getSimpleName().equals(behaviorName)) {
                return b;
            }
        }
        return null;
    }

    public void addBehavior(Behavior behavior) {
        this.behaviors.add(behavior);
    }

    public void setPresenter(Presenter presenter) {
        this.presenter = presenter;
    }

    public Presenter getPresenter() {
        return this.presenter;
    }

    protected void bindAction(View view, Action action) {
        view.setOnClickListener(new C03611(action));
    }

    public void onEvent(Object o) {
    }
}
