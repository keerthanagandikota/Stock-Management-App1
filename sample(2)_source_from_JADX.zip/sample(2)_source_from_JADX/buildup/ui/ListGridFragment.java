package buildup.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.LayoutRes;
import android.support.design.widget.Snackbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ProgressBar;
import android.widget.TextView;
import buildup.adapters.DatasourceAdapter;
import buildup.adapters.DatasourceAdapter.Callback;
import buildup.adapters.PaginationAwareAdapter;
import buildup.behaviors.AnalyticsSwipeRefreshBehavior;
import buildup.behaviors.Behavior;
import buildup.core.C0338R;
import buildup.ds.Datasource;
import buildup.ds.Pagination;
import buildup.ds.SearchOptions;
import buildup.ds.filter.DateRangeFilter;
import buildup.ds.filter.Filter;
import buildup.ds.filter.StringListFilter;
import buildup.mvp.presenter.ListCrudPresenter;
import buildup.mvp.view.ListView;
import buildup.util.EndlessScrollListener;
import java.util.Date;
import java.util.List;

public abstract class ListGridFragment<T> extends BaseFragment implements Refreshable, Filterable, ListView<T>, OnItemClickListener, OnItemLongClickListener {
    private DatasourceAdapter<T> adapter;
    private Datasource<T> datasource;
    private View footer;
    private int headerRes;
    private View headerView;
    private boolean justCreated;
    private AbsListView listView;
    private ProgressBar progressView;
    private EndlessScrollListener scrollListener;

    /* renamed from: buildup.ui.ListGridFragment.1 */
    class C03721 extends EndlessScrollListener {
        C03721() {
        }

        public void onLoadMore(int page, int totalItemsCount) {
            ((PaginationAwareAdapter) ListGridFragment.this.adapter).loadNextPage();
        }
    }

    /* renamed from: buildup.ui.ListGridFragment.2 */
    class C03732 extends PaginationAwareAdapter<T> {
        C03732(Context context, int viewId, Datasource datasource) {
            super(context, viewId, datasource);
        }

        public void bindView(T item, int position, View view) {
            ListGridFragment.this.bindView(item, view, position);
        }
    }

    /* renamed from: buildup.ui.ListGridFragment.3 */
    class C03743 extends DatasourceAdapter<T> {
        C03743(Context context, int viewId, Datasource datasource) {
            super(context, viewId, datasource);
        }

        public void bindView(T item, int position, View view) {
            ListGridFragment.this.bindView(item, view, position);
        }
    }

    /* renamed from: buildup.ui.ListGridFragment.4 */
    class C03754 implements Callback {
        C03754() {
        }

        public void onDataAvailable() {
            ListGridFragment.this.setListShown(true);
            ListGridFragment.this.showFooter(false);
            if (ListGridFragment.this.scrollListener != null) {
                ListGridFragment.this.scrollListener.finishLoading();
            }
        }

        public void onPageRequested() {
            ListGridFragment.this.showFooter(true);
        }

        public void onDatasourceError(Exception e) {
            ListGridFragment.this.setListShown(true);
            ListGridFragment.this.showFooter(false);
        }
    }

    protected abstract void bindView(T t, View view, int i);

    protected abstract Datasource<T> getDatasource();

    @LayoutRes
    protected abstract int getItemLayout();

    @LayoutRes
    protected abstract int getLayout();

    protected abstract SearchOptions getSearchOptions();

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addBehavior(new AnalyticsSwipeRefreshBehavior(this));
        setRetainInstance(true);
        this.justCreated = true;
    }

    private void showFooter(boolean show) {
        if (this.listView.getVisibility() == 0 && this.footer != null) {
            if (show) {
                ((android.widget.ListView) this.listView).addFooterView(this.footer);
            } else {
                ((android.widget.ListView) this.listView).removeFooterView(this.footer);
            }
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            this.datasource = getDatasource();
            this.adapter = createAdapter();
        }
        View view = inflater.inflate(getLayout(), container, false);
        this.listView = (AbsListView) view.findViewById(16908298);
        this.progressView = (ProgressBar) view.findViewById(C0338R.id.progressContainer);
        this.listView.setOnItemClickListener(this);
        this.listView.setOnItemLongClickListener(this);
        if (this.datasource instanceof Pagination) {
            this.scrollListener = new C03721();
            this.listView.setOnScrollListener(this.scrollListener);
            if (this.listView instanceof android.widget.ListView) {
                this.footer = inflater.inflate(C0338R.layout.list_footer, null, false);
                ((android.widget.ListView) this.listView).addFooterView(this.footer);
            }
        }
        if ((this.listView instanceof android.widget.ListView) && this.headerRes != 0) {
            this.headerView = inflater.inflate(this.headerRes, null, false);
            ((android.widget.ListView) this.listView).addHeaderView(this.headerView, null, false);
        }
        this.listView.setAdapter(this.adapter);
        if ((this.datasource instanceof Pagination) && (this.listView instanceof android.widget.ListView)) {
            ((android.widget.ListView) this.listView).removeFooterView(this.footer);
        }
        View emptyView = view.findViewById(16908292);
        if (emptyView != null) {
            this.listView.setEmptyView(emptyView);
        }
        return view;
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public void onResume() {
        super.onResume();
        if (this.justCreated) {
            refresh(false);
        }
    }

    public void onPause() {
        super.onPause();
        this.justCreated = false;
    }

    public void onDestroy() {
        this.datasource = null;
        this.adapter = null;
        super.onDestroy();
    }

    protected DatasourceAdapter<T> createAdapter() {
        DatasourceAdapter<T> datasourceAdapter;
        if (this.datasource instanceof Pagination) {
            datasourceAdapter = new C03732(getActivity(), getItemLayout(), this.datasource);
        } else {
            datasourceAdapter = new C03743(getActivity(), getItemLayout(), this.datasource);
        }
        datasourceAdapter.setCallback(new C03754());
        return datasourceAdapter;
    }

    private void setListShown(boolean shown) {
        int i = 0;
        if (this.progressView != null && this.listView != null) {
            int i2;
            View emptyView = this.listView.getEmptyView();
            if (!(emptyView == null || this.adapter == null)) {
                if (shown && this.adapter.isEmpty()) {
                    i2 = 0;
                } else {
                    i2 = 8;
                }
                emptyView.setVisibility(i2);
            }
            ProgressBar progressBar = this.progressView;
            if (shown) {
                i2 = 8;
            } else {
                i2 = 0;
            }
            progressBar.setVisibility(i2);
            AbsListView absListView = this.listView;
            if (!shown) {
                i = 8;
            }
            absListView.setVisibility(i);
        }
    }

    public AbsListView getListView() {
        return this.listView;
    }

    public void setHeaderResource(int resource) {
        this.headerRes = resource;
    }

    public View getHeaderView() {
        return this.headerView;
    }

    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        itemClicked(parent.getAdapter().getItem(position), position);
    }

    protected void itemClicked(T item, int position) {
        showDetail(item, position);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 100) {
            refresh();
        }
    }

    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        boolean res = false;
        for (Behavior b : this.behaviors) {
            res = b.onItemLongClick(parent, view, position, id) || res;
        }
        return res;
    }

    public void refresh() {
        refresh(true);
    }

    private void refresh(boolean forceRefresh) {
        setListShown(false);
        this.listView.clearChoices();
        this.adapter.refresh(forceRefresh);
    }

    public void setEmptyText(CharSequence emptyText) {
        View emptyView = this.listView.getEmptyView();
        if (emptyText instanceof TextView) {
            ((TextView) emptyView).setText(emptyText);
        }
    }

    public void showDetail(T t, int position) {
    }

    public void showMessage(int messageRes) {
        Snackbar.make(getView(), getString(messageRes), 0).show();
    }

    public DatasourceAdapter<T> getAdapter() {
        return this.adapter;
    }

    public void onSearchTextChanged(String searchText) {
        this.datasource.onSearchTextChanged(searchText);
        refresh();
    }

    public void addFilter(Filter filter) {
        this.datasource.addFilter(filter);
    }

    public void clearFilters() {
        this.datasource.clearFilters();
    }

    public void addStringFilter(String field, List<String> values) {
        this.datasource.addFilter(new StringListFilter(field, values));
    }

    public void addDateRangeFilter(String field, long value1, long value2) {
        Date min;
        Date max = null;
        if (value1 != -1) {
            min = new Date(value1);
        } else {
            min = null;
        }
        if (value2 != -1) {
            max = new Date(value2);
        }
        this.datasource.addFilter(new DateRangeFilter(field, min, max));
    }

    public ListCrudPresenter<T> getPresenter() {
        return (ListCrudPresenter) super.getPresenter();
    }
}
