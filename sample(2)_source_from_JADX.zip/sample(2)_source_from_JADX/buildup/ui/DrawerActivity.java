package buildup.ui;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.NavigationView.OnNavigationItemSelectedListener;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.Toolbar;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import buildup.core.C0338R;
import buildup.navigation.Navigation;
import buildup.util.FragmentUtils;

public abstract class DrawerActivity extends BaseActivity implements Navigation, OnNavigationItemSelectedListener {
    public static String DRAWER_POSITION_KEY = null;
    public static final String FR_DRAWER = "FrDrawer";
    private int lastPosition;
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mDrawerToggle;
    private FragmentManager mFragmentManager;
    private SparseArray<Class<? extends Fragment>> mFragments;
    private Toolbar mToolbar;
    private NavigationView navigationView;

    /* renamed from: buildup.ui.DrawerActivity.1 */
    class C03711 extends ActionBarDrawerToggle {
        C03711(Activity arg0, DrawerLayout arg1, Toolbar arg2, int arg3, int arg4) {
            super(arg0, arg1, arg2, arg3, arg4);
        }

        public void onDrawerClosed(View drawerView) {
            super.onDrawerClosed(drawerView);
            DrawerActivity.this.supportInvalidateOptionsMenu();
        }

        public void onDrawerOpened(View drawerView) {
            super.onDrawerOpened(drawerView);
            DrawerActivity.this.supportInvalidateOptionsMenu();
        }
    }

    public DrawerActivity() {
        this.lastPosition = -1;
    }

    static {
        DRAWER_POSITION_KEY = "DRAWER_POSITION";
    }

    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(C0338R.layout.drawer_activity_main);
        this.mToolbar = (Toolbar) findViewById(C0338R.id.toolbar);
        if (this.mToolbar != null) {
            setSupportActionBar(this.mToolbar);
        }
        this.navigationView = (NavigationView) findViewById(C0338R.id.drawerNavigationView);
        this.mDrawerLayout = (DrawerLayout) findViewById(C0338R.id.drawer_layout);
        this.navigationView.setNavigationItemSelectedListener(this);
        this.navigationView.setItemIconTintList(null);
        this.mFragments = getSectionFragmentClasses();
        setupDrawer();
        this.mFragmentManager = getSupportFragmentManager();
        int currentItem = this.mFragments.keyAt(0);
        if (savedInstance != null) {
            currentItem = savedInstance.getInt(DRAWER_POSITION_KEY, currentItem);
            this.lastPosition = currentItem;
            selectDrawerItem(currentItem);
            return;
        }
        onNavigationItemSelected(this.navigationView.getMenu().getItem(0));
    }

    private void setupDrawer() {
        this.mDrawerToggle = new C03711(this, this.mDrawerLayout, this.mToolbar, C0338R.string.drawer_open, C0338R.string.drawer_close);
        this.mDrawerLayout.setDrawerListener(this.mDrawerToggle);
        this.mDrawerToggle.syncState();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putInt(DRAWER_POSITION_KEY, this.lastPosition);
    }

    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        this.mDrawerToggle.syncState();
    }

    public boolean onPrepareOptionsMenu(Menu menu) {
        if (this.mDrawerLayout.isDrawerOpen(this.navigationView)) {
            for (int index = 0; index < menu.size(); index++) {
                menu.getItem(index).setVisible(false);
            }
        }
        return super.onPrepareOptionsMenu(menu);
    }

    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        this.mDrawerToggle.onConfigurationChanged(config);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        return (this.mDrawerToggle != null && this.mDrawerToggle.onOptionsItemSelected(item)) || super.onOptionsItemSelected(item);
    }

    public void selectDrawerItem(int itemId) {
        if (positionChanged(itemId)) {
            String tag = FR_DRAWER + itemId;
            Fragment fr = this.mFragmentManager.findFragmentByTag(tag);
            if (fr == null) {
                fr = FragmentUtils.instantiate((Class) this.mFragments.get(itemId), new Bundle());
            }
            FragmentTransaction replaceTransaction = this.mFragmentManager.beginTransaction();
            replaceTransaction.replace(C0338R.id.content_frame, fr, tag);
            replaceTransaction.commit();
        }
    }

    private boolean positionChanged(int position) {
        if (position == this.lastPosition) {
            return false;
        }
        this.lastPosition = position;
        return true;
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 100) {
            refreshList();
        }
    }

    private void refreshList() {
        Fragment fr = this.mFragmentManager.findFragmentByTag(FR_DRAWER + this.lastPosition);
        if (fr instanceof ListGridFragment) {
            ((ListGridFragment) fr).refresh();
        }
    }

    public boolean onNavigationItemSelected(MenuItem item) {
        item.setChecked(true);
        this.mDrawerLayout.closeDrawers();
        selectDrawerItem(item.getItemId());
        setTitle(item.getTitle());
        return true;
    }

    public void onBackPressed() {
        if (this.mDrawerLayout.isDrawerOpen((int) GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer((int) GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}
