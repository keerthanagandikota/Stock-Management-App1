package buildup.ui;

public interface Refreshable {
    void refresh();
}
