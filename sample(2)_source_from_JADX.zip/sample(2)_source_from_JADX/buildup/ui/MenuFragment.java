package buildup.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import buildup.MenuItem;
import buildup.actions.Action;
import buildup.behaviors.Behavior;
import buildup.core.C0338R;
import buildup.util.image.ImageLoaderRequest.Builder;
import buildup.util.image.PicassoImageLoader;
import java.util.List;

public abstract class MenuFragment extends BaseFragment implements OnItemClickListener {
    private AbsListView mList;
    private List<MenuItem> mMenuItems;

    /* renamed from: buildup.ui.MenuFragment.1 */
    class C03761 extends ArrayAdapter<MenuItem> {
        C03761(Context x0, int x1, int x2, MenuItem[] x3) {
            super(x0, x1, x2, x3);
        }

        public View getView(int position, View convertView, ViewGroup container) {
            View v;
            if (convertView != null) {
                v = convertView;
            } else {
                v = MenuFragment.this.getActivity().getLayoutInflater().inflate(MenuFragment.this.getItemLayout(), container, false);
            }
            MenuFragment.this.defaultItemBinding((MenuItem) getItem(position), v);
            return v;
        }
    }

    public abstract int getItemLayout();

    public abstract int getLayout();

    public abstract List<MenuItem> getMenuItems();

    public void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        this.mMenuItems = getMenuItems();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(getLayout(), container, false);
        this.mList = (AbsListView) view.findViewById(16908298);
        if (this.mList == null) {
            throw new IllegalStateException("Layout is not a menu layout");
        }
        this.mList.setAdapter(getAdapter());
        this.mList.setOnItemClickListener(this);
        this.mList.setEmptyView(view.findViewById(16908292));
        return view;
    }

    public void onDestroyView() {
        super.onDestroyView();
        this.mList = null;
    }

    public void onDestroy() {
        super.onDestroy();
        this.mMenuItems = null;
    }

    private ArrayAdapter<MenuItem> getAdapter() {
        return new C03761(getActivity(), getItemLayout(), 16908308, (MenuItem[]) this.mMenuItems.toArray(new MenuItem[this.mMenuItems.size()]));
    }

    private void defaultItemBinding(MenuItem item, View view) {
        ImageView image = (ImageView) view.findViewById(C0338R.id.image);
        if (image != null) {
            if (item.getIconUrl() != null) {
                new PicassoImageLoader(image.getContext()).load(Builder.imageLoaderRequest().withPath(item.getIconUrl()).withTargetView(image).build());
            } else {
                image.setImageResource(item.getIcon());
            }
        }
        TextView text = (TextView) view.findViewById(C0338R.id.title);
        if (text != null) {
            text.setText(item.getLabel());
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        executeAction((MenuItem) this.mMenuItems.get(position));
    }

    public void executeAction(MenuItem item) {
        Action cmd = item.getAction();
        if (cmd != null && cmd.canDoExecute()) {
            cmd.execute(getActivity());
            for (Behavior behavior : this.behaviors) {
                behavior.onActionClick(cmd.getAnalyticsInfo());
            }
        }
    }
}
