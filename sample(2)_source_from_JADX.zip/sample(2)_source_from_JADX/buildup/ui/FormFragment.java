package buildup.ui;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v7.widget.SwitchCompat;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import buildup.core.C0338R;
import buildup.ds.restds.GeoPoint;
import buildup.mvp.presenter.FormPresenter;
import buildup.mvp.view.FormView;
import buildup.util.Constants;
import buildup.validation.Validator;
import buildup.views.DatePicker;
import buildup.views.DatePicker.DateSelectedListener;
import buildup.views.DateTimePicker;
import buildup.views.GeoPicker;
import buildup.views.GeoPicker.PointChangedListener;
import buildup.views.ImagePicker;
import buildup.views.ImagePicker.Callback;
import buildup.views.TristateBooleanPicker;
import buildup.views.TristateBooleanPicker.ChoiceListener;
import io.buildup.pkg20170504080645.C0585R;
import java.net.URL;
import java.util.Date;

public abstract class FormFragment<T> extends DetailFragment<T> implements FormView<T> {
    public static final String IS_UPDATING_KEY = "_isupdating_";
    private ProgressDialog mProgressDialog;
    private int mode;

    protected abstract T newItem();

    public void onCreate(Bundle state) {
        super.onCreate(state);
        this.mode = getArguments().getInt(Constants.MODE);
        boolean isUpdating = state != null && state.getBoolean(IS_UPDATING_KEY);
        if (isUpdating) {
            showProgress();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(IS_UPDATING_KEY, isUpdating());
    }

    protected void initView(View view, Bundle state) {
        if (this.mode != 1) {
            this.item = newItem();
            bindView(this.item, view);
            setContentShown(true);
        } else if (this.item != null) {
            bindView(this.item, view);
            setContentShown(true);
        } else {
            refresh();
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.add(0, C0338R.id.action_save, 1, 17039370).setShowAsAction(2);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == C0338R.id.action_save) {
            showProgress();
            if (this.mode == 1) {
                getPresenter().save(getItem());
            } else {
                getPresenter().create(getItem());
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void showProgress() {
        this.mProgressDialog = ProgressDialog.show(getActivity(), null, getString(C0338R.string.saving_changes), true);
    }

    public FormPresenter<T> getPresenter() {
        return (FormPresenter) super.getPresenter();
    }

    public void close(boolean shouldRefresh) {
        dismissPendingProgress();
        Intent data = new Intent();
        data.putExtra(Constants.CONTENT, (Parcelable) getItem());
        getActivity().setResult(shouldRefresh ? 100 : C0585R.styleable.Theme_buttonStyleSmall, data);
        getActivity().finish();
    }

    public void navigateToEditForm() {
    }

    public void showMessage(int message, boolean toast) {
        super.showMessage(message, toast);
        dismissPendingProgress();
    }

    protected void dismissPendingProgress() {
        if (isUpdating()) {
            this.mProgressDialog.dismiss();
        }
    }

    private boolean isUpdating() {
        return this.mProgressDialog != null && this.mProgressDialog.isShowing();
    }

    public void bindBoolean(int viewId, Boolean value, Boolean readonly, OnClickListener listener) {
        boolean z = false;
        SwitchCompat view = (SwitchCompat) getView().findViewById(viewId);
        view.setEnabled(!readonly.booleanValue());
        if (value != null) {
            z = value.booleanValue();
        }
        view.setChecked(z);
        view.setOnClickListener(listener);
        if (value == null) {
            listener.onClick(view);
        }
    }

    public void bindNullableBoolean(int viewId, Boolean value, Boolean readonly, ChoiceListener listener) {
        TristateBooleanPicker view = (TristateBooleanPicker) getView().findViewById(viewId);
        view.setEnabled(!readonly.booleanValue());
        view.setValue(value);
        view.setListener(listener);
    }

    public void bindLong(int viewId, Long value, Boolean readonly, TextWatcher listener) {
        bindLong(viewId, value, readonly, listener, null);
    }

    public void bindLong(int viewId, Long value, Boolean readonly, TextWatcher listener, Validator<T> validator) {
        bindString(viewId, value != null ? String.valueOf(value) : null, readonly, listener, validator);
    }

    public void bindDouble(int viewId, Double value, Boolean readonly, TextWatcher listener) {
        bindDouble(viewId, value, readonly, listener, null);
    }

    public void bindDouble(int viewId, Double value, Boolean readonly, TextWatcher listener, Validator<T> validator) {
        bindString(viewId, value != null ? String.valueOf(value) : null, readonly, listener, validator);
    }

    public void bindString(int viewId, String value, Boolean readonly, TextWatcher listener) {
        bindString(viewId, value, readonly, listener, null);
    }

    public void bindString(int viewId, String value, Boolean readonly, TextWatcher listener, Validator<T> validator) {
        EditText view = (EditText) getView().findViewById(viewId);
        view.setEnabled(!readonly.booleanValue());
        view.setText(value);
        view.addTextChangedListener(listener);
        if (validator != null) {
            getPresenter().addValidator(viewId, validator);
        }
    }

    public void bindDatePicker(int viewId, Date value, Boolean readonly, DateSelectedListener listener) {
        bindDatePicker(viewId, value, readonly, listener, null);
    }

    public void bindDatePicker(int viewId, Date value, Boolean readonly, DateSelectedListener listener, Validator<T> validator) {
        DatePicker view = (DatePicker) getView().findViewById(viewId);
        view.setEnabled(!readonly.booleanValue());
        view.setDate(value);
        view.setListener(listener);
        if (validator != null) {
            getPresenter().addValidator(viewId, validator);
        }
    }

    public void bindDateTimePicker(int viewId, Date value, Boolean readonly, DateTimePicker.DateSelectedListener listener) {
        bindDateTimePicker(viewId, value, readonly, listener, null);
    }

    public void bindDateTimePicker(int viewId, Date value, Boolean readonly, DateTimePicker.DateSelectedListener listener, Validator<T> validator) {
        DateTimePicker view = (DateTimePicker) getView().findViewById(viewId);
        view.setEnabled(!readonly.booleanValue());
        view.setDateTime(value);
        view.setDateTimeSelectedListener(listener);
        if (validator != null) {
            getPresenter().addValidator(viewId, validator);
        }
    }

    public void bindImage(int viewId, URL value, Boolean readonly, int index, Callback callback) {
        bindImage(viewId, value, readonly, index, null, callback);
    }

    public void bindImage(int viewId, URL value, Boolean readonly, int index, Validator<T> validator, Callback callback) {
        ImagePicker picker = (ImagePicker) getView().findViewById(viewId);
        picker.setTargetFragment(this);
        picker.setEnabled(readonly.booleanValue());
        if (callback != null) {
            picker.setCallback(callback);
        }
        if (value != null) {
            picker.setImageUrl(value.toExternalForm());
        }
        if (validator != null) {
            getPresenter().addValidator(viewId, validator);
        }
    }

    public void bindLocation(int viewId, GeoPoint value, Boolean readonly, PointChangedListener listener) {
        bindLocation(viewId, value, readonly, listener, null);
    }

    public void bindLocation(int viewId, GeoPoint value, Boolean readonly, PointChangedListener listener, Validator<T> validator) {
        GeoPicker view = (GeoPicker) getView().findViewById(viewId);
        view.setEnabled(!readonly.booleanValue());
        view.setPoint(value);
        view.setListener(listener);
        if (validator != null) {
            getPresenter().addValidator(viewId, validator);
        }
    }
}
