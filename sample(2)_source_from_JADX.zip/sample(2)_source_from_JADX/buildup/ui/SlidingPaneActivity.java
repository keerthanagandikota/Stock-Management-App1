package buildup.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.SlidingPaneLayout;
import android.support.v4.widget.SlidingPaneLayout.PanelSlideListener;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import buildup.core.C0338R;
import buildup.util.Constants;
import buildup.util.FragmentUtils;

public abstract class SlidingPaneActivity extends BaseActivity {
    private CharSequence mActivityTitle;
    private FragmentManager mFragmentManager;
    private SlidingPaneLayout mSlidingPane;

    private class PaneListener implements PanelSlideListener {
        private PaneListener() {
        }

        public void onPanelClosed(View view) {
            SlidingPaneActivity.this.showActions(false);
        }

        public void onPanelOpened(View view) {
            SlidingPaneActivity.this.setTitle(SlidingPaneActivity.this.mActivityTitle);
            SlidingPaneActivity.this.showActions(true);
        }

        public void onPanelSlide(View view, float arg1) {
        }
    }

    protected abstract Class<? extends Fragment> getFragmentClass();

    protected void onCreate(Bundle savedInstance) {
        super.onCreate(savedInstance);
        setContentView(C0338R.layout.sliding_pane_activity);
        this.mActivityTitle = getTitle();
        this.mSlidingPane = (SlidingPaneLayout) findViewById(C0338R.id.slidingPane);
        this.mSlidingPane.setParallaxDistance(50);
        this.mSlidingPane.setShadowResourceLeft(C0338R.drawable.sliding_pane_shadow);
        this.mSlidingPane.setPanelSlideListener(new PaneListener());
        this.mSlidingPane.openPane();
        this.mFragmentManager = getSupportFragmentManager();
        Toolbar toolbar = (Toolbar) findViewById(C0338R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }
        Class<? extends Fragment> mFragmentClass = getFragmentClass();
        if (mFragmentClass != null) {
            String tag = getClass().getName();
            if (this.mFragmentManager.findFragmentByTag(tag) == null) {
                this.mFragmentManager.beginTransaction().replace(C0338R.id.content_frame, FragmentUtils.instantiate(mFragmentClass, new Bundle()), tag).commit();
            }
        }
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 16908332:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void navigateToDetail(Class detailActivityClass, Class detailFragment, Bundle args) {
        DetailFragment fr = (DetailFragment) this.mFragmentManager.findFragmentById(C0338R.id.detail_frame);
        if (fr == null) {
            this.mFragmentManager.beginTransaction().replace(C0338R.id.detail_frame, FragmentUtils.instantiate(detailFragment, args)).commit();
        } else {
            fr.setItem(args.getParcelable(Constants.CONTENT));
        }
        this.mSlidingPane.closePane();
    }

    private void showActions(boolean isOpen) {
        Fragment fr = this.mFragmentManager.findFragmentById(C0338R.id.content_frame);
        if (fr != null) {
            fr.setHasOptionsMenu(isOpen);
        }
        fr = this.mFragmentManager.findFragmentById(C0338R.id.detail_frame);
        if (fr != null) {
            fr.setHasOptionsMenu(!isOpen);
        }
    }
}
