package buildup.ui;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import buildup.core.C0338R;
import buildup.ds.Count;
import buildup.ds.Datasource;
import buildup.ds.Datasource.Listener;
import buildup.util.Constants;
import buildup.util.DepthPageTransformer;

public abstract class DetailPagerFragment<T> extends BaseFragment {
    PagerAdapter mAdapter;
    Datasource<T> mDatasource;
    ViewPager mPager;
    int mPos;
    private int mSize;

    /* renamed from: buildup.ui.DetailPagerFragment.1 */
    class C03701 extends FragmentStatePagerAdapter {

        /* renamed from: buildup.ui.DetailPagerFragment.1.1 */
        class C03691 implements Listener<T> {
            final /* synthetic */ Fragment val$fr;

            C03691(Fragment fragment) {
                this.val$fr = fragment;
            }

            public void onSuccess(T t) {
                ((DetailFragment) this.val$fr).setItem(t);
            }

            public void onFailure(Exception e) {
            }
        }

        C03701(FragmentManager x0) {
            super(x0);
        }

        public Fragment getItem(int i) {
            Fragment fr = DetailPagerFragment.this.getCardFragment(i);
            if (fr != null) {
                Bundle args = new Bundle();
                args.putInt(Constants.ITEMPOS, i);
                fr.setArguments(args);
                DetailPagerFragment.this.mDatasource.getItem(String.valueOf(i), new C03691(fr));
            }
            return fr;
        }

        public int getCount() {
            if (DetailPagerFragment.this.mDatasource == null || !(DetailPagerFragment.this.mDatasource instanceof Count)) {
                return DetailPagerFragment.this.mSize;
            }
            return ((Count) DetailPagerFragment.this.mDatasource).getCount();
        }
    }

    protected abstract Fragment getCardFragment(int i);

    protected abstract Datasource<T> getDatasource();

    public DetailPagerFragment() {
        this.mPos = 0;
    }

    public void onCreate(Bundle state) {
        super.onCreate(state);
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.mPos = arguments.getInt(Constants.ITEMPOS, 0);
            this.mSize = arguments.getInt(Constants.SIZE, 1);
        }
        if (state != null) {
            this.mPos = state.getInt(Constants.ITEMPOS, this.mPos);
        }
        this.mDatasource = getDatasource();
        this.mAdapter = createPagerAdapter();
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(Constants.ITEMPOS, this.mPager.getCurrentItem());
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(C0338R.layout.detail_pager, container, false);
        this.mPager = (ViewPager) view.findViewById(C0338R.id.pager);
        this.mPager.setAdapter(this.mAdapter);
        this.mPager.setCurrentItem(this.mPos);
        if (VERSION.SDK_INT >= 11) {
            this.mPager.setPageTransformer(true, new DepthPageTransformer());
        }
        return view;
    }

    public void onResume() {
        super.onResume();
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        this.mPager = null;
        this.mAdapter = null;
        this.mDatasource = null;
        super.onDestroy();
    }

    protected PagerAdapter createPagerAdapter() {
        return new C03701(getChildFragmentManager());
    }
}
