package buildup.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewPropertyAnimator;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import buildup.core.C0338R;
import buildup.services.LoginService;
import buildup.util.SecurePreferences;

public abstract class BaseLoginActivity extends BaseActivity {
    private boolean loginTaskRunning;
    private String mEmail;
    private EditText mEmailView;
    private View mLoginFormView;
    private String mPassword;
    private EditText mPasswordView;
    private View mProgressView;
    private SecurePreferences mSharedPreferences;

    /* renamed from: buildup.ui.BaseLoginActivity.1 */
    class C03621 implements OnClickListener {
        final /* synthetic */ Button val$mEmailSignInButton;

        C03621(Button button) {
            this.val$mEmailSignInButton = button;
        }

        public void onClick(View view) {
            ((InputMethodManager) BaseLoginActivity.this.getSystemService("input_method")).hideSoftInputFromWindow(this.val$mEmailSignInButton.getWindowToken(), 0);
            BaseLoginActivity.this.attemptLogin();
        }
    }

    /* renamed from: buildup.ui.BaseLoginActivity.2 */
    class C03632 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$show;

        C03632(boolean z) {
            this.val$show = z;
        }

        public void onAnimationEnd(Animator animation) {
            BaseLoginActivity.this.mLoginFormView.setVisibility(this.val$show ? 8 : 0);
        }
    }

    /* renamed from: buildup.ui.BaseLoginActivity.3 */
    class C03643 extends AnimatorListenerAdapter {
        final /* synthetic */ boolean val$show;

        C03643(boolean z) {
            this.val$show = z;
        }

        public void onAnimationEnd(Animator animation) {
            BaseLoginActivity.this.mProgressView.setVisibility(this.val$show ? 0 : 8);
        }
    }

    public abstract LoginService createLoginService();

    public BaseLoginActivity() {
        this.loginTaskRunning = false;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0338R.layout.activity_login);
        this.mEmailView = (EditText) findViewById(C0338R.id.email);
        populateAutoComplete();
        this.mPasswordView = (EditText) findViewById(C0338R.id.password);
        Button mEmailSignInButton = (Button) findViewById(C0338R.id.email_sign_in_button);
        mEmailSignInButton.setOnClickListener(new C03621(mEmailSignInButton));
        this.mLoginFormView = findViewById(C0338R.id.login_form);
        this.mProgressView = findViewById(C0338R.id.login_progress);
    }

    public void populateAutoComplete() {
        this.mEmailView.setText(this.mSharedPreferences.getString("lastUser", null));
    }

    public void attemptLogin() {
        if (!this.loginTaskRunning) {
            LoginService loginService = createLoginService();
            this.mEmailView.setError(null);
            this.mPasswordView.setError(null);
            this.mEmail = this.mEmailView.getText().toString();
            this.mPassword = this.mPasswordView.getText().toString();
            boolean cancel = false;
            View focusView = null;
            if (!(TextUtils.isEmpty(this.mPassword) || isPasswordValid(this.mPassword))) {
                this.mPasswordView.setError(getString(C0338R.string.error_incorrect_password));
                focusView = this.mPasswordView;
                cancel = true;
            }
            if (TextUtils.isEmpty(this.mEmail)) {
                this.mEmailView.setError(getString(C0338R.string.error_field_required));
                focusView = this.mEmailView;
                cancel = true;
            } else if (!isEmailValid(this.mEmail)) {
                this.mEmailView.setError(getString(C0338R.string.error_invalid_email));
                focusView = this.mEmailView;
                cancel = true;
            }
            if (cancel) {
                focusView.requestFocus();
                return;
            }
            showProgress(true);
            this.loginTaskRunning = true;
            loginService.attemptLogin(this.mEmail, this.mPassword);
        }
    }

    public boolean isEmailValid(String email) {
        return true;
    }

    public boolean isPasswordValid(String password) {
        return true;
    }

    public String getPassword() {
        return this.mPassword;
    }

    public String getEmail() {
        return this.mEmail;
    }

    public void setLoginTaskRunning(boolean loginTaskRunning) {
        this.loginTaskRunning = loginTaskRunning;
    }

    public void showProgress(boolean show) {
        float f;
        int i = 0;
        float f2 = 1.0f;
        int shortAnimTime = getResources().getInteger(17694720);
        this.mLoginFormView.setVisibility(show ? 8 : 0);
        ViewPropertyAnimator duration = this.mLoginFormView.animate().setDuration((long) shortAnimTime);
        if (show) {
            f = 0.0f;
        } else {
            f = 1.0f;
        }
        duration.alpha(f).setListener(new C03632(show));
        View view = this.mProgressView;
        if (!show) {
            i = 8;
        }
        view.setVisibility(i);
        ViewPropertyAnimator duration2 = this.mProgressView.animate().setDuration((long) shortAnimTime);
        if (!show) {
            f2 = 0.0f;
        }
        duration2.alpha(f2).setListener(new C03643(show));
    }

    public SecurePreferences getSharedPreferences() {
        return this.mSharedPreferences;
    }

    public void setSharedPreferences(SecurePreferences mSharedPreferences) {
        this.mSharedPreferences = mSharedPreferences;
    }
}
