package buildup.ui;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.Toolbar;
import buildup.core.C0338R;
import buildup.util.Constants;
import buildup.util.FragmentUtils;

public abstract class BaseDetailActivity extends BaseActivity {
    protected abstract Class<? extends Fragment> getFragmentClass();

    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        setContentView(C0338R.layout.detail_activity);
        Toolbar toolbar = (Toolbar) findViewById(C0338R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
        }
        Intent intent = getIntent();
        String title = intent.getStringExtra(Constants.TITLE);
        if (title != null) {
            setTitle(title);
        }
        Bundle args = intent.getExtras();
        if (args == null) {
            args = new Bundle();
        }
        loadFragment(args);
    }

    private void loadFragment(Bundle args) {
        Class<? extends Fragment> fClass = getFragmentClass();
        FragmentManager manager = getSupportFragmentManager();
        if (fClass != null) {
            String tag = getClass().getName();
            if (manager.findFragmentByTag(tag) == null) {
                manager.beginTransaction().replace(C0338R.id.content_frame, FragmentUtils.instantiate(fClass, args), tag).commit();
            }
        }
    }
}
