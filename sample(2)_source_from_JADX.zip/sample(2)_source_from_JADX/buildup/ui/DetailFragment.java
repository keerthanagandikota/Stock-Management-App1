package buildup.ui;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.widget.Snackbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import buildup.core.C0338R;
import buildup.ds.Datasource;
import buildup.ds.Datasource.Listener;
import buildup.ds.Pagination;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import buildup.mvp.view.DetailView;
import buildup.util.Constants;
import java.util.List;

public abstract class DetailFragment<T> extends BaseFragment implements Filterable, DetailView, Refreshable {
    private View contentContainer;
    protected Listener<List<T>> dataListListener;
    protected Listener<T> dataListener;
    private Datasource<T> datasource;
    protected T item;
    private int itemPos;
    private View progressContainer;
    private SearchOptions searchOptions;

    /* renamed from: buildup.ui.DetailFragment.1 */
    class C03671 implements Listener<T> {

        /* renamed from: buildup.ui.DetailFragment.1.1 */
        class C03651 implements Runnable {
            final /* synthetic */ Object val$result;
            final /* synthetic */ View val$v;

            C03651(View view, Object obj) {
                this.val$v = view;
                this.val$result = obj;
            }

            public void run() {
                if (this.val$v != null) {
                    DetailFragment.this.bindView(this.val$result, this.val$v);
                }
                DetailFragment.this.setContentShown(true);
            }
        }

        /* renamed from: buildup.ui.DetailFragment.1.2 */
        class C03662 implements Runnable {
            C03662() {
            }

            public void run() {
                DetailFragment.this.setContentShown(false);
            }
        }

        C03671() {
        }

        public void onSuccess(T result) {
            DetailFragment.this.item = result;
            View v = DetailFragment.this.getView();
            Activity act = DetailFragment.this.getActivity();
            if (act != null) {
                act.runOnUiThread(new C03651(v, result));
            }
        }

        public void onFailure(Exception e) {
            Activity act = DetailFragment.this.getActivity();
            if (act != null) {
                act.runOnUiThread(new C03662());
            }
        }
    }

    /* renamed from: buildup.ui.DetailFragment.2 */
    class C03682 implements Listener<List<T>> {
        C03682() {
        }

        public void onSuccess(List<T> ts) {
            if (ts.size() > 0) {
                DetailFragment.this.dataListener.onSuccess(ts.get(0));
            } else {
                DetailFragment.this.dataListener.onSuccess(null);
            }
        }

        public void onFailure(Exception e) {
            DetailFragment.this.dataListener.onFailure(e);
        }
    }

    public abstract void bindView(T t, View view);

    protected abstract int getLayout();

    public DetailFragment() {
        this.dataListener = new C03671();
        this.dataListListener = new C03682();
    }

    public void onCreate(Bundle state) {
        super.onCreate(state);
        Bundle args = getArguments();
        if (state != null) {
            this.item = state.getParcelable(Constants.CONTENT);
        }
        if (args != null) {
            if (this.item == null) {
                this.item = args.getParcelable(Constants.CONTENT);
            }
            this.itemPos = args.getInt(Constants.ITEMPOS, 0);
        }
    }

    public void setMenuVisibility(boolean visible) {
        super.setMenuVisibility(visible);
        if (visible && this.item != null) {
            onShow(this.item);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(getLayout(), container, false);
        this.progressContainer = view.findViewById(C0338R.id.progressContainer);
        this.contentContainer = view.findViewById(C0338R.id.contentContainer);
        return view;
    }

    public void onViewCreated(View view, Bundle savedState) {
        super.onViewCreated(view, savedState);
        initView(view, savedState);
    }

    protected void initView(View view, Bundle savedState) {
        this.datasource = getDatasource();
        if (this.item != null) {
            bindView(this.item, view);
            setContentShown(true);
            return;
        }
        refresh();
    }

    public void setItem(T newItem) {
        this.item = newItem;
        View v = getView();
        if (v != null) {
            bindView(this.item, v);
            setContentShown(true);
            onShow(this.item);
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable(Constants.CONTENT, (Parcelable) this.item);
    }

    public void onResume() {
        super.onResume();
        if (this.item != null) {
            onShow(this.item);
        }
    }

    public void onPause() {
        super.onPause();
    }

    public void onDestroy() {
        super.onDestroy();
        this.datasource = null;
        this.item = null;
    }

    public void refresh() {
        if (this.datasource != null) {
            setContentShown(false);
            if (this.searchOptions == null || !(this.datasource instanceof Pagination)) {
                this.datasource.getItem(String.valueOf(this.itemPos), this.dataListener);
                return;
            } else {
                ((Pagination) this.datasource).getItems(0, this.dataListListener);
                return;
            }
        }
        throw new IllegalStateException("Either Item or Datasource should be implemented");
    }

    public void onSearchTextChanged(String s) {
        ensureSearchOptions();
        this.searchOptions.setSearchText(s);
        refresh();
    }

    public void addFilter(Filter filter) {
        ensureSearchOptions();
        this.searchOptions.addFilter(filter);
    }

    public void clearFilters() {
        this.searchOptions.setFilters(null);
    }

    private void ensureSearchOptions() {
        if (this.searchOptions == null) {
            this.searchOptions = new SearchOptions();
        }
    }

    public void showMessage(int message, boolean toast) {
        if (toast) {
            Toast.makeText(getActivity(), getString(message), 0).show();
        } else {
            Snackbar.make(getView(), getString(message), 0).show();
        }
    }

    protected void setContentShown(boolean shown) {
        int i = 0;
        if (this.progressContainer != null && this.contentContainer != null) {
            int i2;
            View view = this.progressContainer;
            if (shown) {
                i2 = 8;
            } else {
                i2 = 0;
            }
            view.setVisibility(i2);
            View view2 = this.contentContainer;
            if (!shown) {
                i = 8;
            }
            view2.setVisibility(i);
        }
    }

    public void navigateToEditForm() {
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == 100) {
            T item = data.getParcelableExtra(Constants.CONTENT);
            if (item != null) {
                setItem(item);
            }
            getActivity().setResult(resultCode, data);
        }
    }

    public void close(boolean shouldRefresh) {
        Activity act = getActivity();
        if (!getResources().getBoolean(C0338R.bool.tabletLayout) || (act instanceof BaseDetailActivity)) {
            Intent data = new Intent();
            data.putExtra(Constants.CONTENT, (Parcelable) (shouldRefresh ? null : getItem()));
            act.setResult(100, data);
            act.finish();
        }
    }

    public T getItem() {
        return this.item;
    }

    public Datasource<T> getDatasource() {
        return null;
    }

    protected void onShow(T t) {
    }
}
