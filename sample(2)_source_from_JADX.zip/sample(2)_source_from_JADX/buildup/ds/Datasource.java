package buildup.ds;

import buildup.ui.Filterable;
import java.util.List;

public interface Datasource<T> extends Filterable {

    public interface Listener<RESULT> {
        void onFailure(Exception exception);

        void onSuccess(RESULT result);
    }

    void getItem(String str, Listener<T> listener);

    void getItems(Listener<List<T>> listener);
}
