package buildup.ds;

public interface Cache {
    void invalidate();
}
