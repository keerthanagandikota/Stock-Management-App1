package buildup.ds;

import buildup.ds.Datasource.Listener;
import java.util.List;

public interface Distinct {
    void getUniqueValuesFor(String str, Listener<List<String>> listener);
}
