package buildup.ds;

public interface Count {
    int getCount();
}
