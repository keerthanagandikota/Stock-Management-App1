package buildup.ds;

import buildup.ds.Datasource.Listener;
import java.util.List;

public interface ForceRefreshDatasource<T> extends Pagination<T> {
    void getItems(int i, boolean z, Listener<List<T>> listener);
}
