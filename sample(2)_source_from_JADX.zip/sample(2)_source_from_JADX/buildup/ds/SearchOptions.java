package buildup.ds;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import buildup.ds.filter.Filter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class SearchOptions implements Parcelable {
    public static final Creator<SearchOptions> CREATOR;
    private List<Filter> filters;
    private List<Filter> fixedFilters;
    private String searchText;
    private boolean sortAscending;
    private String sortColumn;
    private Comparator sortComparator;

    /* renamed from: buildup.ds.SearchOptions.1 */
    static class C03501 implements Creator<SearchOptions> {
        C03501() {
        }

        public SearchOptions createFromParcel(Parcel in) {
            return new SearchOptions(in);
        }

        public SearchOptions[] newArray(int size) {
            return new SearchOptions[size];
        }
    }

    public static class Builder {
        private List<Filter> filters;
        private List<Filter> fixedFilters;
        private String searchText;
        private boolean sortAscending;
        private String sortColumn;
        private Comparator sortComparator;

        public Builder() {
            this.filters = new ArrayList();
            this.fixedFilters = new ArrayList();
        }

        public static Builder searchOptions() {
            return new Builder();
        }

        public Builder withSearchText(String searchText) {
            this.searchText = searchText;
            return this;
        }

        public Builder withSortColumn(String sortColumn) {
            this.sortColumn = sortColumn;
            return this;
        }

        public Builder withSortComparator(Comparator sortComparator) {
            this.sortComparator = sortComparator;
            return this;
        }

        public Builder withSortAscending(boolean sortAscending) {
            this.sortAscending = sortAscending;
            return this;
        }

        public Builder withFilters(List<Filter> filters) {
            this.filters.clear();
            this.filters.addAll(filters);
            return this;
        }

        public Builder withFixedFilters(List<Filter> fixedFilters) {
            this.fixedFilters.clear();
            this.fixedFilters.addAll(fixedFilters);
            return this;
        }

        public SearchOptions build() {
            return new SearchOptions();
        }
    }

    public SearchOptions() {
        this.filters = new ArrayList();
        this.fixedFilters = new ArrayList();
    }

    public SearchOptions(String searchText, String sortColumn, Comparator sortComparator, boolean sortAscending) {
        this.filters = new ArrayList();
        this.fixedFilters = new ArrayList();
        this.searchText = searchText;
        this.sortColumn = sortColumn;
        this.sortComparator = sortComparator;
        this.sortAscending = sortAscending;
    }

    private SearchOptions(Builder builder) {
        this.filters = new ArrayList();
        this.fixedFilters = new ArrayList();
        this.searchText = builder.searchText;
        this.sortColumn = builder.sortColumn;
        this.sortComparator = builder.sortComparator;
        this.sortAscending = builder.sortAscending;
        this.filters = builder.filters;
        this.fixedFilters = builder.fixedFilters;
    }

    public String getSearchText() {
        return this.searchText;
    }

    public void setSearchText(String searchText) {
        this.searchText = searchText;
    }

    public Comparator getSortComparator() {
        return this.sortComparator;
    }

    public String getSortColumn() {
        return this.sortColumn;
    }

    public boolean isSortAscending() {
        return this.sortAscending;
    }

    public void addFilter(Filter filter) {
        if (this.filters == null) {
            this.filters = new ArrayList();
        }
        this.filters.add(filter);
    }

    public List<Filter> getFilters() {
        return this.filters;
    }

    public void setFilters(List<Filter> filters) {
        this.filters = filters;
    }

    public List<Filter> getFixedFilters() {
        return this.fixedFilters;
    }

    protected SearchOptions(Parcel in) {
        this.filters = new ArrayList();
        this.fixedFilters = new ArrayList();
        this.searchText = in.readString();
        this.sortColumn = in.readString();
        this.sortAscending = in.readByte() != null;
        if (in.readByte() == (byte) 1) {
            this.filters = new ArrayList();
            in.readList(this.filters, Filter.class.getClassLoader());
        } else {
            this.filters = null;
        }
        if (in.readByte() == (byte) 1) {
            this.fixedFilters = new ArrayList();
            in.readList(this.fixedFilters, Filter.class.getClassLoader());
            return;
        }
        this.fixedFilters = null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.searchText);
        dest.writeString(this.sortColumn);
        dest.writeByte((byte) (this.sortAscending ? 1 : 0));
        if (this.filters == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeList(this.filters);
        }
        if (this.fixedFilters == null) {
            dest.writeByte((byte) 0);
            return;
        }
        dest.writeByte((byte) 1);
        dest.writeList(this.fixedFilters);
    }

    static {
        CREATOR = new C03501();
    }
}
