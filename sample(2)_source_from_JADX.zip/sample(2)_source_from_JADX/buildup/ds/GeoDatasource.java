package buildup.ds;

public interface GeoDatasource {
}
