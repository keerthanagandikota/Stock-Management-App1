package buildup.ds.filter;

import android.os.Parcelable;

public interface Filter<T> extends Parcelable {
    boolean applyFilter(T t);

    String getField();

    String getQueryString();
}
