package buildup.ds.filter;

public interface IdentityFilter<T> extends Filter<T> {
    T getValue();
}
