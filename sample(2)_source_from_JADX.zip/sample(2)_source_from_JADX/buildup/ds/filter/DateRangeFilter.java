package buildup.ds.filter;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateRangeFilter implements RangeFilter<Date>, Parcelable {
    public static final Creator<DateRangeFilter> CREATOR;
    private String field;
    private Date max;
    private Date min;

    /* renamed from: buildup.ds.filter.DateRangeFilter.1 */
    static class C03511 implements Creator<DateRangeFilter> {
        C03511() {
        }

        public DateRangeFilter createFromParcel(Parcel in) {
            return new DateRangeFilter(in);
        }

        public DateRangeFilter[] newArray(int size) {
            return new DateRangeFilter[size];
        }
    }

    public DateRangeFilter(String field, Date min, Date max) {
        this.field = field;
        this.max = max;
        this.min = min;
    }

    public String getField() {
        return this.field;
    }

    public String getQueryString() {
        if (this.min == null && this.max == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder().append("\"").append(this.field).append("\":");
        sb.append("{");
        if (this.min != null) {
            sb.append("\"$gte\":").append(dateToISO(this.min));
        }
        if (this.max != null) {
            if (this.min != null) {
                sb.append(",");
            }
            sb.append("\"$lte\":").append(dateToISO(this.max));
        }
        sb.append("}");
        return sb.toString();
    }

    public boolean applyFilter(Date fieldValue) {
        if (fieldValue == null) {
            return false;
        }
        Calendar cal = Calendar.getInstance();
        cal.setTime(fieldValue);
        if (this.min != null) {
            Calendar minCal = Calendar.getInstance();
            minCal.setTime(this.min);
            if (!cal.after(minCal)) {
                return false;
            }
        }
        if (this.max != null) {
            Calendar maxCal = Calendar.getInstance();
            maxCal.setTime(this.max);
            if (!cal.before(maxCal)) {
                return false;
            }
        }
        return true;
    }

    public Date getMin() {
        return this.min;
    }

    public Date getMax() {
        return this.max;
    }

    private String dateToISO(Date date) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return "\"" + format.format(date) + "\"";
    }

    protected DateRangeFilter(Parcel in) {
        Date date;
        Date date2 = null;
        this.field = in.readString();
        long tmpMin = in.readLong();
        if (tmpMin != -1) {
            date = new Date(tmpMin);
        } else {
            date = null;
        }
        this.min = date;
        long tmpMax = in.readLong();
        if (tmpMax != -1) {
            date2 = new Date(tmpMax);
        }
        this.max = date2;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        long time;
        long j = -1;
        dest.writeString(this.field);
        if (this.min != null) {
            time = this.min.getTime();
        } else {
            time = -1;
        }
        dest.writeLong(time);
        if (this.max != null) {
            j = this.max.getTime();
        }
        dest.writeLong(j);
    }

    static {
        CREATOR = new C03511();
    }
}
