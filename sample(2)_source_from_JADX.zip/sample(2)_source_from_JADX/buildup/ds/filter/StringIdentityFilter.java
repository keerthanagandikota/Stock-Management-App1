package buildup.ds.filter;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class StringIdentityFilter implements IdentityFilter<String>, Parcelable {
    public static final Creator<StringIdentityFilter> CREATOR;
    private String field;
    private String value;

    /* renamed from: buildup.ds.filter.StringIdentityFilter.1 */
    static class C03551 implements Creator<StringIdentityFilter> {
        C03551() {
        }

        public StringIdentityFilter createFromParcel(Parcel in) {
            return new StringIdentityFilter(in);
        }

        public StringIdentityFilter[] newArray(int size) {
            return new StringIdentityFilter[size];
        }
    }

    public StringIdentityFilter(String field, String value) {
        this.field = field;
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }

    public String getField() {
        return this.field;
    }

    public String getQueryString() {
        return "\"" + this.field + "\":{\"$eq\":" + this.value + "}";
    }

    public boolean applyFilter(String fieldValue) {
        return this.value == null || (fieldValue != null && fieldValue.equalsIgnoreCase(this.value));
    }

    protected StringIdentityFilter(Parcel in) {
        this.field = in.readString();
        this.value = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.field);
        dest.writeString(this.value);
    }

    static {
        CREATOR = new C03551();
    }
}
