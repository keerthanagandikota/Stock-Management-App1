package buildup.ds.filter;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.regex.Pattern;

public class RegularExpFilter implements Filter<String>, Parcelable {
    public static final Creator<RegularExpFilter> CREATOR;
    private String field;
    private String value;

    /* renamed from: buildup.ds.filter.RegularExpFilter.1 */
    static class C03531 implements Creator<RegularExpFilter> {
        C03531() {
        }

        public RegularExpFilter createFromParcel(Parcel in) {
            return new RegularExpFilter(in);
        }

        public RegularExpFilter[] newArray(int size) {
            return new RegularExpFilter[size];
        }
    }

    public RegularExpFilter(String field, String value) {
        this.field = field;
        this.value = value;
    }

    public String getField() {
        return this.field;
    }

    public String getQueryString() {
        if (this.value == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("\"").append(this.field).append("\":{\"$regex\":\"").append(this.value).append("\",\"$options\":\"i\"}");
        return sb.toString();
    }

    public boolean applyFilter(String fieldValue) {
        return Pattern.compile(this.value).matcher(fieldValue).matches();
    }

    protected RegularExpFilter(Parcel in) {
        this.field = in.readString();
        this.value = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.field);
        dest.writeString(this.value);
    }

    static {
        CREATOR = new C03531();
    }
}
