package buildup.ds.filter;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class StringFilter implements ContainsFilter, Parcelable {
    public static final Creator<StringFilter> CREATOR;
    private final String field;
    private final String value;

    /* renamed from: buildup.ds.filter.StringFilter.1 */
    static class C03541 implements Creator<StringFilter> {
        C03541() {
        }

        public StringFilter createFromParcel(Parcel in) {
            return new StringFilter(in);
        }

        public StringFilter[] newArray(int size) {
            return new StringFilter[size];
        }
    }

    public StringFilter(String field, String value) {
        this.field = field;
        this.value = value;
    }

    public String getField() {
        return this.field;
    }

    public String getQueryString() {
        if (this.value == null) {
            return null;
        }
        return "\"" + this.field + "\":{\"$regex\":\"" + this.value + "\",\"$options\":\"i\"}";
    }

    public boolean applyFilter(String fieldValue) {
        return this.value == null || (fieldValue != null && fieldValue.toLowerCase().contains(this.value.toLowerCase()));
    }

    public String getValue() {
        return this.value;
    }

    protected StringFilter(Parcel in) {
        this.value = in.readString();
        this.field = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.value);
        dest.writeString(this.field);
    }

    static {
        CREATOR = new C03541();
    }
}
