package buildup.ds.filter;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

public class StringListFilter implements InFilter<String>, Parcelable {
    public static final Creator<StringListFilter> CREATOR;
    private String field;
    private List<String> values;

    /* renamed from: buildup.ds.filter.StringListFilter.1 */
    static class C03561 implements Creator<StringListFilter> {
        C03561() {
        }

        public StringListFilter createFromParcel(Parcel in) {
            return new StringListFilter(in);
        }

        public StringListFilter[] newArray(int size) {
            return new StringListFilter[size];
        }
    }

    public StringListFilter(String field, List<String> values) {
        this.field = field;
        this.values = values;
    }

    public String getField() {
        return this.field;
    }

    public String getQueryString() {
        if (this.values == null) {
            return null;
        }
        return "\"" + this.field + "\":{\"$in\":[\"" + TextUtils.join("\", \"", this.values) + "\"]}";
    }

    public boolean applyFilter(String fieldValue) {
        return this.values == null || this.values.isEmpty() || this.values.contains(fieldValue);
    }

    public List<String> getValues() {
        return this.values;
    }

    protected StringListFilter(Parcel in) {
        this.field = in.readString();
        if (in.readByte() == 1) {
            this.values = new ArrayList();
            in.readList(this.values, String.class.getClassLoader());
            return;
        }
        this.values = null;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.field);
        if (this.values == null) {
            dest.writeByte((byte) 0);
            return;
        }
        dest.writeByte((byte) 1);
        dest.writeList(this.values);
    }

    static {
        CREATOR = new C03561();
    }
}
