package buildup.ds.filter;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class NumberFilter implements IdentityFilter<Number>, Parcelable {
    public static final Creator<NumberFilter> CREATOR;
    private final String field;
    private final Number value;

    /* renamed from: buildup.ds.filter.NumberFilter.1 */
    static class C03521 implements Creator<NumberFilter> {
        C03521() {
        }

        public NumberFilter createFromParcel(Parcel in) {
            return new NumberFilter(in);
        }

        public NumberFilter[] newArray(int size) {
            return new NumberFilter[size];
        }
    }

    public NumberFilter(String field, Number value) {
        this.field = field;
        this.value = value;
    }

    public String getField() {
        return this.field;
    }

    public String getQueryString() {
        if (this.value == null) {
            return null;
        }
        return "\"" + this.field + "\":{\"$eq\":" + this.value + "}";
    }

    public boolean applyFilter(Number fieldValue) {
        return this.value == null || this.value.equals(fieldValue);
    }

    public Number getValue() {
        return this.value;
    }

    protected NumberFilter(Parcel in) {
        this.value = (Number) in.readValue(Number.class.getClassLoader());
        this.field = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.value);
        dest.writeString(this.field);
    }

    static {
        CREATOR = new C03521();
    }
}
