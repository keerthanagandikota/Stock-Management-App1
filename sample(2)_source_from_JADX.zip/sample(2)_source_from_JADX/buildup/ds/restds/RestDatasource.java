package buildup.ds.restds;

import android.text.TextUtils;
import android.util.Base64;
import buildup.ds.Datasource;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import buildup.gson.DateJsonTypeAdapter;
import buildup.gson.DecimalJsonTypeAdapter;
import buildup.gson.IntegerJsonTypeAdapter;
import buildup.gson.URLJsonTypeAdapter;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.GsonBuilder;
import com.squareup.okhttp.OkHttpClient;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import retrofit.RequestInterceptor;
import retrofit.RequestInterceptor.RequestFacade;
import retrofit.RestAdapter.Builder;
import retrofit.RestAdapter.LogLevel;
import retrofit.client.Client;
import retrofit.client.OkClient;
import retrofit.converter.Converter;
import retrofit.converter.GsonConverter;

public abstract class RestDatasource<T, R> implements Datasource<T> {
    private Converter converter;
    protected SearchOptions searchOptions;
    private Class<R> serviceInterface;
    private R serviceProxy;

    /* renamed from: buildup.ds.restds.RestDatasource.1 */
    class C03581 implements RequestInterceptor {
        C03581() {
        }

        public void intercept(RequestFacade request) {
            request.addHeader("Authorization", "Basic " + Base64.encodeToString((RestDatasource.this.getAppId() + ":" + RestDatasource.this.getApiKey()).getBytes(), 2));
            String token = RestDatasource.this.getToken();
            if (token != null) {
                request.addHeader("UserToken", token);
            }
        }
    }

    public abstract String getServerUrl();

    public RestDatasource(Class<R> clazz, SearchOptions searchOptions) {
        this.serviceInterface = clazz;
        this.searchOptions = searchOptions;
    }

    public void onSearchTextChanged(String s) {
        this.searchOptions.setSearchText(s);
    }

    public void addFilter(Filter filter) {
        this.searchOptions.addFilter(filter);
    }

    public void clearFilters() {
        this.searchOptions.setFilters(null);
    }

    protected R getServiceProxy() {
        if (this.serviceProxy == null) {
            this.serviceProxy = createRestAdapterBuilder().build().create(this.serviceInterface);
        }
        return this.serviceProxy;
    }

    public void setServiceInterface(Class clazz) {
        this.serviceInterface = clazz;
    }

    protected Converter createConverter() {
        return new GsonConverter(new GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).registerTypeAdapter(Integer.class, new IntegerJsonTypeAdapter()).registerTypeAdapter(Double.class, new DecimalJsonTypeAdapter()).registerTypeAdapter(Date.class, new DateJsonTypeAdapter()).registerTypeAdapter(URL.class, new URLJsonTypeAdapter()).create());
    }

    protected Converter getConverter() {
        if (this.converter == null) {
            this.converter = createConverter();
        }
        return this.converter;
    }

    protected Builder createRestAdapterBuilder() {
        Builder builder = new Builder().setClient(getClient()).setEndpoint(getServerUrl()).setConverter(getConverter()).setLogLevel(getLogLevel());
        if (getApiKey() != null) {
            builder.setRequestInterceptor(new C03581());
        }
        return builder;
    }

    protected String getFilterQuery(SearchOptions options) {
        ArrayList<String> conditions = new ArrayList();
        addFilters(conditions, options.getFixedFilters());
        addFilters(conditions, options.getFilters());
        if (conditions.size() > 0) {
            return "[" + TextUtils.join(",", conditions) + "]";
        }
        return null;
    }

    private void addFilters(ArrayList<String> exps, List<Filter> filters) {
        if (filters != null) {
            for (Filter filter : filters) {
                String qs = filter.getQueryString();
                if (qs != null) {
                    exps.add("{" + qs + "}");
                }
            }
        }
    }

    protected LogLevel getLogLevel() {
        return LogLevel.NONE;
    }

    protected Client getClient() {
        OkHttpClient c = new OkHttpClient();
        c.setConnectTimeout(getHttpClientTimeout(), TimeUnit.SECONDS);
        return new OkClient(c);
    }

    protected String getApiKey() {
        return null;
    }

    protected String getAppId() {
        return null;
    }

    protected String getToken() {
        return null;
    }

    protected String getUserId() {
        return null;
    }

    protected long getHttpClientTimeout() {
        return 5;
    }
}
