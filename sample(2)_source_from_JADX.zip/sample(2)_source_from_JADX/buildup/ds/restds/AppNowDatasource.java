package buildup.ds.restds;

import android.text.TextUtils;
import buildup.ds.CrudDatasource;
import buildup.ds.Distinct;
import buildup.ds.GeoDatasource;
import buildup.ds.Pagination;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public abstract class AppNowDatasource<T> implements CrudDatasource<T>, Pagination<T>, Distinct, GeoDatasource {
    protected SearchOptions searchOptions;

    public abstract URL getImageUrl(String str);

    public AppNowDatasource(SearchOptions searchOptions) {
        this.searchOptions = searchOptions;
    }

    public void onSearchTextChanged(String s) {
        this.searchOptions.setSearchText(s);
    }

    public void addFilter(Filter filter) {
        this.searchOptions.addFilter(filter);
    }

    public void clearFilters() {
        this.searchOptions.setFilters(null);
    }

    protected String getConditions(SearchOptions options, String[] searchCols) {
        int i = 0;
        if (options == null) {
            return null;
        }
        ArrayList<String> exps = new ArrayList();
        addFilters(exps, options.getFilters(), false);
        addFilters(exps, options.getFixedFilters(), true);
        String st = options.getSearchText();
        if (!(st == null || searchCols == null || searchCols.length <= 0)) {
            ArrayList<String> searches = new ArrayList();
            int length = searchCols.length;
            while (i < length) {
                searches.add("{\"" + searchCols[i] + "\":{\"$regex\":\"" + st + "\",\"$options\":\"i\"}}");
                i++;
            }
            exps.add("\"$or\":[" + TextUtils.join(",", searches) + "]");
        }
        if (exps.size() > 0) {
            return "{" + TextUtils.join(",", exps) + "}";
        }
        return null;
    }

    private void addFilters(ArrayList<String> exps, List<Filter> filters, boolean fixed) {
        if (filters != null) {
            List<String> filterExps = new ArrayList();
            for (Filter filter : filters) {
                String qs = filter.getQueryString();
                if (qs != null) {
                    filterExps.add(qs);
                }
            }
            if (filterExps.size() <= 0) {
                return;
            }
            if (fixed) {
                exps.add("\"$and\":[{" + TextUtils.join("},{", filterExps) + "}]");
            } else {
                exps.addAll(filterExps);
            }
        }
    }

    protected String getSort(SearchOptions options) {
        if (options == null) {
            return null;
        }
        String col = options.getSortColumn();
        boolean asc = options.isSortAscending();
        if (col == null) {
            return null;
        }
        if (asc) {
            return col;
        }
        return "-" + col;
    }
}
