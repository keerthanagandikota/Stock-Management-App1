package buildup.ds.restds;

import buildup.ds.Datasource;
import buildup.ds.Datasource.Listener;
import buildup.ds.Pagination;
import buildup.ds.SearchOptions;
import buildup.ds.filter.Filter;
import java.net.URL;
import java.util.List;

public abstract class SAPHanaDatasource<T> implements Datasource<T>, Pagination<T> {
    protected SearchOptions searchOptions;

    public abstract URL getImageUrl(String str);

    public abstract void getItems(SearchOptions searchOptions, Listener<List<T>> listener);

    public SAPHanaDatasource(SearchOptions searchOptions) {
        this.searchOptions = searchOptions;
    }

    protected String getSort(SearchOptions options) {
        if (options == null) {
            return null;
        }
        String col = options.getSortColumn();
        boolean asc = options.isSortAscending();
        if (col == null) {
            return null;
        }
        if (asc) {
            return col + " asc";
        }
        return col + " desc";
    }

    public void onSearchTextChanged(String s) {
    }

    public void addFilter(Filter filter) {
    }

    public void clearFilters() {
    }
}
