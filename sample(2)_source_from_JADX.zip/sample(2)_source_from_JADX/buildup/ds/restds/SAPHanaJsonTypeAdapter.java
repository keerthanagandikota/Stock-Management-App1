package buildup.ds.restds;

import com.google.gson.Gson;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class SAPHanaJsonTypeAdapter<T> implements GenericJsonTypeAdapter<T, List<T>> {
    private List<String> dateFields;
    private Class<T> item;

    public SAPHanaJsonTypeAdapter(Class<T> item) {
        this(item, Collections.EMPTY_LIST);
    }

    public SAPHanaJsonTypeAdapter(Class<T> item, List<String> dateFields) {
        this.item = item;
        this.dateFields = dateFields;
    }

    public List<T> deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        Gson gson = new Gson();
        List<T> items = new ArrayList();
        Iterator it = json.getAsJsonObject().get("d").getAsJsonObject().get("results").getAsJsonArray().iterator();
        while (it.hasNext()) {
            JsonElement jsonElement = (JsonElement) it.next();
            if (!this.dateFields.isEmpty()) {
                for (String dateField : this.dateFields) {
                    String date = jsonElement.getAsJsonObject().get(dateField).getAsString();
                    jsonElement.getAsJsonObject().remove(dateField);
                    jsonElement.getAsJsonObject().addProperty(dateField, Long.valueOf(Long.parseLong(date.substring(date.indexOf("(") + 1, date.indexOf(")")))));
                }
            }
            items.add(gson.fromJson(jsonElement, this.item));
        }
        return items;
    }

    public Class<T> getItem() {
        return this.item;
    }
}
