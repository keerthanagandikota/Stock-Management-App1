package buildup.ds.restds;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.gson.annotations.SerializedName;
import java.util.Locale;

public class GeoPoint implements Parcelable {
    public static final Creator<GeoPoint> CREATOR;
    public static final int LATITUDE_INDEX = 1;
    public static final int LONGITUDE_INDEX = 0;
    @SerializedName("coordinates")
    public double[] coordinates;
    @SerializedName("type")
    public String type;

    /* renamed from: buildup.ds.restds.GeoPoint.1 */
    static class C03571 implements Creator<GeoPoint> {
        C03571() {
        }

        public GeoPoint createFromParcel(Parcel in) {
            return new GeoPoint(in);
        }

        public GeoPoint[] newArray(int size) {
            return new GeoPoint[size];
        }
    }

    public GeoPoint() {
        this.type = "Point";
        this.coordinates = new double[]{0.0d, 0.0d};
    }

    public GeoPoint(double lon, double lat) {
        this.type = "Point";
        this.coordinates = new double[]{0.0d, 0.0d};
        this.coordinates[0] = lon;
        this.coordinates[LATITUDE_INDEX] = lat;
    }

    public GeoPoint(double[] coords) {
        this.type = "Point";
        this.coordinates = new double[]{0.0d, 0.0d};
        this.coordinates = coords;
    }

    public String toString() {
        return String.format(Locale.US, "%.8f, %.8f", new Object[]{Double.valueOf(this.coordinates[LATITUDE_INDEX]), Double.valueOf(this.coordinates[0])});
    }

    protected GeoPoint(Parcel in) {
        this.type = "Point";
        this.coordinates = new double[]{0.0d, 0.0d};
        this.type = in.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.type);
    }

    static {
        CREATOR = new C03571();
    }
}
