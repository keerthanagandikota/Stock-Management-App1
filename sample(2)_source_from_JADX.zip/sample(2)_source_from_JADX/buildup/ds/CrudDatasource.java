package buildup.ds;

import buildup.ds.Datasource.Listener;
import java.util.List;

public interface CrudDatasource<T> extends Datasource<T> {
    void create(T t, Listener<T> listener);

    void deleteItem(T t, Listener<T> listener);

    void deleteItems(List<T> list, Listener<T> listener);

    void updateItem(T t, Listener<T> listener);
}
