package buildup.ds;

import android.text.TextUtils;
import android.util.Base64;
import buildup.ds.filter.Filter;
import buildup.gson.DateJsonTypeAdapter;
import buildup.gson.DecimalJsonTypeAdapter;
import buildup.gson.IntegerJsonTypeAdapter;
import buildup.gson.URLJsonTypeAdapter;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import com.squareup.okhttp.OkHttpClient;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import retrofit.RequestInterceptor;
import retrofit.RequestInterceptor.RequestFacade;
import retrofit.RestAdapter;
import retrofit.RestAdapter.Builder;
import retrofit.RestAdapter.LogLevel;
import retrofit.client.Client;
import retrofit.client.OkClient;
import retrofit.converter.Converter;
import retrofit.converter.GsonConverter;

public abstract class RestService<R> {
    private final Class<R> mClass;
    Converter mConverter;
    private R mServiceProxy;

    /* renamed from: buildup.ds.RestService.1 */
    class C03471 implements RequestInterceptor {
        final /* synthetic */ String val$apiKey;

        C03471(String str) {
            this.val$apiKey = str;
        }

        public void intercept(RequestFacade request) {
            request.addHeader("apikey", this.val$apiKey);
        }
    }

    /* renamed from: buildup.ds.RestService.2 */
    class C03482 implements RequestInterceptor {
        final /* synthetic */ String val$pwd;
        final /* synthetic */ String val$user;

        C03482(String str, String str2) {
            this.val$user = str;
            this.val$pwd = str2;
        }

        public void intercept(RequestFacade request) {
            request.addHeader("Authorization", "Basic " + Base64.encodeToString((this.val$user + ":" + this.val$pwd).getBytes(), 2));
        }
    }

    /* renamed from: buildup.ds.RestService.3 */
    class C03493 implements ExclusionStrategy {
        C03493() {
        }

        public boolean shouldSkipField(FieldAttributes f) {
            SerializedName annotation = (SerializedName) f.getAnnotation(SerializedName.class);
            return annotation != null && annotation.value().equals("_id");
        }

        public boolean shouldSkipClass(Class<?> cls) {
            return false;
        }
    }

    public abstract URL getImageUrl(String str);

    public abstract String getServerUrl();

    public RestService(Class<R> clazz) {
        this.mClass = clazz;
    }

    public RestService(Class<R> clazz, Converter converter) {
        this.mClass = clazz;
        this.mConverter = converter;
    }

    public R getServiceProxy() {
        if (this.mServiceProxy == null) {
            this.mServiceProxy = createRestAdapterBuilder().create(this.mClass);
        }
        return this.mServiceProxy;
    }

    protected RestAdapter createRestAdapterBuilder() {
        Builder builder = new Builder().setClient(getClient()).setEndpoint(getServerUrl()).setConverter(getConverter()).setLogLevel(getLogLevel());
        if (tryApiKey(builder) || tryBasicAuth(builder)) {
            return builder.build();
        }
        throw new IllegalArgumentException("AppNow datasource needs an api key or user-pwd pair !");
    }

    protected boolean tryApiKey(Builder builder) {
        String apiKey = getApiKey();
        if (apiKey == null) {
            return false;
        }
        builder.setRequestInterceptor(new C03471(apiKey));
        return true;
    }

    protected boolean tryBasicAuth(Builder builder) {
        String user = getApiUser();
        String pwd = getApiPassword();
        if (user == null || pwd == null) {
            return false;
        }
        builder.setRequestInterceptor(new C03482(user, pwd));
        return true;
    }

    protected String getConditions(SearchOptions options, String[] searchCols) {
        if (options == null) {
            return null;
        }
        ArrayList<String> exps = new ArrayList();
        if (options.getFilters() != null) {
            for (Filter filter : options.getFilters()) {
                String qs = filter.getQueryString();
                if (qs != null) {
                    exps.add(qs);
                }
            }
        }
        String st = options.getSearchText();
        if (!(st == null || searchCols == null || searchCols.length <= 0)) {
            ArrayList<String> searches = new ArrayList();
            for (String col : searchCols) {
                searches.add("{\"" + col + "\":{\"$regex\":\"" + st + "\",\"$options\":\"i\"}}");
            }
            exps.add("\"$or\":[" + TextUtils.join(",", searches) + "]");
        }
        if (exps.size() > 0) {
            return "{" + TextUtils.join(",", exps) + "}";
        }
        return null;
    }

    protected String getSort(SearchOptions options) {
        String col = options.getSortColumn();
        boolean asc = options.isSortAscending();
        if (col == null) {
            return null;
        }
        if (!asc) {
            col = "-" + col;
        }
        return col;
    }

    protected Converter createConverter() {
        return new GsonConverter(new GsonBuilder().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).registerTypeAdapter(Integer.class, new IntegerJsonTypeAdapter()).registerTypeAdapter(Double.class, new DecimalJsonTypeAdapter()).registerTypeAdapter(Date.class, new DateJsonTypeAdapter()).registerTypeAdapter(URL.class, new URLJsonTypeAdapter()).addSerializationExclusionStrategy(new C03493()).create());
    }

    protected Converter getConverter() {
        if (this.mConverter == null) {
            this.mConverter = createConverter();
        }
        return this.mConverter;
    }

    protected LogLevel getLogLevel() {
        return LogLevel.NONE;
    }

    protected Client getClient() {
        OkHttpClient c = new OkHttpClient();
        c.setConnectTimeout(getHttpClientTimeout(), TimeUnit.SECONDS);
        return new OkClient(c);
    }

    protected long getHttpClientTimeout() {
        return 5;
    }

    protected String getApiKey() {
        return null;
    }

    protected String getApiUser() {
        return null;
    }

    protected String getApiPassword() {
        return null;
    }
}
