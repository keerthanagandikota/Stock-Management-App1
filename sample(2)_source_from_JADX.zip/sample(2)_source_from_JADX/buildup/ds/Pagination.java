package buildup.ds;

import buildup.ds.Datasource.Listener;
import java.util.List;

public interface Pagination<T> {
    void getItems(int i, Listener<List<T>> listener);

    int getPageSize();
}
