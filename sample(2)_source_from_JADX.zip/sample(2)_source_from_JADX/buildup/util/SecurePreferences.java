package buildup.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.preference.PreferenceManager;
import android.provider.Settings.Secure;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.Base64;
import android.util.Log;
import buildup.analytics.AnalyticsReporter;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class SecurePreferences implements SharedPreferences {
    public static final String TAG;
    private static SharedPreferences sFile;
    private static byte[] sKey;
    private final AnalyticsReporter analyticsReporter;

    public static class Editor implements android.content.SharedPreferences.Editor {
        private final android.content.SharedPreferences.Editor mEditor;

        private Editor() {
            this.mEditor = SecurePreferences.sFile.edit();
        }

        public android.content.SharedPreferences.Editor putString(String key, String value) {
            this.mEditor.putString(SecurePreferences.encrypt(key), SecurePreferences.encrypt(value));
            return this;
        }

        public android.content.SharedPreferences.Editor putStringSet(String key, Set<String> values) {
            Set<String> encryptedValues = new HashSet(values.size());
            for (String value : values) {
                encryptedValues.add(SecurePreferences.encrypt(value));
            }
            this.mEditor.putStringSet(SecurePreferences.encrypt(key), encryptedValues);
            return this;
        }

        public android.content.SharedPreferences.Editor putInt(String key, int value) {
            this.mEditor.putString(SecurePreferences.encrypt(key), SecurePreferences.encrypt(Integer.toString(value)));
            return this;
        }

        public android.content.SharedPreferences.Editor putLong(String key, long value) {
            this.mEditor.putString(SecurePreferences.encrypt(key), SecurePreferences.encrypt(Long.toString(value)));
            return this;
        }

        public android.content.SharedPreferences.Editor putFloat(String key, float value) {
            this.mEditor.putString(SecurePreferences.encrypt(key), SecurePreferences.encrypt(Float.toString(value)));
            return this;
        }

        public android.content.SharedPreferences.Editor putBoolean(String key, boolean value) {
            this.mEditor.putString(SecurePreferences.encrypt(key), SecurePreferences.encrypt(Boolean.toString(value)));
            return this;
        }

        public android.content.SharedPreferences.Editor remove(String key) {
            this.mEditor.remove(SecurePreferences.encrypt(key));
            return this;
        }

        public android.content.SharedPreferences.Editor clear() {
            this.mEditor.clear();
            return this;
        }

        public boolean commit() {
            return this.mEditor.commit();
        }

        public void apply() {
            this.mEditor.apply();
        }
    }

    static {
        TAG = SecurePreferences.class.getSimpleName();
    }

    public SecurePreferences(Context context) {
        this.analyticsReporter = AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext());
        if (sFile == null) {
            sFile = PreferenceManager.getDefaultSharedPreferences(context);
        }
        try {
            String key = generateAesKeyName(context);
            String value = sFile.getString(key, null);
            if (value == null) {
                value = generateAesKeyValue();
                sFile.edit().putString(key, value).commit();
            }
            sKey = decode(value);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private static String encode(byte[] input) {
        return Base64.encodeToString(input, 3);
    }

    private static byte[] decode(String input) {
        return Base64.decode(input, 3);
    }

    private static String generateAesKeyName(Context context) throws InvalidKeySpecException, NoSuchAlgorithmException {
        return encode(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(new PBEKeySpec(context.getPackageName().toCharArray(), Secure.getString(context.getContentResolver(), "android_id").getBytes(), 1000, AccessibilityNodeInfoCompat.ACTION_NEXT_AT_MOVEMENT_GRANULARITY)).getEncoded());
    }

    private static String generateAesKeyValue() throws NoSuchAlgorithmException {
        SecureRandom random = new SecureRandom();
        KeyGenerator generator = KeyGenerator.getInstance("AES");
        try {
            generator.init(AccessibilityNodeInfoCompat.ACTION_NEXT_AT_MOVEMENT_GRANULARITY, random);
        } catch (Exception e) {
            try {
                generator.init(192, random);
            } catch (Exception e2) {
                generator.init(AccessibilityNodeInfoCompat.ACTION_CLEAR_ACCESSIBILITY_FOCUS, random);
            }
        }
        return encode(generator.generateKey().getEncoded());
    }

    private static String encrypt(String cleartext) {
        if (cleartext == null || cleartext.length() == 0) {
            return cleartext;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(1, new SecretKeySpec(sKey, "AES"));
            return encode(cipher.doFinal(cleartext.getBytes("UTF-8")));
        } catch (Exception e) {
            Log.w(SecurePreferences.class.getName(), "encrypt", e);
            return null;
        }
    }

    private static String decrypt(String ciphertext) {
        if (ciphertext == null || ciphertext.length() == 0) {
            return ciphertext;
        }
        try {
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(2, new SecretKeySpec(sKey, "AES"));
            return new String(cipher.doFinal(decode(ciphertext)), "UTF-8");
        } catch (Exception e) {
            AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException(TAG, "decrypt", e);
            Log.w(TAG, "decrypt", e);
            return null;
        }
    }

    public Map<String, String> getAll() {
        Map<String, ?> encryptedMap = sFile.getAll();
        Map<String, String> decryptedMap = new HashMap(encryptedMap.size());
        for (Entry<String, ?> entry : encryptedMap.entrySet()) {
            try {
                decryptedMap.put(decrypt((String) entry.getKey()), decrypt(entry.getValue().toString()));
            } catch (Exception e) {
                this.analyticsReporter.sendHandledException(TAG, "getAll", e);
            }
        }
        return decryptedMap;
    }

    public String getString(String key, String defaultValue) {
        String encryptedValue = sFile.getString(encrypt(key), null);
        return encryptedValue != null ? decrypt(encryptedValue) : defaultValue;
    }

    public Set<String> getStringSet(String key, Set<String> defaultValues) {
        Set<String> encryptedSet = sFile.getStringSet(encrypt(key), null);
        if (encryptedSet == null) {
            return defaultValues;
        }
        Set<String> decryptedSet = new HashSet(encryptedSet.size());
        for (String encryptedValue : encryptedSet) {
            decryptedSet.add(decrypt(encryptedValue));
        }
        return decryptedSet;
    }

    public int getInt(String key, int defaultValue) {
        String encryptedValue = sFile.getString(encrypt(key), null);
        if (encryptedValue != null) {
            try {
                defaultValue = Integer.parseInt(decrypt(encryptedValue));
            } catch (NumberFormatException e) {
                this.analyticsReporter.sendHandledException(TAG, "getInt", e);
                throw new ClassCastException(e.getMessage());
            }
        }
        return defaultValue;
    }

    public long getLong(String key, long defaultValue) {
        String encryptedValue = sFile.getString(encrypt(key), null);
        if (encryptedValue != null) {
            try {
                defaultValue = Long.parseLong(decrypt(encryptedValue));
            } catch (NumberFormatException e) {
                this.analyticsReporter.sendHandledException(TAG, "getLong", e);
                throw new ClassCastException(e.getMessage());
            }
        }
        return defaultValue;
    }

    public float getFloat(String key, float defaultValue) {
        String encryptedValue = sFile.getString(encrypt(key), null);
        if (encryptedValue != null) {
            try {
                defaultValue = Float.parseFloat(decrypt(encryptedValue));
            } catch (NumberFormatException e) {
                this.analyticsReporter.sendHandledException(TAG, "getFloat", e);
                throw new ClassCastException(e.getMessage());
            }
        }
        return defaultValue;
    }

    public boolean getBoolean(String key, boolean defaultValue) {
        String encryptedValue = sFile.getString(encrypt(key), null);
        if (encryptedValue != null) {
            try {
                defaultValue = Boolean.parseBoolean(decrypt(encryptedValue));
            } catch (NumberFormatException e) {
                this.analyticsReporter.sendHandledException(TAG, "getBoolean", e);
                throw new ClassCastException(e.getMessage());
            }
        }
        return defaultValue;
    }

    public boolean contains(String key) {
        return sFile.contains(encrypt(key));
    }

    public Editor edit() {
        return new Editor();
    }

    public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener listener) {
        sFile.registerOnSharedPreferenceChangeListener(listener);
    }

    public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener listener) {
        sFile.unregisterOnSharedPreferenceChangeListener(listener);
    }
}
