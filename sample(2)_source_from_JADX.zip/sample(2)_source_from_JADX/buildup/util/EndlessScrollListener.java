package buildup.util;

import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;

public abstract class EndlessScrollListener implements OnScrollListener {
    private int currentPage;
    private boolean loading;
    private int startingPageIndex;
    private int visibleThreshold;

    public abstract void onLoadMore(int i, int i2);

    public EndlessScrollListener() {
        this.visibleThreshold = 5;
        this.currentPage = 0;
        this.loading = false;
        this.startingPageIndex = 0;
    }

    public EndlessScrollListener(int visibleThreshold) {
        this.visibleThreshold = 5;
        this.currentPage = 0;
        this.loading = false;
        this.startingPageIndex = 0;
        this.visibleThreshold = visibleThreshold;
    }

    public EndlessScrollListener(int visibleThreshold, int startPage) {
        this.visibleThreshold = 5;
        this.currentPage = 0;
        this.loading = false;
        this.startingPageIndex = 0;
        this.visibleThreshold = visibleThreshold;
        this.startingPageIndex = startPage;
        this.currentPage = startPage;
    }

    public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
        if (totalItemCount <= 1) {
            this.currentPage = this.startingPageIndex;
        } else if (!this.loading && firstVisibleItem + visibleItemCount >= totalItemCount - this.visibleThreshold) {
            this.loading = true;
            int i = this.currentPage + 1;
            this.currentPage = i;
            onLoadMore(i, totalItemCount);
        }
    }

    public void finishLoading() {
        this.loading = false;
    }

    public void onScrollStateChanged(AbsListView view, int scrollState) {
    }
}
