package buildup.util;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import buildup.actions.StartActivityAction;
import buildup.core.C0338R;
import buildup.ui.DetailFragment;

public class NavigationUtils {
    public static void navigateToDetail(Context context, Class activityClass, Class fragmentClass, Bundle args) {
        if (context.getResources().getBoolean(C0338R.bool.tabletLayout) && (context instanceof FragmentActivity)) {
            FragmentManager fragmentManager = ((FragmentActivity) context).getSupportFragmentManager();
            DetailFragment fr = (DetailFragment) fragmentManager.findFragmentById(C0338R.id.detail_frame);
            if (fr == null || !fr.getClass().equals(fragmentClass)) {
                FragmentTransaction replaceTransaction = fragmentManager.beginTransaction();
                replaceTransaction.replace(C0338R.id.detail_frame, FragmentUtils.instantiate(fragmentClass, args));
                replaceTransaction.commit();
                return;
            }
            fr.setItem(args.getParcelable(Constants.CONTENT));
            return;
        }
        Intent intent = new Intent(context, activityClass);
        intent.putExtras(args);
        context.startActivity(intent);
    }

    public static <T> void showAddOrUpdateItem(T item, int position, FragmentActivity activity, Class activityClass) {
        Bundle args = new Bundle();
        args.putInt(Constants.ITEMPOS, position);
        args.putParcelable(Constants.CONTENT, (Parcelable) item);
        int requestCode = item == null ? 2 : 1;
        args.putInt(Constants.MODE, requestCode);
        new StartActivityAction(activityClass, args, requestCode).execute(activity);
    }

    public static <T> Intent generateIntentToDetailOrForm(T item, int position, FragmentActivity activity, Class activityClass) {
        return generateIntentToDetailOrForm(item, position, activity, activityClass, new Parcelable[0]);
    }

    public static <T> Intent generateIntentToDetailOrForm(T item, int position, FragmentActivity activity, Class activityClass, Parcelable[] parameters) {
        Bundle args = new Bundle();
        args.putInt(Constants.ITEMPOS, position);
        args.putParcelable(Constants.CONTENT, (Parcelable) item);
        for (Parcelable param : parameters) {
            args.putParcelable(param.getClass().getName(), param);
        }
        Intent intent = new Intent(activity, activityClass);
        intent.putExtras(args);
        return intent;
    }
}
