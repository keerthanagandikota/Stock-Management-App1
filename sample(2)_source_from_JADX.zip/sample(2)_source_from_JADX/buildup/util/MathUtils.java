package buildup.util;

public class MathUtils {
    public static int getOrderOfMagnitude(int range) {
        int mag = 1;
        for (int aux = range; aux > 10; aux /= 10) {
            mag *= 10;
        }
        return mag;
    }
}
