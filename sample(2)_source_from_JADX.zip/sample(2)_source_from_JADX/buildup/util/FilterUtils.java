package buildup.util;

import android.content.Context;
import android.text.format.DateFormat;
import android.util.Log;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.ds.filter.Filter;
import buildup.injectors.ApplicationInjector;
import java.util.Date;
import java.util.List;

public class FilterUtils {
    public static int compareString(Object o1, Object o2) {
        if (o1 == null || o2 == null) {
            return 0;
        }
        return ((String) o1).compareToIgnoreCase((String) o2);
    }

    public static int compareDouble(Double d1, Double d2) {
        if (d1 == null || d2 == null) {
            return 0;
        }
        return d1.compareTo(d2);
    }

    public static int compareInteger(Integer i1, Integer i2) {
        if (i1 == null || i2 == null) {
            return 0;
        }
        return i1.compareTo(i2);
    }

    public static int compareDate(Context context, Object o1, Object o2) {
        if (o1 == null || o2 == null) {
            return 0;
        }
        try {
            return DateFormat.getMediumDateFormat(context).parse((String) o1).compareTo(DateFormat.getMediumDateFormat(context).parse((String) o2));
        } catch (Exception e) {
            AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("FilterUtils", "Parse Error", e);
            Log.e("ParseError", e.getMessage());
            return 0;
        }
    }

    public static boolean searchInString(String columnText, String filterText) {
        if (columnText == null || filterText == null) {
            return false;
        }
        return columnText.toLowerCase().contains(filterText.toLowerCase());
    }

    public static boolean searchInDouble(Double columnText, String filterText) {
        if (columnText == null || filterText == null) {
            return false;
        }
        return columnText.toString().toLowerCase().contains(filterText.toLowerCase());
    }

    public static boolean searchInDate(Date columnText, String filterText) {
        if (columnText == null || filterText == null) {
            return false;
        }
        return columnText.toString().toLowerCase().contains(filterText.toLowerCase());
    }

    public static boolean applyFilters(String name, Object value, List<Filter> filters) {
        if (filters != null) {
            for (Filter filter : filters) {
                if (filter.getField().equals(name) && !filter.applyFilter(value)) {
                    return false;
                }
            }
        }
        return true;
    }
}
