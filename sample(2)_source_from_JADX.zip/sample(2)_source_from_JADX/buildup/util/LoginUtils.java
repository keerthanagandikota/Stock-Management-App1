package buildup.util;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import org.apache.http.HttpResponse;
import org.json.JSONException;
import org.json.JSONObject;

public class LoginUtils {
    public static String EXPIRATION_TIME;
    public static String LAST_USER;
    public static long NEVER_EXPIRES;
    public static long SESSION_EXPIRED;
    public static String SUSPENDED_DATE;
    public static String TOKEN;

    static {
        SUSPENDED_DATE = "suspendedDate";
        EXPIRATION_TIME = "expirationTime";
        LAST_USER = "lastUser";
        TOKEN = "token";
        NEVER_EXPIRES = 0;
        SESSION_EXPIRED = -1;
    }

    public static void checkLoggedStatus(SecurePreferences mSharedPreferences, Class loginActivity, Activity activity) {
        Long mins = Long.valueOf((Long.valueOf(System.currentTimeMillis()).longValue() - Long.valueOf(mSharedPreferences.getLong(SUSPENDED_DATE, 0)).longValue()) / 60000);
        Long expirationTime = Long.valueOf(mSharedPreferences.getLong(EXPIRATION_TIME, SESSION_EXPIRED));
        if (expirationTime.longValue() != NEVER_EXPIRES && mins.longValue() >= expirationTime.longValue()) {
            Intent goToLogin = new Intent(activity, loginActivity);
            goToLogin.addFlags(1409286144);
            activity.startActivity(goToLogin);
            activity.finish();
        }
    }

    public static void storeLastActiveStatus(SecurePreferences mSharedPreferences) {
        mSharedPreferences.edit().putLong(SUSPENDED_DATE, System.currentTimeMillis()).commit();
    }

    public static void logOut(SecurePreferences mSharedPreferences, Class loginActivity, Activity activity) {
        mSharedPreferences.edit().putLong(EXPIRATION_TIME, SESSION_EXPIRED).commit();
        Intent goToLogin = new Intent(activity, loginActivity);
        goToLogin.addFlags(1409286144);
        activity.startActivity(goToLogin);
        activity.finish();
    }

    public static String getResponseString(HttpResponse response) {
        String res = null;
        try {
            res = new BufferedReader(new InputStreamReader(response.getEntity().getContent(), "UTF-8")).readLine();
        } catch (IOException e) {
            logException(e);
        }
        return res;
    }

    public static JSONObject parseJSON(String responseString) {
        try {
            return new JSONObject(responseString);
        } catch (JSONException e) {
            logException(e);
            return null;
        }
    }

    private static void logException(Exception e) {
        AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("LoginUtils", "getResponseString", e);
        Log.e("getResponseString", e.getMessage());
    }
}
