package buildup.util;

import android.util.SparseArray;
import android.view.View;
import android.widget.Checkable;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewHolder {
    public static <T extends View> T get(View view, int id) {
        SparseArray<View> viewHolder = (SparseArray) view.getTag();
        if (viewHolder == null) {
            viewHolder = new SparseArray();
            view.setTag(viewHolder);
        }
        View childView = (View) viewHolder.get(id);
        if (childView == null) {
            childView = view.findViewById(id);
            viewHolder.put(id, childView);
        }
        resetView(childView);
        return childView;
    }

    private static void resetView(View view) {
        if (view instanceof TextView) {
            ((TextView) view).setText(null);
        } else if (!(view instanceof ImageButton)) {
            if (view instanceof ImageView) {
                ((ImageView) view).setImageDrawable(null);
            }
        } else {
            return;
        }
        if (view instanceof Checkable) {
            ((Checkable) view).setChecked(false);
        }
    }
}
