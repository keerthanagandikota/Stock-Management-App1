package buildup.util;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;

public class FragmentUtils {
    private static final String TAG;

    static {
        TAG = FragmentUtils.class.getSimpleName();
    }

    public static Fragment instantiate(Class<? extends Fragment> clazz, Bundle defaults) {
        try {
            return (Fragment) clazz.getMethod("newInstance", new Class[]{Bundle.class}).invoke(null, new Object[]{defaults});
        } catch (Exception e) {
            AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("FragmentUtils", "Exception instantiating the fragment [" + clazz.getName() + "]", e);
            Log.d(TAG, "Exception instantiating the fragment [" + clazz.getName() + "]");
            throw new IllegalArgumentException("Couldn't instantie fragment: + clazz.getName()", e);
        }
    }
}
