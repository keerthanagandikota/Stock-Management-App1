package buildup.util;

public interface Constants {
    public static final String CONTENT = "content";
    public static final int CONTENT_NOT_UPDATED = 101;
    public static final int CONTENT_UPDATED = 100;
    public static final int DETAIL = 3;
    public static final String ITEMPOS = "itempos";
    public static final String MODE = "mode";
    public static final int MODE_CREATE = 2;
    public static final int MODE_EDIT = 1;
    public static final String SIZE = "size";
    public static final String TITLE = "title";
}
