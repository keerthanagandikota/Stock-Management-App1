package buildup.util;

import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;
import io.buildup.pkg20170504080645.BuildConfig;
import java.text.FieldPosition;
import java.text.Format;
import java.text.ParsePosition;
import java.util.List;

public class StringLabelFormat extends Format {
    public List<String> labels;

    public StringLabelFormat(List<String> xValues) {
        this.labels = xValues;
    }

    public StringBuffer format(Object object, StringBuffer buffer, FieldPosition field) {
        int parsedInt = Math.round(Float.parseFloat(object.toString()));
        String labelString = BuildConfig.FLAVOR;
        try {
            labelString = (String) this.labels.get(parsedInt);
        } catch (IndexOutOfBoundsException e) {
            AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("StringLabelFormat", "format", e);
        }
        if (labelString.length() > 9) {
            labelString = labelString.substring(0, 6) + "...";
        }
        buffer.append(labelString);
        return buffer;
    }

    public Object parseObject(String string, ParsePosition position) {
        return Integer.valueOf(this.labels.indexOf(string));
    }
}
