package buildup.util;

import android.content.Context;
import android.graphics.PorterDuff.Mode;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;

public class ColorUtils {
    private static final String[] PALETTE_DEFAULT;

    static {
        PALETTE_DEFAULT = new String[]{"#17B9ED", "#1992B8", "#31D755", "#EDE66D", "#F4C745", "#E88E38", "#EA4C26", "#FC6CBC", "#E94A86", "#C230D8", "#9A1CF5", "#733BC7", "#8551F3", "#5E4FDE", "#4A3DBD", "#173791", "#32769A", "#30A198", "#26BBAF", "#379B7D", "#7DB324", "#A0D743", "#A3A153", "#B69042", "#EFAC57", "#EF5E57", "#FC8599", "#DD6C6C", "#4D5EFF", "#24DDEB"};
    }

    public static String[] getDefaultPalette() {
        return PALETTE_DEFAULT;
    }

    public static void tintIcon(MenuItem item, int resId, Context context) {
        tintIcon(item.getIcon(), resId, context);
    }

    public static void tintIcon(Drawable drawable, int resId, Context context) {
        if (drawable != null && context != null) {
            drawable.mutate();
            drawable.setColorFilter(context.getResources().getColor(resId), Mode.SRC_IN);
        }
    }
}
