package buildup.util;

import android.support.annotation.Nullable;
import android.util.Log;
import buildup.analytics.AnalyticsReporter;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.core.C0338R;
import buildup.ds.restds.GeoPoint;
import buildup.injectors.ApplicationInjector;
import buildup.injectors.GsonInjector;
import io.buildup.pkg20170504080645.BuildConfig;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class StringUtils {
    private static final AnalyticsReporter ANALYTICS_REPORTER;
    private static final String TAG;

    static {
        TAG = StringUtils.class.getSimpleName();
        ANALYTICS_REPORTER = AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext());
    }

    public static String firstNChars(String theString, int nChars, boolean ellipsize) {
        if (theString == null) {
            return null;
        }
        return theString.substring(0, theString.length() > nChars ? nChars : theString.length() - 1) + (ellipsize ? " ..." : BuildConfig.FLAVOR);
    }

    public static String removeImgTag(String input) {
        return input.replaceAll("<img.+?>", BuildConfig.FLAVOR);
    }

    public static Number StringToNumber(Object num) {
        if (num == null) {
            return null;
        }
        if (num instanceof Number) {
            return (Number) num;
        }
        Number res = null;
        try {
            if (num instanceof String) {
                res = Float.valueOf(Float.parseFloat((String) num));
            }
        } catch (NumberFormatException e) {
            ANALYTICS_REPORTER.sendHandledException(TAG, "Error parsing string to number", e);
            Log.d("Parsing Error", "Error parsing string to number " + e.getMessage());
        }
        return res;
    }

    public static Date parseDateTime(String date) {
        Date res = null;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.getDefault());
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            res = df.parse(date);
        } catch (ParseException e) {
            ANALYTICS_REPORTER.sendHandledException(TAG, "Parse Error while parsing Date", e);
            Log.e("ParseError", e.getMessage());
        }
        return res;
    }

    public static Date parseDate(String date) {
        Date res = null;
        DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        df.setTimeZone(TimeZone.getTimeZone("UTC"));
        try {
            res = df.parse(date);
        } catch (ParseException e) {
            ANALYTICS_REPORTER.sendHandledException(TAG, "Parse Error while parsing Date", e);
            Log.e("ParseError", e.getMessage());
        }
        return res;
    }

    public static String monthName(int month) {
        Calendar cal = Calendar.getInstance();
        try {
            cal.set(2, month);
            return new SimpleDateFormat("MMM").format(cal.getTime());
        } catch (Exception e) {
            ANALYTICS_REPORTER.sendHandledException(TAG, "monthName", e);
            return null;
        }
    }

    public static String doubleToString(Double val, boolean removeTrailingZeroes) {
        if (val == null) {
            return null;
        }
        String res = val.toString();
        if (removeTrailingZeroes) {
            return res.replaceAll("\\.0*$", BuildConfig.FLAVOR);
        }
        return res;
    }

    public static String intToString(Number val) {
        if (val == null) {
            return null;
        }
        return val.toString();
    }

    public static Long parseLong(String value) {
        if (value != null) {
            try {
                if (value.length() != 0) {
                    return Long.valueOf(Long.parseLong(value.toString()));
                }
            } catch (NumberFormatException e) {
                ANALYTICS_REPORTER.sendHandledException(TAG, "parseLong", e);
                return null;
            }
        }
        return null;
    }

    public static Double parseDouble(String value) {
        if (value != null) {
            try {
                if (value.length() != 0) {
                    return Double.valueOf(Double.parseDouble(value.toString()));
                }
            } catch (NumberFormatException e) {
                ANALYTICS_REPORTER.sendHandledException(TAG, "parseDouble", e);
                return null;
            }
        }
        return null;
    }

    public static String booleanToString(Boolean value) {
        if (value == null) {
            return BuildConfig.FLAVOR;
        }
        return value.booleanValue() ? "Yes" : "No";
    }

    public static GeoPoint parseGeopoint(String geopointJson) {
        return (GeoPoint) GsonInjector.cloudantGson().fromJson(geopointJson, GeoPoint.class);
    }

    @Nullable
    public static URL parseUrl(String value) {
        try {
            return new URL(value);
        } catch (MalformedURLException e) {
            ANALYTICS_REPORTER.sendHandledException(TAG, "parseUrl", e);
            return null;
        }
    }

    @Nullable
    public static URL parseUrl(String baseUrl, String url, String qs) {
        if (url == null) {
            return null;
        }
        if (url.startsWith("http://") || url.startsWith("https://")) {
            return parseUrl(url);
        }
        if (baseUrl == null) {
            return null;
        }
        String postfix;
        if (qs != null) {
            postfix = (url.indexOf(63) >= 0 ? "&" : "?") + qs;
        } else {
            postfix = BuildConfig.FLAVOR;
        }
        if (baseUrl.endsWith("/")) {
            baseUrl = baseUrl.substring(0, baseUrl.length());
        }
        return parseUrl(baseUrl + url + postfix);
    }

    public static URL parseUrl(URL url) {
        return url;
    }

    public static boolean isEmptyOrNull(String text) {
        return text == null || text.isEmpty();
    }

    public static boolean isNotEmptyOrNull(String text) {
        return !isEmptyOrNull(text);
    }

    public static ArrayList<String> replaceNullOrEmptyByText(List<String> values) {
        if (values != null && values.size() > 0) {
            int i = 0;
            while (i < values.size()) {
                if (values.get(i) == null || ((String) values.get(i)).equals(BuildConfig.FLAVOR)) {
                    values.set(i, ApplicationInjector.getApplicationContext().getString(C0338R.string.select_empty));
                }
                i++;
            }
        }
        return (ArrayList) values;
    }
}
