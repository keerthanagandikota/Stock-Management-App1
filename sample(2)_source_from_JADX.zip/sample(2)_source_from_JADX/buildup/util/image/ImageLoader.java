package buildup.util.image;

public interface ImageLoader {
    void load(ImageLoaderRequest imageLoaderRequest);
}
