package buildup.util.image;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import buildup.injectors.PicassoBuilderInjector;
import buildup.util.image.transformations.PicassoExifDocumentTransformation;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.Builder;
import com.squareup.picasso.RequestCreator;

public class PicassoImageLoader implements ImageLoader {
    private static final String TAG;
    private static Picasso picasso;
    private boolean basicAuthInterceptor;
    private final Context context;

    static {
        TAG = PicassoImageLoader.class.getSimpleName();
    }

    public PicassoImageLoader(Context context) {
        this.context = context;
        picasso = Picasso.with(context);
        this.basicAuthInterceptor = false;
    }

    public PicassoImageLoader(Context context, boolean basicAuthInterceptor) {
        this.context = context;
        picasso = Picasso.with(context);
        this.basicAuthInterceptor = basicAuthInterceptor;
    }

    public void load(ImageLoaderRequest request) {
        RequestCreator requestCreator;
        if (this.basicAuthInterceptor) {
            picasso = PicassoBuilderInjector.getPicassoBuilderInjector();
        } else {
            picasso = getInstance(this.context);
        }
        picasso.setIndicatorsEnabled(request.isDebugging());
        Uri requestUri = request.getUri();
        if (request.getPath() != null) {
            requestCreator = picasso.load(request.getPath());
        } else if (requestUri != null) {
            requestCreator = picasso.load(requestUri).transform(new PicassoExifDocumentTransformation(this.context, requestUri));
        } else if (request.getResourceToLoad() != 0) {
            requestCreator = picasso.load(request.getResourceToLoad());
        } else {
            requestCreator = picasso.load((String) null);
            Log.w(TAG, "Attempted to load image without a valid source.");
        }
        if (request.shouldFit()) {
            requestCreator.centerInside();
            requestCreator.fit();
        }
        requestCreator.placeholder(request.getPlaceholder()).error(request.getError()).into(request.getTargetView());
    }

    private static Picasso getInstance(Context context) {
        if (picasso == null) {
            picasso = new Builder(context).build();
        }
        return picasso;
    }
}
