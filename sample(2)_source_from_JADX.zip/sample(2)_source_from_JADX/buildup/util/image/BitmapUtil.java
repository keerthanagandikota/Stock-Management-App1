package buildup.util.image;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.util.Log;

public class BitmapUtil {
    private static final String[] CONTENT_ORIENTATION;

    @android.annotation.TargetApi(19)
    public static int getExifOrientation(android.content.Context r10, android.net.Uri r11) {
        /* JADX: method processing error */
/*
        Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x0044 in list []
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:42)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:58)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:281)
	at jadx.api.JavaClass.decompile(JavaClass.java:59)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:161)
*/
        /*
        r9 = 0;
        r0 = r10.getContentResolver();
        r6 = 0;
        r7 = android.provider.DocumentsContract.getDocumentId(r11);	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r1 = ":";	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r1 = r7.split(r1);	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r2 = 1;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r7 = r1[r2];	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r1 = android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r2 = CONTENT_ORIENTATION;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r3 = "_id = ?";	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r4 = 1;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r4 = new java.lang.String[r4];	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r5 = 0;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r4[r5] = r7;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r5 = 0;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        r6 = r0.query(r1, r2, r3, r4, r5);	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        if (r6 == 0) goto L_0x002c;	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
    L_0x0026:
        r1 = r6.moveToFirst();	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        if (r1 != 0) goto L_0x0033;
    L_0x002c:
        if (r6 == 0) goto L_0x0031;
    L_0x002e:
        r6.close();
    L_0x0031:
        r1 = r9;
    L_0x0032:
        return r1;
    L_0x0033:
        r1 = 0;
        r1 = r6.getInt(r1);	 Catch:{ RuntimeException -> 0x003e, all -> 0x0046 }
        if (r6 == 0) goto L_0x0032;
    L_0x003a:
        r6.close();
        goto L_0x0032;
    L_0x003e:
        r8 = move-exception;
        if (r6 == 0) goto L_0x0044;
    L_0x0041:
        r6.close();
    L_0x0044:
        r1 = r9;
        goto L_0x0032;
    L_0x0046:
        r1 = move-exception;
        if (r6 == 0) goto L_0x004c;
    L_0x0049:
        r6.close();
    L_0x004c:
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: buildup.util.image.BitmapUtil.getExifOrientation(android.content.Context, android.net.Uri):int");
    }

    static {
        CONTENT_ORIENTATION = new String[]{"orientation"};
    }

    public static Bitmap rotateBitmap(Bitmap bitmap, int degrees) {
        Matrix matrix = new Matrix();
        matrix.postRotate((float) degrees);
        Bitmap rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        if (bitmap != rotated) {
            Log.wtf("DMV", "Bitmpa rotated");
            bitmap.recycle();
        } else {
            Log.wtf("DMV", "Bitmap NOT rotated");
        }
        return rotated;
    }
}
