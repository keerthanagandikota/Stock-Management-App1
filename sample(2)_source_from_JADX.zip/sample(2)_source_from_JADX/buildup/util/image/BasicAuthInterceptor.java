package buildup.util.image;

import android.util.Base64;
import com.squareup.okhttp.Interceptor;
import com.squareup.okhttp.Interceptor.Chain;
import com.squareup.okhttp.Response;
import java.io.IOException;

public class BasicAuthInterceptor implements Interceptor {
    String password;
    String username;

    public BasicAuthInterceptor(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public Response intercept(Chain chain) throws IOException {
        return chain.proceed(chain.request().newBuilder().header("Authorization", "Basic " + Base64.encodeToString(String.format("%s:%s", new Object[]{this.username, this.password}).getBytes(), 2)).build());
    }
}
