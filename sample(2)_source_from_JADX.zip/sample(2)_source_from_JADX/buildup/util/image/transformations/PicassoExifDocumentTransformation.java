package buildup.util.image.transformations;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build.VERSION;
import android.provider.DocumentsContract;
import buildup.util.image.BitmapUtil;
import com.squareup.picasso.Transformation;

public class PicassoExifDocumentTransformation implements Transformation {
    final Context context;
    final Uri uri;

    public PicassoExifDocumentTransformation(Context context, Uri uri) {
        this.context = context;
        this.uri = uri;
    }

    public Bitmap transform(Bitmap source) {
        if (VERSION.SDK_INT < 19 || !DocumentsContract.isDocumentUri(this.context, this.uri)) {
            return source;
        }
        int exifRotation = BitmapUtil.getExifOrientation(this.context, this.uri);
        if (exifRotation != 0) {
            return BitmapUtil.rotateBitmap(source, exifRotation);
        }
        return source;
    }

    public String key() {
        if (VERSION.SDK_INT < 19 || !DocumentsContract.isDocumentUri(this.context, this.uri)) {
            return "documentTransform()";
        }
        return "documentExifTransform(" + DocumentsContract.getDocumentId(this.uri) + ")";
    }
}
