package buildup.util.image;

import android.net.Uri;
import android.support.annotation.AnyRes;
import android.widget.ImageView;
import buildup.core.C0338R;

public class ImageLoaderRequest {
    private final boolean debug;
    @AnyRes
    private final int error;
    private final boolean fit;
    private final String path;
    @AnyRes
    private final int placeholder;
    @AnyRes
    private final int resourceToLoad;
    private final ImageView targetView;
    private final Uri uri;

    public static class Builder {
        private boolean debug;
        private int error;
        private boolean fit;
        private String path;
        private int placeholder;
        private int resourceToLoad;
        private ImageView targetView;
        private Uri uri;

        public Builder() {
            this.placeholder = C0338R.color.ima_il_placeholder;
            this.error = C0338R.drawable.ima_il_error;
        }

        public static Builder imageLoaderRequest() {
            return new Builder();
        }

        public Builder withPath(String path) {
            this.path = path;
            return this;
        }

        public Builder withUri(Uri uri) {
            this.uri = uri;
            return this;
        }

        public Builder withPlaceholder(@AnyRes int placeholder) {
            this.placeholder = placeholder;
            return this;
        }

        public Builder withError(@AnyRes int error) {
            this.error = error;
            return this;
        }

        public Builder fit() {
            this.fit = true;
            return this;
        }

        public Builder debugging() {
            this.debug = true;
            return this;
        }

        public Builder withTargetView(ImageView targetView) {
            this.targetView = targetView;
            return this;
        }

        public Builder withResourceToLoad(@AnyRes int resourceToLoad) {
            this.resourceToLoad = resourceToLoad;
            return this;
        }

        public ImageLoaderRequest build() {
            return new ImageLoaderRequest();
        }
    }

    private ImageLoaderRequest(Builder builder) {
        this.path = builder.path;
        this.uri = builder.uri;
        this.placeholder = builder.placeholder;
        this.error = builder.error;
        this.fit = builder.fit;
        this.debug = builder.debug;
        this.targetView = builder.targetView;
        this.resourceToLoad = builder.resourceToLoad;
    }

    public String getPath() {
        return this.path;
    }

    public Uri getUri() {
        return this.uri;
    }

    @AnyRes
    public int getResourceToLoad() {
        return this.resourceToLoad;
    }

    public int getPlaceholder() {
        return this.placeholder;
    }

    public int getError() {
        return this.error;
    }

    public boolean shouldFit() {
        return this.fit;
    }

    public boolean isDebugging() {
        return this.debug;
    }

    public ImageView getTargetView() {
        return this.targetView;
    }
}
