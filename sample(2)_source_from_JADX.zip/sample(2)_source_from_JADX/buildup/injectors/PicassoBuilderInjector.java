package buildup.injectors;

import android.content.Context;
import buildup.util.image.BasicAuthInterceptor;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.picasso.OkHttpDownloader;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Picasso.Builder;

public class PicassoBuilderInjector {
    private static Picasso picassoBuilderInjector;

    public static void setPicassoBasicAuthBuilderInjector(BasicAuthInterceptor basicAuthInterceptor, Context context) {
        Builder builder = new Builder(context);
        OkHttpClient client = new OkHttpClient();
        client.networkInterceptors().add(basicAuthInterceptor);
        picassoBuilderInjector = builder.downloader(new OkHttpDownloader(client)).build();
    }

    public static Picasso getPicassoBuilderInjector() {
        return picassoBuilderInjector;
    }
}
