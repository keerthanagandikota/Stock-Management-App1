package buildup.injectors;

import buildup.gson.BooleanJsonTypeAdapter;
import buildup.gson.DateJsonTypeAdapter;
import buildup.gson.IntegerJsonTypeAdapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.Date;

public class GsonInjector {
    private static final Gson CLOUDANT_GSON;

    static {
        CLOUDANT_GSON = new GsonBuilder().registerTypeAdapter(Integer.class, new IntegerJsonTypeAdapter()).registerTypeAdapter(Date.class, new DateJsonTypeAdapter()).registerTypeAdapter(Boolean.class, new BooleanJsonTypeAdapter()).create();
    }

    public static Gson cloudantGson() {
        return CLOUDANT_GSON;
    }
}
