package buildup.injectors;

import buildup.ds.restds.GenericJsonTypeAdapter;
import buildup.gson.DateJsonTypeAdapter;
import buildup.gson.DecimalJsonTypeAdapter;
import buildup.gson.URLJsonTypeAdapter;
import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import com.google.gson.internal.C$Gson$Types;
import java.net.URL;
import java.util.Date;
import java.util.List;
import retrofit.converter.Converter;
import retrofit.converter.GsonConverter;

public class ConverterInjector {
    private static GenericJsonTypeAdapter genericJsonTypeAdapter;

    /* renamed from: buildup.injectors.ConverterInjector.1 */
    static class C03591 implements ExclusionStrategy {
        C03591() {
        }

        public boolean shouldSkipField(FieldAttributes f) {
            SerializedName annotation = (SerializedName) f.getAnnotation(SerializedName.class);
            return annotation != null && annotation.value().equals("_id");
        }

        public boolean shouldSkipClass(Class<?> cls) {
            return false;
        }
    }

    public static void setGenericJsonTypeAdapter(GenericJsonTypeAdapter typeAdapter) {
        genericJsonTypeAdapter = typeAdapter;
    }

    public static Converter getConverter() {
        if (genericJsonTypeAdapter != null) {
            return new GsonConverter(new GsonBuilder().serializeNulls().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).registerTypeAdapter(C$Gson$Types.newParameterizedTypeWithOwner(null, List.class, genericJsonTypeAdapter.getItem()), genericJsonTypeAdapter).registerTypeAdapter(Double.class, new DecimalJsonTypeAdapter()).registerTypeAdapter(Date.class, new DateJsonTypeAdapter()).registerTypeAdapter(URL.class, new URLJsonTypeAdapter()).addSerializationExclusionStrategy(new C03591()).create());
        }
        throw new IllegalStateException("You must set the type adapter first");
    }
}
