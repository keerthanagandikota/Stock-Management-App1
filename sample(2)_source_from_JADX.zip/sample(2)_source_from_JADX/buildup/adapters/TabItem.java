package buildup.adapters;

import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;

public class TabItem {
    private Class fragmentClass;
    private Integer pageIconRes;
    private Integer pageTitleRes;

    public TabItem(@StringRes Integer pageTitleRes, @DrawableRes Integer pageIconRes, Class fragmentClass) {
        this.pageTitleRes = pageTitleRes;
        this.pageIconRes = pageIconRes;
        this.fragmentClass = fragmentClass;
    }

    public TabItem(Integer pageTypeRes, boolean isPageTitle, Class fragmentClass) {
        if (isPageTitle) {
            this.pageTitleRes = pageTypeRes;
        } else {
            this.pageIconRes = pageTypeRes;
        }
        this.fragmentClass = fragmentClass;
    }

    public Integer getPageTitleRes() {
        return this.pageTitleRes;
    }

    public Integer getPageIconRes() {
        return this.pageIconRes;
    }

    public Class getFragmentClass() {
        return this.fragmentClass;
    }
}
