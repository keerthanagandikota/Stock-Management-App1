package buildup.adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import buildup.ds.Cache;
import buildup.ds.Datasource;
import buildup.ds.Datasource.Listener;
import java.lang.ref.WeakReference;
import java.util.List;

public abstract class DatasourceAdapter<T> extends ArrayAdapter<T> {
    protected Callback callback;
    protected WeakReference<Context> contextWeakReference;
    protected final Datasource<T> datasource;
    private final LayoutInflater inflater;
    private final int viewId;

    /* renamed from: buildup.adapters.DatasourceAdapter.1 */
    class C03191 implements Listener<List<T>> {

        /* renamed from: buildup.adapters.DatasourceAdapter.1.1 */
        class C03171 implements Runnable {
            final /* synthetic */ List val$result;

            C03171(List list) {
                this.val$result = list;
            }

            public void run() {
                DatasourceAdapter.this.clear();
                DatasourceAdapter.this.addAll(this.val$result);
                DatasourceAdapter.this.notifyDataSetChanged();
                if (DatasourceAdapter.this.callback != null) {
                    DatasourceAdapter.this.callback.onDataAvailable();
                }
            }
        }

        /* renamed from: buildup.adapters.DatasourceAdapter.1.2 */
        class C03182 implements Runnable {
            final /* synthetic */ Exception val$e;

            C03182(Exception exception) {
                this.val$e = exception;
            }

            public void run() {
                if (DatasourceAdapter.this.callback != null) {
                    DatasourceAdapter.this.callback.onDatasourceError(this.val$e);
                }
                DatasourceAdapter.this.notifyDatasourceError(this.val$e);
                DatasourceAdapter.this.notifyDataSetChanged();
            }
        }

        C03191() {
        }

        public void onSuccess(List<T> result) {
            DatasourceAdapter.this.runOnActivity(new C03171(result));
        }

        public void onFailure(Exception e) {
            DatasourceAdapter.this.runOnActivity(new C03182(e));
        }
    }

    public interface Callback {
        void onDataAvailable();

        void onDatasourceError(Exception exception);

        void onPageRequested();
    }

    public abstract void bindView(T t, int i, View view);

    public DatasourceAdapter(Context context, int viewId, Datasource<T> datasource) {
        super(context, viewId);
        this.inflater = LayoutInflater.from(context);
        this.datasource = datasource;
        this.viewId = viewId;
        this.contextWeakReference = new WeakReference(context);
        setNotifyOnChange(false);
    }

    public void setCallback(Callback c) {
        this.callback = c;
    }

    public Callback getCallback() {
        return this.callback;
    }

    public void refresh() {
        refresh(false);
    }

    public void refresh(boolean forceRefresh) {
        if (this.datasource instanceof Cache) {
            ((Cache) this.datasource).invalidate();
        }
        this.datasource.getItems(new C03191());
    }

    private void runOnActivity(Runnable runnable) {
        Activity act = (Activity) this.contextWeakReference.get();
        if (act != null) {
            act.runOnUiThread(runnable);
        }
    }

    public final View getView(int position, View view, ViewGroup container) {
        if (view == null) {
            view = newView(this.inflater, position, container);
            if (view == null) {
                throw new IllegalStateException("newView result must not be null.");
            }
        }
        bindView(getItem(position), position, view);
        return view;
    }

    public void notifyDatasourceError(Exception e) {
    }

    private View newView(LayoutInflater inflater, int position, ViewGroup container) {
        return inflater.inflate(this.viewId, container, false);
    }
}
