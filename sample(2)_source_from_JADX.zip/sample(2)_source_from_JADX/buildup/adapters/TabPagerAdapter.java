package buildup.adapters;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import io.buildup.pkg20170504080645.BuildConfig;
import java.util.List;

public class TabPagerAdapter extends FragmentPagerAdapter {
    private Context context;
    private List<TabItem> tabItems;

    public TabPagerAdapter(FragmentManager fm, Context context, List<TabItem> tabItems) {
        super(fm);
        this.context = context;
        this.tabItems = tabItems;
    }

    public Fragment getItem(int position) {
        try {
            return (Fragment) ((TabItem) this.tabItems.get(position)).getFragmentClass().newInstance();
        } catch (InstantiationException e) {
            throw new IllegalStateException("Fragment result must not be null.");
        } catch (IllegalAccessException e2) {
            throw new IllegalStateException("Fragment result must not be null.");
        }
    }

    public CharSequence getPageTitle(int position) {
        return ((TabItem) this.tabItems.get(position)).getPageTitleRes() != null ? this.context.getString(((TabItem) this.tabItems.get(position)).getPageTitleRes().intValue()) : BuildConfig.FLAVOR;
    }

    public int getCount() {
        return this.tabItems.size();
    }
}
