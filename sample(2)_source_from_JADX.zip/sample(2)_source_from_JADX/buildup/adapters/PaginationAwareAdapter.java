package buildup.adapters;

import android.content.Context;
import android.util.Log;
import buildup.ds.Datasource;
import buildup.ds.Datasource.Listener;
import buildup.ds.ForceRefreshDatasource;
import buildup.ds.Pagination;
import java.util.List;

public abstract class PaginationAwareAdapter<T> extends DatasourceAdapter<T> {
    private static final String TAG;
    private int currentPage;
    private boolean reachedEnd;

    /* renamed from: buildup.adapters.PaginationAwareAdapter.1 */
    class C03201 implements Listener<List<T>> {
        final /* synthetic */ boolean val$clear;
        final /* synthetic */ int val$pageSize;

        C03201(int i, boolean z) {
            this.val$pageSize = i;
            this.val$clear = z;
        }

        public void onSuccess(List<T> result) {
            if (result.size() < this.val$pageSize) {
                PaginationAwareAdapter.this.reachedEnd = true;
            }
            if (this.val$clear) {
                PaginationAwareAdapter.this.clear();
            }
            PaginationAwareAdapter.this.addAll(result);
            PaginationAwareAdapter.this.notifyDataSetChanged();
            if (PaginationAwareAdapter.this.callback != null) {
                PaginationAwareAdapter.this.callback.onDataAvailable();
            }
        }

        public void onFailure(Exception e) {
            PaginationAwareAdapter.this.notifyDatasourceError(e);
            PaginationAwareAdapter.this.notifyDataSetChanged();
            if (PaginationAwareAdapter.this.callback != null) {
                PaginationAwareAdapter.this.callback.onDatasourceError(e);
            }
        }
    }

    static {
        TAG = PaginationAwareAdapter.class.getSimpleName();
    }

    public PaginationAwareAdapter(Context context, int viewId, Datasource<T> datasource) {
        super(context, viewId, datasource);
        this.currentPage = -1;
    }

    public void refresh(boolean forceRefresh) {
        this.currentPage = -1;
        this.reachedEnd = false;
        loadNextPage(true, forceRefresh);
    }

    public void loadNextPage() {
        loadNextPage(false);
    }

    public void loadNextPage(boolean clear) {
        loadNextPage(clear, false);
    }

    public void loadNextPage(boolean clear, boolean forceRefresh) {
        if (!this.reachedEnd) {
            Log.d(TAG, "loading page: " + (this.currentPage + 1));
            Pagination<T> pagedDS = this.datasource;
            int pageSize = pagedDS.getPageSize();
            if (this.callback != null) {
                this.callback.onPageRequested();
            }
            Listener<List<T>> paginationListener = new C03201(pageSize, clear);
            int i;
            if (pagedDS instanceof ForceRefreshDatasource) {
                ForceRefreshDatasource forceRefreshDs = (ForceRefreshDatasource) pagedDS;
                i = this.currentPage + 1;
                this.currentPage = i;
                forceRefreshDs.getItems(i, forceRefresh, paginationListener);
                return;
            }
            i = this.currentPage + 1;
            this.currentPage = i;
            pagedDS.getItems(i, paginationListener);
        }
    }
}
