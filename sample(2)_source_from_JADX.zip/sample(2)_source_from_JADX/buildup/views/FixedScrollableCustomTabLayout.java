package buildup.views;

import android.content.Context;
import android.support.design.widget.TabLayout;
import android.util.AttributeSet;

public class FixedScrollableCustomTabLayout extends TabLayout {
    private static int MAX_TABS_FIXED;

    static {
        MAX_TABS_FIXED = 3;
    }

    public FixedScrollableCustomTabLayout(Context context) {
        super(context);
    }

    public FixedScrollableCustomTabLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FixedScrollableCustomTabLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        if (getResources().getConfiguration().orientation == 1) {
            MAX_TABS_FIXED = 3;
        } else {
            MAX_TABS_FIXED = 5;
        }
        try {
            if (getTabCount() != 0) {
                if (getTabCount() <= MAX_TABS_FIXED) {
                    setTabMode(1);
                    setTabGravity(0);
                    return;
                }
                setTabMode(0);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
