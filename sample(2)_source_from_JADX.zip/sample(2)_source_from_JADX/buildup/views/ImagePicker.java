package buildup.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.core.C0338R;
import buildup.dialogs.ImagePickerOptionsDialog;
import buildup.dialogs.ImagePickerOptionsDialog.OnOptionSelectedListener;
import buildup.util.image.ImageLoader;
import buildup.util.image.ImageLoaderRequest.Builder;
import buildup.util.image.PicassoImageLoader;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class ImagePicker extends LinearLayout implements OnClickListener, OnOptionSelectedListener {
    public static final int CAPTURE_REQUEST_CODE = 2048;
    public static final String FILE_PICKER_TAG = "FilePicker";
    public static final int GALLERY_REQUEST_CODE = 1024;
    private static final String SUFFIX_JPG = ".jpg";
    private Callback callback;
    private final TextView errorView;
    private Fragment fragment;
    private final FragmentManager fragmentManager;
    private boolean hasImage;
    private File imageFile;
    private final ImageLoader imageLoader;
    private ImagePickerOptionsDialog imagePickerDialog;
    private final ImageView imageView;
    private final int index;

    /* renamed from: buildup.views.ImagePicker.1 */
    class C03971 extends AnimatorListenerAdapter {
        C03971() {
        }

        public void onAnimationEnd(Animator animation) {
            ImagePicker.this.errorView.setText(null);
            ImagePicker.this.errorView.setVisibility(8);
        }
    }

    public interface Callback {
        void imageRemoved();
    }

    static class ImagePickerSavedState extends BaseSavedState {
        public static final Creator<ImagePickerSavedState> CREATOR;
        private final File mImageFile;

        /* renamed from: buildup.views.ImagePicker.ImagePickerSavedState.1 */
        static class C03981 implements Creator<ImagePickerSavedState> {
            C03981() {
            }

            public ImagePickerSavedState createFromParcel(Parcel in) {
                return new ImagePickerSavedState(null);
            }

            public ImagePickerSavedState[] newArray(int size) {
                return new ImagePickerSavedState[size];
            }
        }

        public ImagePickerSavedState(Parcelable parcelable, File imageFile) {
            super(parcelable);
            this.mImageFile = imageFile;
        }

        private ImagePickerSavedState(Parcel in) {
            super(in);
            this.mImageFile = (File) in.readSerializable();
        }

        public File getImageFile() {
            return this.mImageFile;
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeSerializable(this.mImageFile);
        }

        static {
            CREATOR = new C03981();
        }
    }

    public ImagePicker(Context context) {
        this(context, null);
    }

    public ImagePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.imageLoader = new PicassoImageLoader(context);
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.ImagePicker, 0, 0);
        String label = a.getString(C0338R.styleable.ImagePicker_label);
        this.index = a.getInt(C0338R.styleable.ImagePicker_index, 0);
        a.recycle();
        setOrientation(1);
        setGravity(16);
        LayoutInflater.from(context).inflate(C0338R.layout.file_picker, this, true);
        this.errorView = (TextView) findViewById(C0338R.id.error);
        TextView labelView = (TextView) findViewById(C0338R.id.label);
        labelView.setText(label);
        this.imageView = (ImageView) findViewById(C0338R.id.image);
        labelView.setOnClickListener(this);
        this.imageView.setOnClickListener(this);
        this.fragmentManager = ((FragmentActivity) getContext()).getSupportFragmentManager();
        this.imagePickerDialog = (ImagePickerOptionsDialog) this.fragmentManager.findFragmentByTag(FILE_PICKER_TAG);
        if (this.imagePickerDialog == null) {
            this.imagePickerDialog = new ImagePickerOptionsDialog();
        }
    }

    public void setImageBitmap(Bitmap bm) {
        this.hasImage = true;
        this.imageView.setImageBitmap(bm);
    }

    public void setImageUrl(@NonNull String url) {
        this.hasImage = true;
        this.imageLoader.load(Builder.imageLoaderRequest().withPath(url).withTargetView(this.imageView).fit().build());
    }

    public void setImageUri(@NonNull Uri uri) {
        this.hasImage = true;
        this.imageLoader.load(Builder.imageLoaderRequest().withUri(uri).withTargetView(this.imageView).fit().build());
    }

    public void setTargetFragment(Fragment fr) {
        this.fragment = fr;
    }

    public File getImageFile() {
        return this.imageFile;
    }

    public void clear() {
        this.hasImage = false;
        this.imageLoader.load(Builder.imageLoaderRequest().withResourceToLoad(C0338R.drawable.ic_image_photo).withTargetView(this.imageView).build());
    }

    public void onClick(View v) {
        if (this.hasImage) {
            this.imagePickerDialog.setRemoveEnabled(true);
        }
        this.imagePickerDialog.setListener(this);
        this.imagePickerDialog.show(this.fragmentManager, FILE_PICKER_TAG);
    }

    public void fromStorage() {
        Intent fileIntent = new Intent("android.intent.action.GET_CONTENT");
        fileIntent.setType("image/*");
        this.fragment.startActivityForResult(Intent.createChooser(fileIntent, null), this.index + GALLERY_REQUEST_CODE);
    }

    public void fromCamera() {
        Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
        cameraIntent.putExtra("output", Uri.fromFile(createImageFile()));
        this.fragment.startActivityForResult(Intent.createChooser(cameraIntent, null), this.index + CAPTURE_REQUEST_CODE);
    }

    private File createImageFile() {
        if (this.imageFile == null) {
            try {
                this.imageFile = File.createTempFile("BU_" + UUID.randomUUID(), SUFFIX_JPG, Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES));
            } catch (IOException e) {
                throw new RuntimeException("Could not create image");
            }
        }
        return this.imageFile;
    }

    public void remove() {
        if (this.callback != null) {
            this.callback.imageRemoved();
        }
    }

    protected Parcelable onSaveInstanceState() {
        return new ImagePickerSavedState(super.onSaveInstanceState(), this.imageFile);
    }

    protected void onRestoreInstanceState(Parcelable state) {
        ImagePickerSavedState savedState = (ImagePickerSavedState) state;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.imageFile = savedState.getImageFile();
    }

    public void setCallback(Callback callback) {
        this.callback = callback;
    }

    public Callback getCallback() {
        return this.callback;
    }

    public void setError(int errorRes) {
        setError(getContext().getString(errorRes));
    }

    public void setError(CharSequence errorMsg) {
        if (errorMsg == null) {
            this.errorView.animate().alpha(0.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(new C03971());
        } else if (this.errorView.getVisibility() == 8) {
            this.errorView.setText(errorMsg);
            this.errorView.setAlpha(0.0f);
            this.errorView.setVisibility(0);
            this.errorView.animate().alpha(1.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(null).start();
        }
    }
}
