package buildup.views;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View.MeasureSpec;
import android.widget.ImageView;

public class ResizableImageView extends ImageView {
    public ResizableImageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ResizableImageView(Context context) {
        super(context);
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        Drawable d = getDrawable();
        if (d == null) {
            super.setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
            return;
        }
        int width;
        int height;
        int imageHeight = d.getIntrinsicHeight();
        int imageWidth = d.getIntrinsicWidth();
        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        float imageRatio = 0.0f;
        if (imageHeight > 0) {
            imageRatio = (float) (imageWidth / imageHeight);
        }
        float sizeRatio = 0.0f;
        if (heightSize > 0) {
            sizeRatio = (float) (widthSize / heightSize);
        }
        if (imageRatio >= sizeRatio) {
            width = widthSize;
            height = (width * imageHeight) / imageWidth;
        } else {
            height = heightSize;
            width = (height * imageWidth) / imageHeight;
        }
        setMeasuredDimension(width, height);
    }
}
