package buildup.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.core.C0338R;
import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog;
import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog.OnDateSetListener;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class DatePicker extends LinearLayout {
    OnDateSetListener dateCallback;
    private Date mDate;
    private final TextView mErrorView;
    TextView mLabelView;
    private DateSelectedListener mListener;
    ImageButton mReset;
    TextView mValueView;

    /* renamed from: buildup.views.DatePicker.1 */
    class C03801 implements OnClickListener {
        C03801() {
        }

        public void onClick(View view) {
            DatePicker.this.setDate(null);
            if (DatePicker.this.getListener() != null) {
                DatePicker.this.getListener().onSelected(null);
            }
        }
    }

    /* renamed from: buildup.views.DatePicker.2 */
    class C03812 implements OnClickListener {
        C03812() {
        }

        public void onClick(View v) {
            Calendar cal = Calendar.getInstance();
            if (DatePicker.this.mDate != null) {
                cal.setTime(DatePicker.this.mDate);
            }
            FragmentManager fm = ((FragmentActivity) DatePicker.this.getContext()).getSupportFragmentManager();
            CalendarDatePickerDialog calendarDatePickerDialog = (CalendarDatePickerDialog) fm.findFragmentByTag("DatePicker");
            if (calendarDatePickerDialog == null) {
                calendarDatePickerDialog = CalendarDatePickerDialog.newInstance(DatePicker.this.dateCallback, cal.get(1), cal.get(2), cal.get(5));
            } else {
                calendarDatePickerDialog.setOnDateSetListener(DatePicker.this.dateCallback);
            }
            calendarDatePickerDialog.show(fm, "DatePicker");
        }
    }

    /* renamed from: buildup.views.DatePicker.3 */
    class C03823 extends AnimatorListenerAdapter {
        C03823() {
        }

        public void onAnimationEnd(Animator animation) {
            DatePicker.this.mErrorView.setText((CharSequence) null);
            DatePicker.this.mErrorView.setVisibility(8);
        }
    }

    /* renamed from: buildup.views.DatePicker.4 */
    class C03834 implements OnDateSetListener {
        C03834() {
        }

        public void onDateSet(CalendarDatePickerDialog calendarDatePickerDialog, int year, int month, int day) {
            Calendar cal = Calendar.getInstance();
            cal.set(year, month, day, 0, 0, 0);
            DatePicker.this.mDate = cal.getTime();
            DatePicker.this.setDateText(DatePicker.this.mDate);
            if (DatePicker.this.getListener() != null) {
                DatePicker.this.getListener().onSelected(cal.getTime());
            }
        }
    }

    public interface DateSelectedListener {
        void onSelected(Date date);
    }

    public DatePicker(Context context) {
        this(context, null);
    }

    public DatePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.dateCallback = new C03834();
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.ListSelectionPicker, 0, 0);
        String label = a.getString(C0338R.styleable.ListSelectionPicker_label);
        a.recycle();
        setOrientation(1);
        setGravity(16);
        LayoutInflater.from(context).inflate(C0338R.layout.date_picker, this, true);
        this.mLabelView = (TextView) getChildAt(0);
        this.mLabelView.setText(label);
        this.mValueView = (TextView) findViewById(C0338R.id.dateValue);
        this.mReset = (ImageButton) findViewById(C0338R.id.dateReset);
        this.mReset.setOnClickListener(new C03801());
        this.mErrorView = (TextView) findViewById(C0338R.id.errorView);
        this.mValueView.setOnClickListener(new C03812());
    }

    private void setDateText(Date date) {
        this.mValueView.setText(date != null ? DateFormat.getDateInstance().format(date) : null);
    }

    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        if (this.mDate != null) {
            bundle.putLong("theDate", this.mDate.getTime());
        }
        return bundle;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            long dateVal = ((Bundle) state).getLong("theDate", -1);
            if (dateVal != -1) {
                setDate(new Date(dateVal));
            }
            state = ((Bundle) state).getParcelable("instanceState");
        }
        super.onRestoreInstanceState(state);
    }

    public void setDate(Date date) {
        this.mDate = date;
        setDateText(date);
    }

    public Date getDate() {
        return this.mDate;
    }

    public void setListener(DateSelectedListener listener) {
        this.mListener = listener;
    }

    public DateSelectedListener getListener() {
        return this.mListener;
    }

    public void setError(int errorRes) {
        setError(getContext().getString(errorRes));
    }

    public void setError(CharSequence errorMsg) {
        if (errorMsg == null) {
            this.mErrorView.animate().alpha(0.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(new C03823());
        } else if (this.mErrorView.getVisibility() == 8) {
            this.mErrorView.setText(errorMsg);
            this.mErrorView.setAlpha(0.0f);
            this.mErrorView.setVisibility(0);
            this.mErrorView.animate().alpha(1.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(null).start();
        }
    }
}
