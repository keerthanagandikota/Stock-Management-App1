package buildup.views.org.sufficientlysecure.htmltextview;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.text.Html.ImageGetter;
import android.view.View;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class UrlImageGetter implements ImageGetter {
    Context f11c;
    View container;

    public class ImageGetterAsyncTask extends AsyncTask<String, Void, Drawable> {
        UrlDrawable urlDrawable;

        public ImageGetterAsyncTask(UrlDrawable d) {
            this.urlDrawable = d;
        }

        protected Drawable doInBackground(String... params) {
            return fetchDrawable(params[0]);
        }

        protected void onPostExecute(Drawable result) {
            this.urlDrawable.setBounds(0, 0, result.getIntrinsicWidth() + 0, result.getIntrinsicHeight() + 0);
            this.urlDrawable.drawable = result;
            UrlImageGetter.this.container.invalidate();
        }

        public Drawable fetchDrawable(String urlString) {
            try {
                Drawable drawable = Drawable.createFromStream(fetch(urlString), "src");
                drawable.setBounds(0, 0, drawable.getIntrinsicWidth() + 0, drawable.getIntrinsicHeight() + 0);
                return drawable;
            } catch (Exception e) {
                return null;
            }
        }

        private InputStream fetch(String urlString) throws MalformedURLException, IOException {
            return new DefaultHttpClient().execute(new HttpGet(urlString)).getEntity().getContent();
        }
    }

    public class UrlDrawable extends BitmapDrawable {
        protected Drawable drawable;

        public void draw(Canvas canvas) {
            if (this.drawable != null) {
                this.drawable.draw(canvas);
            }
        }
    }

    public UrlImageGetter(View t, Context c) {
        this.f11c = c;
        this.container = t;
    }

    public Drawable getDrawable(String source) {
        UrlDrawable urlDrawable = new UrlDrawable();
        new ImageGetterAsyncTask(urlDrawable).execute(new String[]{source});
        return urlDrawable;
    }
}
