package buildup.views.org.sufficientlysecure.htmltextview;

import android.content.Context;
import android.text.Html;
import android.text.Html.ImageGetter;
import android.text.method.LinkMovementMethod;
import android.util.AttributeSet;
import io.buildup.pkg20170504080645.BuildConfig;
import java.io.InputStream;
import java.util.Scanner;

public class HtmlTextView extends JellyBeanSpanFixTextView {
    public static final boolean DEBUG = false;
    public static final String TAG = "HtmlTextView";

    public HtmlTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public HtmlTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public HtmlTextView(Context context) {
        super(context);
    }

    private static String convertStreamToString(InputStream is) {
        Scanner s = new Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : BuildConfig.FLAVOR;
    }

    public void setHtmlFromRawResource(Context context, int id, boolean useLocalDrawables) {
        setHtmlFromString(convertStreamToString(context.getResources().openRawResource(id)), useLocalDrawables);
    }

    public void setHtmlFromString(String html, boolean useLocalDrawables) {
        ImageGetter imgGetter;
        if (useLocalDrawables) {
            imgGetter = new LocalImageGetter(getContext());
        } else {
            imgGetter = new UrlImageGetter(this, getContext());
        }
        setText(Html.fromHtml(html, imgGetter, new HtmlTagHandler()));
        setMovementMethod(LinkMovementMethod.getInstance());
    }
}
