package buildup.views.org.sufficientlysecure.htmltextview;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.Html.ImageGetter;
import android.util.Log;

public class LocalImageGetter implements ImageGetter {
    Context f10c;

    public LocalImageGetter(Context c) {
        this.f10c = c;
    }

    public Drawable getDrawable(String source) {
        int id = this.f10c.getResources().getIdentifier(source, "drawable", this.f10c.getPackageName());
        if (id == 0) {
            id = this.f10c.getResources().getIdentifier(source, "drawable", "android");
        }
        if (id == 0) {
            Log.e(HtmlTextView.TAG, "source could not be found: " + source);
            return null;
        }
        Drawable d = this.f10c.getResources().getDrawable(id);
        d.setBounds(0, 0, d.getIntrinsicWidth(), d.getIntrinsicHeight());
        return d;
    }
}
