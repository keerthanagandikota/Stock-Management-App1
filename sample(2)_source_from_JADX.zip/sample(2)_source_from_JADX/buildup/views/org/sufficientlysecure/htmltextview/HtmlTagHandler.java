package buildup.views.org.sufficientlysecure.htmltextview;

import android.text.Editable;
import android.text.Html.TagHandler;
import android.text.Layout.Alignment;
import android.text.style.AlignmentSpan.Standard;
import android.text.style.BulletSpan;
import android.text.style.LeadingMarginSpan;
import android.text.style.TypefaceSpan;
import java.util.Vector;
import org.xml.sax.XMLReader;

public class HtmlTagHandler implements TagHandler {
    private int mListItemCount;
    private final Vector<String> mListParents;

    private static class Center {
        private Center() {
        }
    }

    private static class Code {
        private Code() {
        }
    }

    public HtmlTagHandler() {
        this.mListItemCount = 0;
        this.mListParents = new Vector();
    }

    public void handleTag(boolean opening, String tag, Editable output, XMLReader xmlReader) {
        if (opening) {
            if (tag.equalsIgnoreCase("ul") || tag.equalsIgnoreCase("ol") || tag.equalsIgnoreCase("dd")) {
                this.mListParents.add(tag);
                this.mListItemCount = 0;
            } else if (tag.equalsIgnoreCase("code")) {
                start(output, new Code());
            } else if (tag.equalsIgnoreCase("center")) {
                start(output, new Center());
            }
        } else if (tag.equalsIgnoreCase("ul") || tag.equalsIgnoreCase("ol") || tag.equalsIgnoreCase("dd")) {
            this.mListParents.remove(tag);
            this.mListItemCount = 0;
        } else if (tag.equalsIgnoreCase("li")) {
            handleListTag(output);
        } else if (tag.equalsIgnoreCase("code")) {
            end(output, Code.class, new TypefaceSpan("monospace"), false);
        } else if (tag.equalsIgnoreCase("center")) {
            end(output, Center.class, new Standard(Alignment.ALIGN_CENTER), true);
        }
    }

    private void start(Editable output, Object mark) {
        int len = output.length();
        output.setSpan(mark, len, len, 17);
    }

    private void end(Editable output, Class kind, Object repl, boolean paragraphStyle) {
        Object obj = getLast(output, kind);
        int where = output.getSpanStart(obj);
        int len = output.length();
        output.removeSpan(obj);
        if (where != len) {
            if (paragraphStyle) {
                output.append("\n");
                len++;
            }
            output.setSpan(repl, where, len, 33);
        }
    }

    private Object getLast(Editable text, Class kind) {
        Object[] objs = text.getSpans(0, text.length(), kind);
        if (objs.length == 0) {
            return null;
        }
        for (int i = objs.length; i > 0; i--) {
            if (text.getSpanFlags(objs[i - 1]) == 17) {
                return objs[i - 1];
            }
        }
        return null;
    }

    private void handleListTag(Editable output) {
        String[] split;
        if (((String) this.mListParents.lastElement()).equals("ul")) {
            output.append("\n");
            split = output.toString().split("\n");
            output.setSpan(new BulletSpan(this.mListParents.size() * 15), (output.length() - split[split.length - 1].length()) - 1, output.length(), 0);
        } else if (((String) this.mListParents.lastElement()).equals("ol")) {
            this.mListItemCount++;
            output.append("\n");
            split = output.toString().split("\n");
            int start = (output.length() - split[split.length - 1].length()) - 1;
            output.insert(start, this.mListItemCount + ". ");
            output.setSpan(new LeadingMarginSpan.Standard(this.mListParents.size() * 15), start, output.length(), 0);
        }
    }
}
