package buildup.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.core.C0338R;
import buildup.dialogs.SelectionDialog;
import buildup.dialogs.SelectionDialog.SelectionListener;
import buildup.util.StringUtils;
import io.buildup.pkg20170504080645.BuildConfig;
import java.util.ArrayList;

public class ListSelectionPicker extends LinearLayout {
    SelectionDialog mDialog;
    String mLabel;
    TextView mLabelView;
    ListSelectedListener mListener;
    TextView mSelectionView;
    private String mTag;
    ArrayList<String> mValues;

    /* renamed from: buildup.views.ListSelectionPicker.1 */
    class C03991 implements SelectionListener {
        C03991() {
        }

        public void onSelected(ArrayList<String> terms) {
            ListSelectionPicker.this.setSelectedValues(terms);
            if (ListSelectionPicker.this.getSelectedListener() != null) {
                ListSelectionPicker.this.getSelectedListener().onSelected(terms);
            }
        }
    }

    /* renamed from: buildup.views.ListSelectionPicker.2 */
    class C04002 implements OnClickListener {
        C04002() {
        }

        public void onClick(View v) {
            Bundle bundle = new Bundle();
            bundle.putStringArrayList(SelectionDialog.INITIAL_VALUES, ListSelectionPicker.this.mValues);
            ListSelectionPicker.this.mDialog.setArguments(bundle);
            ListSelectionPicker.this.mDialog.show(((FragmentActivity) ListSelectionPicker.this.getContext()).getSupportFragmentManager(), ListSelectionPicker.this.mTag);
        }
    }

    public interface ListSelectedListener {
        void onSelected(ArrayList<String> arrayList);
    }

    public ListSelectionPicker(Context context) {
        this(context, null);
    }

    public ListSelectionPicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.ListSelectionPicker, 0, 0);
        this.mLabel = a.getString(C0338R.styleable.ListSelectionPicker_label);
        a.recycle();
        setOrientation(1);
        setGravity(16);
        LayoutInflater.from(context).inflate(C0338R.layout.listselection_picker, this, true);
        this.mLabelView = (TextView) getChildAt(0);
        this.mLabelView.setText(this.mLabel);
        this.mSelectionView = (TextView) getChildAt(1);
        setPicker();
    }

    public void setLabel(String label) {
        this.mLabel = label;
        this.mLabelView.setText(label);
    }

    public ListSelectionPicker setSelectionDialog(SelectionDialog dialog) {
        this.mDialog = dialog;
        if (this.mDialog != null) {
            this.mDialog.setSelectionListener(new C03991());
        }
        return this;
    }

    public ListSelectionPicker setSelectedListener(ListSelectedListener listener) {
        this.mListener = listener;
        return this;
    }

    public ListSelectedListener getSelectedListener() {
        return this.mListener;
    }

    public ListSelectionPicker setTag(String tag) {
        this.mTag = tag;
        return this;
    }

    public ListSelectionPicker setSelectedValues(ArrayList<String> values) {
        this.mValues = values;
        if (this.mValues == null) {
            this.mSelectionView.setText(null);
        } else if (this.mValues.size() == 1 && this.mValues.contains(BuildConfig.FLAVOR)) {
            this.mSelectionView.setText(getContext().getString(C0338R.string.select_empty));
        } else {
            this.mSelectionView.setText(TextUtils.join(", ", StringUtils.replaceNullOrEmptyByText(new ArrayList(values))));
        }
        return this;
    }

    private void setPicker() {
        setOnClickListener(new C04002());
    }
}
