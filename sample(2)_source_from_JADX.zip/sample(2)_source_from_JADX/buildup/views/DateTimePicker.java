package buildup.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.core.C0338R;
import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog;
import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog.OnDateSetListener;
import com.doomonafireball.betterpickers.radialtimepicker.RadialTimePickerDialog;
import com.doomonafireball.betterpickers.radialtimepicker.RadialTimePickerDialog.OnTimeSetListener;
import java.util.Calendar;
import java.util.Date;

public class DateTimePicker extends LinearLayout {
    OnDateSetListener dateCallback;
    Calendar mDateTime;
    TextView mDateView;
    private TextView mErrorView;
    TextView mLabelView;
    DateSelectedListener mListener;
    ImageButton mReset;
    TextView mTimeView;
    OnTimeSetListener timeCallback;

    /* renamed from: buildup.views.DateTimePicker.1 */
    class C03871 implements OnClickListener {
        C03871() {
        }

        public void onClick(View v) {
            DateTimePicker.this.setDateTime(null);
            if (DateTimePicker.this.getListener() != null) {
                DateTimePicker.this.getListener().onDateSelected(null);
            }
        }
    }

    /* renamed from: buildup.views.DateTimePicker.2 */
    class C03882 implements OnClickListener {
        C03882() {
        }

        public void onClick(View v) {
            Calendar cal = DateTimePicker.this.mDateTime;
            if (cal == null) {
                cal = Calendar.getInstance();
            }
            FragmentManager fm = ((FragmentActivity) DateTimePicker.this.getContext()).getSupportFragmentManager();
            CalendarDatePickerDialog calendarDatePickerDialog = (CalendarDatePickerDialog) fm.findFragmentByTag("DatePicker");
            if (calendarDatePickerDialog == null) {
                calendarDatePickerDialog = CalendarDatePickerDialog.newInstance(DateTimePicker.this.dateCallback, cal.get(1), cal.get(2), cal.get(5));
            } else {
                calendarDatePickerDialog.setOnDateSetListener(DateTimePicker.this.dateCallback);
            }
            calendarDatePickerDialog.show(fm, "DatePicker");
        }
    }

    /* renamed from: buildup.views.DateTimePicker.3 */
    class C03893 implements OnClickListener {
        C03893() {
        }

        public void onClick(View v) {
            Calendar cal = DateTimePicker.this.mDateTime;
            if (cal == null) {
                cal = Calendar.getInstance();
            }
            FragmentManager fm = ((FragmentActivity) DateTimePicker.this.getContext()).getSupportFragmentManager();
            RadialTimePickerDialog radialTimePickerDialog = (RadialTimePickerDialog) fm.findFragmentByTag("TimePicker");
            if (radialTimePickerDialog == null) {
                radialTimePickerDialog = RadialTimePickerDialog.newInstance(DateTimePicker.this.timeCallback, cal.get(11), cal.get(12), false);
            } else {
                radialTimePickerDialog.setOnTimeSetListener(DateTimePicker.this.timeCallback);
            }
            radialTimePickerDialog.show(fm, "TimePicker");
        }
    }

    /* renamed from: buildup.views.DateTimePicker.4 */
    class C03904 extends AnimatorListenerAdapter {
        C03904() {
        }

        public void onAnimationEnd(Animator animation) {
            DateTimePicker.this.mErrorView.setText((CharSequence) null);
            DateTimePicker.this.mErrorView.setVisibility(8);
        }
    }

    /* renamed from: buildup.views.DateTimePicker.5 */
    class C03915 implements OnDateSetListener {
        C03915() {
        }

        public void onDateSet(CalendarDatePickerDialog calendarDatePickerDialog, int year, int month, int day) {
            Calendar cal = Calendar.getInstance();
            cal.set(year, month, day, 0, 0, 0);
            DateTimePicker.this.setDate(cal.getTime());
            DateTimePicker.this.notifyListener();
        }
    }

    /* renamed from: buildup.views.DateTimePicker.6 */
    class C03926 implements OnTimeSetListener {
        C03926() {
        }

        public void onTimeSet(RadialTimePickerDialog radialTimePickerDialog, int h, int m) {
            Calendar cal = Calendar.getInstance();
            cal.set(11, h);
            cal.set(12, m);
            cal.set(13, 0);
            cal.set(14, 0);
            DateTimePicker.this.setTime(cal.getTime());
            DateTimePicker.this.notifyListener();
        }
    }

    public interface DateSelectedListener {
        void onDateSelected(Date date);
    }

    public DateTimePicker(Context context) {
        this(context, null);
    }

    public DateTimePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.dateCallback = new C03915();
        this.timeCallback = new C03926();
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.DateTimePicker, 0, 0);
        String label = a.getString(C0338R.styleable.DateTimePicker_label);
        a.recycle();
        setOrientation(1);
        setGravity(16);
        LayoutInflater.from(context).inflate(C0338R.layout.datetime_picker, this, true);
        this.mLabelView = (TextView) getChildAt(0);
        this.mLabelView.setText(label);
        this.mDateView = (TextView) findViewById(C0338R.id.dateValue);
        this.mTimeView = (TextView) findViewById(C0338R.id.timeValue);
        this.mReset = (ImageButton) findViewById(C0338R.id.dateReset);
        this.mErrorView = (TextView) findViewById(C0338R.id.errorView);
        setDatePicker(this.mDateView, true);
        setTimePicker(this.mTimeView, false);
        setResetHandler();
    }

    private void setResetHandler() {
        this.mReset.setOnClickListener(new C03871());
    }

    public void setLabel(String label) {
        this.mLabelView.setText(label);
    }

    public DateTimePicker setDate(Date date) {
        if (date != null) {
            if (this.mDateTime == null) {
                this.mDateTime = Calendar.getInstance();
                this.mDateTime.setTime(date);
            } else {
                Calendar from = Calendar.getInstance();
                from.setTime(date);
                this.mDateTime.set(from.get(1), from.get(2), from.get(5));
            }
            setDateText(this.mDateView, this.mDateTime);
        }
        return this;
    }

    public DateTimePicker setTime(Date date) {
        if (date != null) {
            if (this.mDateTime == null) {
                this.mDateTime = Calendar.getInstance();
                this.mDateTime.setTime(date);
            } else {
                Calendar from = Calendar.getInstance();
                from.setTime(date);
                this.mDateTime.set(11, from.get(11));
                this.mDateTime.set(12, from.get(12));
                this.mDateTime.set(13, from.get(13));
                this.mDateTime.set(14, from.get(14));
            }
            setTimeText(this.mTimeView, this.mDateTime);
        }
        return this;
    }

    public DateTimePicker setDateTime(Date date) {
        if (date != null) {
            if (this.mDateTime == null) {
                this.mDateTime = Calendar.getInstance();
            }
            this.mDateTime.setTime(date);
        } else {
            this.mDateTime = null;
        }
        setDateText(this.mDateView, this.mDateTime);
        setTimeText(this.mTimeView, this.mDateTime);
        return this;
    }

    public DateTimePicker setDateTimeSelectedListener(DateSelectedListener listener) {
        this.mListener = listener;
        return this;
    }

    public DateSelectedListener getListener() {
        return this.mListener;
    }

    private void setDateText(TextView view, Calendar cal) {
        view.setText(cal != null ? DateFormat.getMediumDateFormat(getContext()).format(cal.getTime()) : null);
    }

    private void setTimeText(TextView mTimeView, Calendar mDateTime) {
        mTimeView.setText(mDateTime != null ? DateFormat.getTimeFormat(getContext()).format(mDateTime.getTime()) : null);
    }

    private void setDatePicker(TextView view, boolean isMin) {
        view.setOnClickListener(new C03882());
    }

    private void setTimePicker(TextView view, boolean isMin) {
        view.setOnClickListener(new C03893());
    }

    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        if (this.mDateTime != null) {
            bundle.putLong("datetime", this.mDateTime.getTime().getTime());
        }
        return bundle;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            long datetimeVal = ((Bundle) state).getLong("datetime", -1);
            if (datetimeVal != -1) {
                setDateTime(new Date(datetimeVal));
            }
            state = ((Bundle) state).getParcelable("instanceState");
        }
        super.onRestoreInstanceState(state);
    }

    public void setError(int errorRes) {
        setError(getContext().getString(errorRes));
    }

    public void setError(CharSequence errorMsg) {
        if (errorMsg == null) {
            this.mErrorView.animate().alpha(0.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(new C03904());
        } else if (this.mErrorView.getVisibility() == 8) {
            this.mErrorView.setText(errorMsg);
            this.mErrorView.setAlpha(0.0f);
            this.mErrorView.setVisibility(0);
            this.mErrorView.animate().alpha(1.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(null).start();
        }
    }

    private void notifyListener() {
        if (getListener() != null) {
            getListener().onDateSelected(this.mDateTime.getTime());
        }
    }
}
