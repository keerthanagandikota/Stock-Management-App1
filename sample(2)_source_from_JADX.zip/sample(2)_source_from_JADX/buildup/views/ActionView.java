package buildup.views;

import android.content.Context;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.core.C0338R;

public class ActionView extends LinearLayout {
    public ActionView(Context context) {
        super(context);
        LayoutInflater inflater = (LayoutInflater) context.getSystemService("layout_inflater");
        if (inflater != null) {
            inflater.inflate(C0338R.layout.drawer_item, this).setBackgroundColor(getResources().getColor(C0338R.color.window_background));
        }
    }

    public void setText(String s) {
        ((TextView) findViewById(16908308)).setText(s);
    }
}
