package buildup.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.core.C0338R;
import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog;
import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog.OnDateSetListener;
import java.util.Calendar;
import java.util.Date;

public class DateRangePicker extends LinearLayout {
    private TextView mErrorView;
    TextView mLabelView;
    DateRangeSelectedListener mListener;
    Date mMaxDate;
    TextView mMaxDateView;
    Date mMinDate;
    TextView mMinDateView;

    /* renamed from: buildup.views.DateRangePicker.1 */
    class C03851 implements OnClickListener {
        final /* synthetic */ boolean val$isMin;
        final /* synthetic */ TextView val$view;

        /* renamed from: buildup.views.DateRangePicker.1.1 */
        class C03841 implements OnDateSetListener {
            C03841() {
            }

            public void onDateSet(CalendarDatePickerDialog calendarDatePickerDialog, int year, int month, int day) {
                Calendar cal = Calendar.getInstance();
                cal.set(year, month, day, 0, 0, 0);
                if (C03851.this.val$isMin) {
                    DateRangePicker.this.mMinDate = cal.getTime();
                } else {
                    DateRangePicker.this.mMaxDate = cal.getTime();
                }
                DateRangePicker.this.setDateText(C03851.this.val$view, cal.getTime(), C03851.this.val$isMin);
                if (DateRangePicker.this.getListener() != null) {
                    DateRangePicker.this.getListener().onRangeSelected(DateRangePicker.this.mMinDate, DateRangePicker.this.mMaxDate);
                }
            }
        }

        C03851(boolean z, TextView textView) {
            this.val$isMin = z;
            this.val$view = textView;
        }

        public void onClick(View v) {
            Calendar cal = Calendar.getInstance();
            if (this.val$isMin && DateRangePicker.this.mMinDate != null) {
                cal.setTime(DateRangePicker.this.mMinDate);
            } else if (!(this.val$isMin || DateRangePicker.this.mMaxDate == null)) {
                cal.setTime(DateRangePicker.this.mMaxDate);
            }
            FragmentManager fm = ((FragmentActivity) DateRangePicker.this.getContext()).getSupportFragmentManager();
            CalendarDatePickerDialog calendarDatePickerDialog = (CalendarDatePickerDialog) fm.findFragmentByTag("DatePicker");
            OnDateSetListener callback = new C03841();
            if (calendarDatePickerDialog == null) {
                calendarDatePickerDialog = CalendarDatePickerDialog.newInstance(callback, cal.get(1), cal.get(2), cal.get(5));
            } else {
                calendarDatePickerDialog.setOnDateSetListener(callback);
            }
            calendarDatePickerDialog.show(fm, "DatePicker");
        }
    }

    /* renamed from: buildup.views.DateRangePicker.2 */
    class C03862 extends AnimatorListenerAdapter {
        C03862() {
        }

        public void onAnimationEnd(Animator animation) {
            DateRangePicker.this.mErrorView.setText((CharSequence) null);
            DateRangePicker.this.mErrorView.setVisibility(8);
        }
    }

    public interface DateRangeSelectedListener {
        void onRangeSelected(Date date, Date date2);
    }

    public DateRangePicker(Context context) {
        this(context, null);
    }

    public DateRangePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.DateRangePicker, 0, 0);
        String label = a.getString(C0338R.styleable.DateRangePicker_label);
        a.recycle();
        setOrientation(1);
        setGravity(16);
        LayoutInflater.from(context).inflate(C0338R.layout.daterange_picker, this, true);
        this.mLabelView = (TextView) getChildAt(0);
        this.mLabelView.setText(label);
        this.mErrorView = (TextView) findViewById(C0338R.id.errorView);
        this.mMinDateView = (TextView) findViewById(C0338R.id.min_value);
        this.mMaxDateView = (TextView) findViewById(C0338R.id.max_value);
        setPicker(this.mMinDateView, true);
        setPicker(this.mMaxDateView, false);
    }

    public void setLabel(String label) {
        this.mLabelView.setText(label);
    }

    public DateRangePicker setMinDate(Date date) {
        this.mMinDate = date;
        setDateText(this.mMinDateView, date, true);
        return this;
    }

    public DateRangePicker setMaxDate(Date date) {
        this.mMaxDate = date;
        setDateText(this.mMaxDateView, date, false);
        return this;
    }

    public DateRangePicker setRangeSelectedListener(DateRangeSelectedListener listener) {
        this.mListener = listener;
        return this;
    }

    public DateRangeSelectedListener getListener() {
        return this.mListener;
    }

    private void setDateText(TextView view, Date date, boolean min) {
        CharSequence format;
        if (date != null) {
            format = String.format(getResources().getString(min ? C0338R.string.datemin_filter_format : C0338R.string.datemax_filter_format), new Object[]{DateFormat.getMediumDateFormat(getContext()).format(date)});
        } else {
            format = null;
        }
        view.setText(format);
    }

    private void setPicker(TextView view, boolean isMin) {
        view.setOnClickListener(new C03851(isMin, view));
    }

    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        if (this.mMinDate != null) {
            bundle.putLong("rangeMin", this.mMinDate.getTime());
        }
        if (this.mMaxDate != null) {
            bundle.putLong("rangeMax", this.mMaxDate.getTime());
        }
        return bundle;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            Bundle b = (Bundle) state;
            long minVal = b.getLong("rangeMin", -1);
            long maxVal = b.getLong("rangeMax", -1);
            if (minVal != -1) {
                this.mMinDate = new Date(minVal);
            }
            if (maxVal != -1) {
                this.mMaxDate = new Date(maxVal);
            }
            state = ((Bundle) state).getParcelable("instanceState");
        }
        super.onRestoreInstanceState(state);
    }

    public void setError(int errorRes) {
        setError(getContext().getString(errorRes));
    }

    public void setError(CharSequence errorMsg) {
        if (errorMsg == null) {
            this.mErrorView.animate().alpha(0.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(new C03862());
        } else if (this.mErrorView.getVisibility() == 8) {
            this.mErrorView.setText(errorMsg);
            this.mErrorView.setAlpha(0.0f);
            this.mErrorView.setVisibility(0);
            this.mErrorView.animate().alpha(1.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(null).start();
        }
    }
}
