package buildup.views;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import buildup.core.C0338R;

public class TristateBooleanPicker extends LinearLayout {
    private ChoiceListener mClickListener;
    private final Spinner mSpinner;
    Boolean mValue;

    /* renamed from: buildup.views.TristateBooleanPicker.1 */
    class C04011 implements OnItemSelectedListener {
        C04011() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            Boolean bool;
            boolean z = true;
            TristateBooleanPicker tristateBooleanPicker = TristateBooleanPicker.this;
            if (position == 2) {
                bool = null;
            } else {
                if (position == 1) {
                    z = false;
                }
                bool = Boolean.valueOf(z);
            }
            tristateBooleanPicker.mValue = bool;
            if (TristateBooleanPicker.this.getListener() != null) {
                TristateBooleanPicker.this.getListener().onChoice(TristateBooleanPicker.this.mValue);
            }
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    public interface ChoiceListener {
        void onChoice(Boolean bool);
    }

    public TristateBooleanPicker(Context context) {
        this(context, null);
    }

    public TristateBooleanPicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mValue = null;
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.DateTimePicker, 0, 0);
        String label = a.getString(C0338R.styleable.TristateBooleanPicker_label);
        a.recycle();
        setOrientation(0);
        setGravity(16);
        LayoutInflater.from(context).inflate(C0338R.layout.tristate_picker, this, true);
        ((TextView) findViewById(C0338R.id.label)).setText(label);
        this.mSpinner = (Spinner) findViewById(C0338R.id.spinner);
        ArrayAdapter<String> mAdapter = new ArrayAdapter(getContext(), C0338R.layout.tristate_picker_item_collapsed);
        mAdapter.addAll(new String[]{getResources().getString(17039379), getResources().getString(17039369), getResources().getString(C0338R.string.not_set)});
        mAdapter.setDropDownViewResource(C0338R.layout.tristate_picker_item);
        this.mSpinner.setAdapter(mAdapter);
        this.mSpinner.setOnItemSelectedListener(new C04011());
        setValue(null);
    }

    protected Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("instanceState", super.onSaveInstanceState());
        if (this.mValue != null) {
            bundle.putInt("boolVal", this.mValue.booleanValue() ? 0 : 1);
        }
        return bundle;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof Bundle) {
            int storedVal = ((Bundle) state).getInt("boolVal", -1);
            if (storedVal != -1) {
                setValue(Boolean.valueOf(storedVal == 0));
            } else {
                setValue(null);
            }
            state = ((Bundle) state).getParcelable("instanceState");
        }
        super.onRestoreInstanceState(state);
    }

    public void setValue(Boolean choice) {
        this.mValue = choice;
        if (choice == null) {
            this.mSpinner.setSelection(2);
        } else {
            this.mSpinner.setSelection(choice.booleanValue() ? 0 : 1);
        }
    }

    public Boolean getValue() {
        return this.mValue;
    }

    public void setListener(ChoiceListener listener) {
        this.mClickListener = listener;
    }

    public ChoiceListener getListener() {
        return this.mClickListener;
    }
}
