package buildup.views;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.TypedArray;
import android.location.Location;
import android.location.LocationManager;
import android.support.design.widget.Snackbar;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.text.Editable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.core.C0338R;
import buildup.ds.restds.GeoPoint;
import buildup.injectors.ApplicationInjector;

public class GeoPicker extends LinearLayout {
    private static final String TAG;
    private final TextView mErrorView;
    private GeoPoint mGeoPoint;
    private final EditText mLatitudeView;
    private PointChangedListener mListener;
    private final EditText mLongitudeView;

    /* renamed from: buildup.views.GeoPicker.1 */
    class C03931 implements OnClickListener {
        final /* synthetic */ Context val$context;

        C03931(Context context) {
            this.val$context = context;
        }

        public void onClick(View v) {
            if (GeoPicker.this.getLastKnownLocation() != null) {
                GeoPicker.this.setPoint(new GeoPoint(new double[]{loc.getLongitude(), loc.getLatitude()}));
                return;
            }
            Snackbar.make(v, this.val$context.getString(C0338R.string.error_location_unavailable), -1).show();
        }
    }

    /* renamed from: buildup.views.GeoPicker.2 */
    class C03942 extends AnimatorListenerAdapter {
        C03942() {
        }

        public void onAnimationEnd(Animator animation) {
            GeoPicker.this.mErrorView.setText((CharSequence) null);
            GeoPicker.this.mErrorView.setVisibility(8);
        }
    }

    /* renamed from: buildup.views.GeoPicker.3 */
    class C03953 extends TextWatcherAdapter {
        C03953() {
        }

        public void afterTextChanged(Editable s) {
            Double value = null;
            try {
                value = Double.valueOf(Double.parseDouble(s.toString()));
            } catch (NumberFormatException e) {
                AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException(GeoPicker.TAG, "parseDouble", e);
            }
            GeoPicker.this.setLatitude(value);
        }
    }

    /* renamed from: buildup.views.GeoPicker.4 */
    class C03964 extends TextWatcherAdapter {
        C03964() {
        }

        public void afterTextChanged(Editable s) {
            Double value = null;
            try {
                value = Double.valueOf(Double.parseDouble(s.toString()));
            } catch (NumberFormatException e) {
                AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException(GeoPicker.TAG, "parseDouble", e);
            }
            GeoPicker.this.setLongitude(value);
        }
    }

    public interface PointChangedListener {
        void onPointChanged(GeoPoint geoPoint);
    }

    static {
        TAG = GeoPicker.class.getSimpleName();
    }

    public GeoPicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.obtainStyledAttributes(attrs, C0338R.styleable.GeoPicker, 0, 0);
        String label = a.getString(C0338R.styleable.GeoPicker_label);
        a.recycle();
        setOrientation(1);
        setGravity(17);
        LayoutInflater.from(context).inflate(C0338R.layout.geopoint_picker, this, true);
        ((TextView) getChildAt(0)).setText(label);
        this.mLatitudeView = (EditText) findViewById(C0338R.id.latitude);
        this.mLongitudeView = (EditText) findViewById(C0338R.id.longitude);
        ((ImageButton) findViewById(C0338R.id.my_location_button)).setOnClickListener(new C03931(context));
        this.mErrorView = (TextView) findViewById(C0338R.id.error);
        setWatchers();
    }

    public GeoPicker setPoint(GeoPoint point) {
        this.mGeoPoint = point;
        updateViews();
        notifyListener();
        return this;
    }

    protected void notifyListener() {
        if (getListener() != null) {
            getListener().onPointChanged(this.mGeoPoint);
        }
    }

    public PointChangedListener getListener() {
        return this.mListener;
    }

    public GeoPoint getPoint() {
        return this.mGeoPoint;
    }

    public GeoPicker setListener(PointChangedListener listener) {
        this.mListener = listener;
        return this;
    }

    public void setError(int error) {
        setError(getContext().getString(error));
    }

    public void setError(String errorMsg) {
        if (errorMsg == null) {
            this.mErrorView.animate().alpha(0.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(new C03942());
        } else if (this.mErrorView.getVisibility() == 8) {
            this.mErrorView.setText(errorMsg);
            this.mErrorView.setAlpha(0.0f);
            this.mErrorView.setVisibility(0);
            this.mErrorView.animate().alpha(1.0f).setDuration(200).setInterpolator(new FastOutSlowInInterpolator()).setListener(null).start();
        }
    }

    private void setWatchers() {
        this.mLatitudeView.addTextChangedListener(new C03953());
        this.mLongitudeView.addTextChangedListener(new C03964());
    }

    private void setLatitude(Double latitude) {
        if (latitude != null) {
            createGeoPoint();
            this.mGeoPoint.coordinates[1] = latitude.doubleValue();
            notifyListener();
        }
    }

    private void setLongitude(Double longitude) {
        if (longitude != null) {
            createGeoPoint();
            this.mGeoPoint.coordinates[0] = longitude.doubleValue();
            notifyListener();
        }
    }

    private void updateViews() {
        CharSequence format;
        CharSequence charSequence = null;
        EditText editText = this.mLatitudeView;
        if (this.mGeoPoint != null) {
            format = String.format("%.3f", new Object[]{Double.valueOf(this.mGeoPoint.coordinates[1])});
        } else {
            format = null;
        }
        editText.setText(format);
        EditText editText2 = this.mLongitudeView;
        if (this.mGeoPoint != null) {
            charSequence = String.format("%.3f", new Object[]{Double.valueOf(this.mGeoPoint.coordinates[0])});
        }
        editText2.setText(charSequence);
    }

    private void createGeoPoint() {
        if (this.mGeoPoint == null) {
            this.mGeoPoint = new GeoPoint();
        }
    }

    private Location getLastKnownLocation() {
        LocationManager lm = (LocationManager) ApplicationInjector.getApplicationContext().getSystemService("location");
        Location bestLocation = null;
        for (String provider : lm.getProviders(true)) {
            Location l = lm.getLastKnownLocation(provider);
            if (l != null && (bestLocation == null || l.getAccuracy() < bestLocation.getAccuracy())) {
                bestLocation = l;
            }
        }
        return bestLocation;
    }
}
