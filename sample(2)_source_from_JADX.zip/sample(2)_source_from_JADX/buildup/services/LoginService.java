package buildup.services;

public interface LoginService {
    void attemptLogin(String str, String str2);
}
