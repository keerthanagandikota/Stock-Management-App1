package buildup.services;

import android.os.AsyncTask;
import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import android.util.Base64;
import android.util.Log;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;
import buildup.util.LoginUtils;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

public class DefaultLoginService extends AsyncTask<Void, Void, Map<String, String>> implements LoginService {
    private HttpClient httpclient;
    private String mEmail;
    private String mPassword;
    private String mServerUrl;

    public DefaultLoginService(String serverUrl) {
        this.mServerUrl = serverUrl;
        this.httpclient = new DefaultHttpClient();
    }

    protected Map<String, String> doInBackground(Void... params) {
        HttpUriRequest request = new HttpPost(this.mServerUrl);
        request.addHeader("Authorization", "Basic " + Base64.encodeToString((this.mEmail + ":" + this.mPassword).getBytes(), 2));
        HttpResponse response = null;
        Map<String, String> responseParams = new HashMap();
        try {
            response = this.httpclient.execute(request);
        } catch (IOException e) {
            AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("DefaultLoginService", "Client execute", e);
            Log.e("clientExecute", e.getMessage());
        }
        if (response != null && response.getStatusLine().getStatusCode() == Callback.DEFAULT_DRAG_ANIMATION_DURATION) {
            JSONObject json = LoginUtils.parseJSON(LoginUtils.getResponseString(response));
            try {
                responseParams.put(LoginUtils.EXPIRATION_TIME, json.getString("expirationTime"));
                responseParams.put(LoginUtils.TOKEN, json.getString("token"));
            } catch (JSONException e2) {
                AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("DefaultLoginService", "jsonGetLong", e2);
                Log.e("jsonGetLong", e2.getMessage());
            }
        }
        return responseParams;
    }

    public void attemptLogin(String email, String password) {
        this.mEmail = email;
        this.mPassword = password;
        execute(new Void[0]);
    }
}
