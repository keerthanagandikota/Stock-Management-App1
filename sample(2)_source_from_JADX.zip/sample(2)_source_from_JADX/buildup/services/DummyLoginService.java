package buildup.services;

import android.os.AsyncTask;

public class DummyLoginService extends AsyncTask<Void, Void, Boolean> implements LoginService {
    private static final String[] DUMMY_CREDENTIALS;
    private String mEmail;
    private String mPassword;

    static {
        DUMMY_CREDENTIALS = new String[]{"test@icinetic.com:icinetic"};
    }

    protected Boolean doInBackground(Void... voids) {
        try {
            Thread.sleep(2000);
            for (String credential : DUMMY_CREDENTIALS) {
                String[] pieces = credential.split(":");
                if (pieces[0].equals(this.mEmail)) {
                    return Boolean.valueOf(pieces[1].equals(this.mPassword));
                }
            }
            return Boolean.valueOf(true);
        } catch (InterruptedException e) {
            return Boolean.valueOf(false);
        }
    }

    public void attemptLogin(String email, String password) {
        this.mEmail = email;
        this.mPassword = password;
        execute(new Void[0]);
    }
}
