package buildup.dialogs;

import android.support.v4.app.DialogFragment;
import java.util.ArrayList;

public abstract class SelectionDialog extends DialogFragment {
    public static final String INITIAL_VALUES = "InitialValues";
    protected boolean haveSearch;
    protected boolean multipleChoice;
    protected SelectionListener selectionListener;
    protected String title;

    public interface SelectionListener {
        void onSelected(ArrayList<String> arrayList);
    }

    public SelectionDialog setMultipleChoice(boolean multipleChoice) {
        this.multipleChoice = multipleChoice;
        return this;
    }

    public SelectionDialog setHaveSearch(boolean hs) {
        this.haveSearch = hs;
        return this;
    }

    public SelectionDialog setTitle(String title) {
        this.title = title;
        return this;
    }

    public void setSelectionListener(SelectionListener listener) {
        this.selectionListener = listener;
    }
}
