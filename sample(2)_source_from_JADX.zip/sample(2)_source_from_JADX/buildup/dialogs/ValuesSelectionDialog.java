package buildup.dialogs;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.SearchView.OnCloseListener;
import android.support.v7.widget.SearchView.OnQueryTextListener;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import buildup.core.C0338R;
import buildup.ds.Datasource;
import buildup.ds.Datasource.Listener;
import buildup.ds.Distinct;
import buildup.ds.SearchOptions;
import buildup.util.StringUtils;
import io.buildup.pkg20170504080645.BuildConfig;
import java.util.ArrayList;
import java.util.List;

public class ValuesSelectionDialog extends SelectionDialog {
    private ArrayAdapter<String> adapter;
    private boolean canceled;
    private ArrayList<String> checkedValues;
    private String columnName;
    private Distinct datasource;
    private boolean isFiltering;
    private ListView listView;
    private SearchOptions searchOptions;

    /* renamed from: buildup.dialogs.ValuesSelectionDialog.1 */
    class C03421 implements OnQueryTextListener {
        C03421() {
        }

        public boolean onQueryTextSubmit(String s) {
            if (BuildConfig.FLAVOR.equals(s)) {
                return false;
            }
            ValuesSelectionDialog.this.isFiltering = true;
            ValuesSelectionDialog.this.adapter.getFilter().filter(s);
            ValuesSelectionDialog.this.listView.clearChoices();
            return true;
        }

        public boolean onQueryTextChange(String s) {
            return false;
        }
    }

    /* renamed from: buildup.dialogs.ValuesSelectionDialog.2 */
    class C03432 implements OnCloseListener {
        C03432() {
        }

        public boolean onClose() {
            if (!ValuesSelectionDialog.this.isFiltering) {
                return false;
            }
            ValuesSelectionDialog.this.adapter.getFilter().filter(null);
            ValuesSelectionDialog.this.isFiltering = false;
            return true;
        }
    }

    /* renamed from: buildup.dialogs.ValuesSelectionDialog.3 */
    class C03443 implements OnClickListener {
        C03443() {
        }

        public void onClick(View v) {
            ValuesSelectionDialog.this.dismiss();
        }
    }

    /* renamed from: buildup.dialogs.ValuesSelectionDialog.4 */
    class C03454 implements Listener<List<String>> {
        C03454() {
        }

        public void onSuccess(List<String> objects) {
            ValuesSelectionDialog.this.adapter.clear();
            ValuesSelectionDialog.this.adapter.addAll(new ArrayList(StringUtils.replaceNullOrEmptyByText(objects)));
        }

        public void onFailure(Exception e) {
            ValuesSelectionDialog.this.dismiss();
        }
    }

    /* renamed from: buildup.dialogs.ValuesSelectionDialog.5 */
    class C03465 extends ArrayAdapter<String> {
        C03465(Context x0, int x1) {
            super(x0, x1);
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            String value = (String) ValuesSelectionDialog.this.adapter.getItem(position);
            if (value.equals(ValuesSelectionDialog.this.getString(C0338R.string.select_empty))) {
                value = BuildConfig.FLAVOR;
            }
            if (ValuesSelectionDialog.this.checkedValues != null && ValuesSelectionDialog.this.checkedValues.contains(value)) {
                ValuesSelectionDialog.this.listView.setItemChecked(position, true);
            }
            return super.getView(position, convertView, parent);
        }
    }

    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity(), VERSION.SDK_INT > 19 ? C0338R.style.SelectionDialog : C0338R.style.SelectionDialog_PreL);
        LayoutInflater inflater = getActivity().getLayoutInflater();
        this.canceled = false;
        View view = inflater.inflate(C0338R.layout.selection_dialog, null);
        this.listView = (ListView) view.findViewById(16908298);
        createAdapter();
        this.listView.setAdapter(this.adapter);
        this.listView.setChoiceMode(this.multipleChoice ? 2 : 1);
        if (this.haveSearch) {
            SearchView searchView = (SearchView) view.findViewById(C0338R.id.search);
            searchView.setVisibility(0);
            searchView.setOnQueryTextListener(new C03421());
            searchView.setOnCloseListener(new C03432());
        }
        ((Button) view.findViewById(C0338R.id.search_btn)).setOnClickListener(new C03443());
        if (getArguments() != null) {
            this.checkedValues = getArguments().getStringArrayList(SelectionDialog.INITIAL_VALUES);
        }
        builder.setTitle(this.title).setView(view);
        if (this.datasource != null) {
            this.datasource.getUniqueValuesFor(this.columnName, new C03454());
        }
        builder.setTitle(this.title);
        return builder.create();
    }

    public ValuesSelectionDialog setDatasource(Datasource datasource) {
        if (datasource instanceof Distinct) {
            this.datasource = (Distinct) datasource;
            return this;
        }
        throw new IllegalArgumentException("Datasource must implement Distinct interface");
    }

    public ValuesSelectionDialog setSearchOptions(SearchOptions searchOptions) {
        this.searchOptions = searchOptions;
        return this;
    }

    public ValuesSelectionDialog setColumnName(String columnName) {
        this.columnName = columnName;
        return this;
    }

    private void createAdapter() {
        int i;
        Context activity = getActivity();
        if (this.multipleChoice) {
            i = C0338R.layout.dialog_item_multiple_choice;
        } else {
            i = C0338R.layout.dialog_item_single_choice;
        }
        this.adapter = new C03465(activity, i);
    }

    public void onCancel(DialogInterface dialog) {
        super.onCancel(dialog);
        this.canceled = true;
    }

    public void onDismiss(DialogInterface dialog) {
        if (!(this.canceled || this.selectionListener == null)) {
            SparseBooleanArray checked = this.listView.getCheckedItemPositions();
            ArrayList<String> res = new ArrayList(checked.size());
            for (int i = 0; i < checked.size(); i++) {
                if (checked.valueAt(i)) {
                    String item = (String) this.adapter.getItem(checked.keyAt(i));
                    if (item.equals(getString(C0338R.string.select_empty))) {
                        item = BuildConfig.FLAVOR;
                    }
                    res.add(item);
                }
            }
            this.selectionListener.onSelected(res);
        }
        super.onDismiss(dialog);
    }
}
