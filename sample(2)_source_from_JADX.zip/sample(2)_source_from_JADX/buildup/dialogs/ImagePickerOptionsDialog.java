package buildup.dialogs;

import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import buildup.core.C0338R;
import java.util.Arrays;
import org.jraf.android.backport.switchwidget.C0678R;

public class ImagePickerOptionsDialog extends DialogFragment {
    private OnOptionSelectedListener mListener;
    boolean removeEnabled;

    /* renamed from: buildup.dialogs.ImagePickerOptionsDialog.1 */
    class C03411 implements OnClickListener {
        C03411() {
        }

        public void onClick(DialogInterface dialog, int which) {
            OnOptionSelectedListener listener = ImagePickerOptionsDialog.this.getListener();
            if (listener != null) {
                switch (which) {
                    case C0678R.styleable.Switch_asb_thumb /*0*/:
                        listener.fromCamera();
                    case C0678R.styleable.Switch_asb_track /*1*/:
                        listener.fromStorage();
                    case C0678R.styleable.Switch_asb_textOn /*2*/:
                        listener.remove();
                    default:
                }
            }
        }
    }

    public interface OnOptionSelectedListener {
        void fromCamera();

        void fromStorage();

        void remove();
    }

    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity(), getTheme());
        String[] actions = getResources().getStringArray(C0338R.array.image_picker_actions);
        if (!getRemoveEnabled()) {
            actions = (String[]) Arrays.copyOf(actions, 2);
        }
        builder.setItems(actions, new C03411());
        return builder.create();
    }

    public void setRemoveEnabled(boolean re) {
        this.removeEnabled = re;
    }

    public boolean getRemoveEnabled() {
        return this.removeEnabled;
    }

    public void setListener(OnOptionSelectedListener listener) {
        this.mListener = listener;
    }

    public OnOptionSelectedListener getListener() {
        return this.mListener;
    }
}
