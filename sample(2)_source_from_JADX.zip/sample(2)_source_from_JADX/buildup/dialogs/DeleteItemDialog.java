package buildup.dialogs;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import buildup.core.C0338R;

public class DeleteItemDialog extends DialogFragment {
    private DeleteItemListener listener;

    /* renamed from: buildup.dialogs.DeleteItemDialog.1 */
    class C03391 implements OnClickListener {
        C03391() {
        }

        public void onClick(DialogInterface dialog, int which) {
            DeleteItemDialog.this.listener.deleteItem(false);
        }
    }

    /* renamed from: buildup.dialogs.DeleteItemDialog.2 */
    class C03402 implements OnClickListener {
        C03402() {
        }

        public void onClick(DialogInterface dialog, int which) {
            DeleteItemDialog.this.listener.deleteItem(true);
        }
    }

    public interface DeleteItemListener {
        void deleteItem(boolean z);
    }

    public DeleteItemDialog(DeleteItemListener listener) {
        this.listener = listener;
    }

    @NonNull
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        setRetainInstance(true);
        return createDeleteItemDialog();
    }

    public AlertDialog createDeleteItemDialog() {
        Builder builder = new Builder(getActivity(), VERSION.SDK_INT > 19 ? C0338R.style.SelectionDialog : C0338R.style.SelectionDialog_PreL);
        builder.setTitle(getString(C0338R.string.dialog_delete_title)).setMessage(getString(C0338R.string.dialog_delete_message)).setPositiveButton(getString(C0338R.string.button_ok), new C03402()).setNegativeButton(getString(C0338R.string.button_cancel), new C03391());
        return builder.create();
    }
}
