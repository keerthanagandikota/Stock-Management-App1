package buildup.gson;

import android.util.Log;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;

public class DecimalJsonTypeAdapter implements JsonDeserializer<Double>, JsonSerializer<Double> {
    public Double deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        String jsonDouble = json.getAsString();
        Double res = Double.valueOf(0.0d);
        try {
            res = Double.valueOf(Double.parseDouble(jsonDouble));
        } catch (Exception e) {
            AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("DecimalJsonTypeAdapter", "ParseError", e);
            Log.d("ParseError", e.getMessage());
        }
        return res;
    }

    public JsonElement serialize(Double src, Type typeOfSrc, JsonSerializationContext context) {
        return new JsonPrimitive((Number) src);
    }
}
