package buildup.gson;

import android.util.Log;
import buildup.analytics.injector.AnalyticsReporterInjector;
import buildup.injectors.ApplicationInjector;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class DateJsonTypeAdapter implements JsonDeserializer<Date>, JsonSerializer<Date> {
    private static final String DEFAULT_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
    private static final String[] ISO_FORMATS;

    static {
        ISO_FORMATS = new String[]{DEFAULT_FORMAT, "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd", "yyyyMMdd", "yy-MM-dd", "yyMMdd"};
    }

    public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
        String jsonDate = json.getAsString();
        String[] strArr = ISO_FORMATS;
        int length = strArr.length;
        int i = 0;
        while (i < length) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat(strArr[i]);
                sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                return sdf.parse(jsonDate);
            } catch (Exception e) {
                AnalyticsReporterInjector.analyticsReporter(ApplicationInjector.getApplicationContext()).sendHandledException("DateJsonTypeAdapter", "ParseError", e);
                Log.d("ParseError", e.getMessage());
                i++;
            }
        }
        return null;
    }

    public JsonElement serialize(Date src, Type typeOfSrc, JsonSerializationContext context) {
        SimpleDateFormat sdf = new SimpleDateFormat(DEFAULT_FORMAT);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return new JsonPrimitive(sdf.format(src));
    }
}
