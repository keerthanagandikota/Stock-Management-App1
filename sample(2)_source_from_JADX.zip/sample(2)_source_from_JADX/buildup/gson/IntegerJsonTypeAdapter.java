package buildup.gson;

import com.google.gson.TypeAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;

public class IntegerJsonTypeAdapter extends TypeAdapter<Integer> {
    public void write(JsonWriter out, Integer value) throws IOException {
        if (value == null) {
            out.nullValue();
        } else {
            out.value((Number) value);
        }
    }

    public Integer read(JsonReader in) throws IOException {
        Integer num = null;
        if (in.peek() == JsonToken.NULL) {
            in.nextNull();
        } else {
            try {
                num = Integer.valueOf(Integer.parseInt(in.nextString()));
            } catch (NumberFormatException e) {
            }
        }
        return num;
    }
}
