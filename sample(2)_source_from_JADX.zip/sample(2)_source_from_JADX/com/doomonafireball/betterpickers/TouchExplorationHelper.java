package com.doomonafireball.betterpickers;

import android.content.Context;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.support.v4.view.accessibility.AccessibilityRecordCompat;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import buildup.views.ImagePicker;
import com.doomonafireball.betterpickers.recurrencepicker.EventRecurrence;
import io.buildup.pkg20170504080645.C0585R;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public abstract class TouchExplorationHelper<T> extends AccessibilityNodeProviderCompat {
    public static final int INVALID_ID = Integer.MIN_VALUE;
    private T mCurrentItem;
    private final AccessibilityDelegateCompat mDelegate;
    private int mFocusedItemId;
    private final AccessibilityManager mManager;
    private View mParentView;
    private final int[] mTempGlobalRect;
    private final Rect mTempParentRect;
    private final Rect mTempScreenRect;
    private final Rect mTempVisibleRect;

    /* renamed from: com.doomonafireball.betterpickers.TouchExplorationHelper.1 */
    class C04051 extends AccessibilityDelegateCompat {
        C04051() {
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent event) {
            super.onInitializeAccessibilityEvent(view, event);
            event.setClassName(view.getClass().getName());
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat info) {
            super.onInitializeAccessibilityNodeInfo(view, info);
            info.setClassName(view.getClass().getName());
        }

        public AccessibilityNodeProviderCompat getAccessibilityNodeProvider(View host) {
            return TouchExplorationHelper.this;
        }
    }

    protected abstract int getIdForItem(T t);

    protected abstract T getItemAt(float f, float f2);

    protected abstract T getItemForId(int i);

    protected abstract void getVisibleItems(List<T> list);

    protected abstract boolean performActionForItem(T t, int i, Bundle bundle);

    protected abstract void populateEventForItem(T t, AccessibilityEvent accessibilityEvent);

    protected abstract void populateNodeForItem(T t, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat);

    public TouchExplorationHelper(Context context, View parentView) {
        this.mTempScreenRect = new Rect();
        this.mTempParentRect = new Rect();
        this.mTempVisibleRect = new Rect();
        this.mTempGlobalRect = new int[2];
        this.mFocusedItemId = INVALID_ID;
        this.mCurrentItem = null;
        this.mDelegate = new C04051();
        this.mManager = (AccessibilityManager) context.getSystemService("accessibility");
        this.mParentView = parentView;
    }

    public T getFocusedItem() {
        return getItemForId(this.mFocusedItemId);
    }

    public void clearFocusedItem() {
        int itemId = this.mFocusedItemId;
        if (itemId != INVALID_ID) {
            performAction(itemId, AccessibilityNodeInfoCompat.ACTION_CLEAR_ACCESSIBILITY_FOCUS, null);
        }
    }

    public void setFocusedItem(T item) {
        int itemId = getIdForItem(item);
        if (itemId != INVALID_ID) {
            performAction(itemId, 64, null);
        }
    }

    public void invalidateParent() {
        this.mParentView.sendAccessibilityEvent(ImagePicker.CAPTURE_REQUEST_CODE);
    }

    public void invalidateItem(T item) {
        sendEventForItem(item, ImagePicker.CAPTURE_REQUEST_CODE);
    }

    public boolean sendEventForItem(T item, int eventType) {
        if (!this.mManager.isEnabled()) {
            return false;
        }
        return ((ViewGroup) this.mParentView.getParent()).requestSendAccessibilityEvent(this.mParentView, getEventForItem(item, eventType));
    }

    public AccessibilityNodeInfoCompat createAccessibilityNodeInfo(int virtualViewId) {
        if (virtualViewId == -1) {
            return getNodeForParent();
        }
        T item = getItemForId(virtualViewId);
        if (item == null) {
            return null;
        }
        AccessibilityNodeInfoCompat node = AccessibilityNodeInfoCompat.obtain();
        populateNodeForItemInternal(item, node);
        return node;
    }

    public boolean performAction(int virtualViewId, int action, Bundle arguments) {
        if (virtualViewId == -1) {
            return ViewCompat.performAccessibilityAction(this.mParentView, action, arguments);
        }
        T item = getItemForId(virtualViewId);
        if (item == null) {
            return false;
        }
        boolean handled = false;
        switch (action) {
            case C0585R.styleable.Theme_imageButtonStyle /*64*/:
                if (this.mFocusedItemId != virtualViewId) {
                    this.mFocusedItemId = virtualViewId;
                    sendEventForItem(item, AccessibilityNodeInfoCompat.ACTION_PASTE);
                    handled = true;
                    break;
                }
                break;
            case AccessibilityNodeInfoCompat.ACTION_CLEAR_ACCESSIBILITY_FOCUS /*128*/:
                if (this.mFocusedItemId == virtualViewId) {
                    this.mFocusedItemId = INVALID_ID;
                    sendEventForItem(item, EventRecurrence.SU);
                    handled = true;
                    break;
                }
                break;
        }
        return handled | performActionForItem(item, action, arguments);
    }

    private void setCurrentItem(T item) {
        if (this.mCurrentItem != item) {
            if (this.mCurrentItem != null) {
                sendEventForItem(this.mCurrentItem, AccessibilityNodeInfoCompat.ACTION_NEXT_AT_MOVEMENT_GRANULARITY);
            }
            this.mCurrentItem = item;
            if (this.mCurrentItem != null) {
                sendEventForItem(this.mCurrentItem, AccessibilityNodeInfoCompat.ACTION_CLEAR_ACCESSIBILITY_FOCUS);
            }
        }
    }

    private AccessibilityEvent getEventForItem(T item, int eventType) {
        AccessibilityEvent event = AccessibilityEvent.obtain(eventType);
        AccessibilityRecordCompat record = new AccessibilityRecordCompat(event);
        int virtualDescendantId = getIdForItem(item);
        event.setEnabled(true);
        populateEventForItem(item, event);
        if (event.getText().isEmpty() && TextUtils.isEmpty(event.getContentDescription())) {
            throw new RuntimeException("You must add text or a content description in populateEventForItem()");
        }
        event.setClassName(item.getClass().getName());
        event.setPackageName(this.mParentView.getContext().getPackageName());
        record.setSource(this.mParentView, virtualDescendantId);
        return event;
    }

    private AccessibilityNodeInfoCompat getNodeForParent() {
        AccessibilityNodeInfoCompat info = AccessibilityNodeInfoCompat.obtain(this.mParentView);
        ViewCompat.onInitializeAccessibilityNodeInfo(this.mParentView, info);
        LinkedList<T> items = new LinkedList();
        getVisibleItems(items);
        Iterator it = items.iterator();
        while (it.hasNext()) {
            info.addChild(this.mParentView, getIdForItem(it.next()));
        }
        return info;
    }

    private AccessibilityNodeInfoCompat populateNodeForItemInternal(T item, AccessibilityNodeInfoCompat node) {
        int virtualDescendantId = getIdForItem(item);
        node.setEnabled(true);
        populateNodeForItem(item, node);
        if (TextUtils.isEmpty(node.getText()) && TextUtils.isEmpty(node.getContentDescription())) {
            throw new RuntimeException("You must add text or a content description in populateNodeForItem()");
        }
        node.setPackageName(this.mParentView.getContext().getPackageName());
        node.setClassName(item.getClass().getName());
        node.setParent(this.mParentView);
        node.setSource(this.mParentView, virtualDescendantId);
        if (this.mFocusedItemId == virtualDescendantId) {
            node.addAction((int) AccessibilityNodeInfoCompat.ACTION_CLEAR_ACCESSIBILITY_FOCUS);
        } else {
            node.addAction(64);
        }
        node.getBoundsInParent(this.mTempParentRect);
        if (this.mTempParentRect.isEmpty()) {
            throw new RuntimeException("You must set parent bounds in populateNodeForItem()");
        }
        if (intersectVisibleToUser(this.mTempParentRect)) {
            node.setVisibleToUser(true);
            node.setBoundsInParent(this.mTempParentRect);
        }
        this.mParentView.getLocationOnScreen(this.mTempGlobalRect);
        int offsetX = this.mTempGlobalRect[0];
        int offsetY = this.mTempGlobalRect[1];
        this.mTempScreenRect.set(this.mTempParentRect);
        this.mTempScreenRect.offset(offsetX, offsetY);
        node.setBoundsInScreen(this.mTempScreenRect);
        return node;
    }

    private boolean intersectVisibleToUser(Rect localRect) {
        if (localRect == null || localRect.isEmpty() || this.mParentView.getWindowVisibility() != 0) {
            return false;
        }
        ViewParent viewParent = this;
        while (viewParent instanceof View) {
            View view = (View) viewParent;
            if (view.getAlpha() <= 0.0f || view.getVisibility() != 0) {
                return false;
            }
            viewParent = view.getParent();
        }
        if (this.mParentView.getLocalVisibleRect(this.mTempVisibleRect)) {
            return localRect.intersect(this.mTempVisibleRect);
        }
        return false;
    }

    public AccessibilityDelegateCompat getAccessibilityDelegate() {
        return this.mDelegate;
    }
}
