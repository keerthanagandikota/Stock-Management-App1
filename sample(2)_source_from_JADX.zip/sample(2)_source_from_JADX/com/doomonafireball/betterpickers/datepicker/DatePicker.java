package com.doomonafireball.betterpickers.datepicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.widget.UnderlinePageIndicatorPicker;
import io.buildup.pkg20170504080645.BuildConfig;
import io.buildup.pkg20170504080645.C0585R;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

public class DatePicker extends LinearLayout implements OnClickListener, OnLongClickListener {
    private static final String KEYBOARD_DATE = "date";
    private static final String KEYBOARD_MONTH = "month";
    private static final String KEYBOARD_YEAR = "year";
    private static int sDateKeyboardPosition;
    private static int sMonthKeyboardPosition;
    private static int sYearKeyboardPosition;
    private int mButtonBackgroundResId;
    private int mCheckDrawableSrcResId;
    protected final Context mContext;
    private char[] mDateFormatOrder;
    protected int[] mDateInput;
    protected int mDateInputPointer;
    protected int mDateInputSize;
    protected Button mDateLeft;
    protected final Button[] mDateNumbers;
    protected ImageButton mDateRight;
    protected ImageButton mDelete;
    private int mDeleteDrawableSrcResId;
    protected View mDivider;
    protected DateView mEnteredDate;
    private int mKeyBackgroundResId;
    protected UnderlinePageIndicatorPicker mKeyboardIndicator;
    private int mKeyboardIndicatorColor;
    protected ViewPager mKeyboardPager;
    protected KeyboardPagerAdapter mKeyboardPagerAdapter;
    protected String[] mMonthAbbreviations;
    protected int mMonthInput;
    protected final Button[] mMonths;
    private Button mSetButton;
    private ColorStateList mTextColor;
    private int mTheme;
    private int mTitleDividerColor;
    protected int[] mYearInput;
    protected int mYearInputPointer;
    protected int mYearInputSize;
    protected Button mYearLeft;
    protected final Button[] mYearNumbers;
    protected Button mYearRight;

    private class KeyboardPagerAdapter extends PagerAdapter {
        private LayoutInflater mInflater;

        public KeyboardPagerAdapter(LayoutInflater inflater) {
            this.mInflater = inflater;
        }

        public Object instantiateItem(ViewGroup collection, int position) {
            View view;
            Resources res = DatePicker.this.mContext.getResources();
            View v1;
            View v2;
            View v3;
            View v4;
            int i;
            if (DatePicker.this.mDateFormatOrder[position] == 'M') {
                DatePicker.sMonthKeyboardPosition = position;
                view = this.mInflater.inflate(C0404R.layout.keyboard_text_with_header, null);
                v1 = view.findViewById(C0404R.id.first);
                v2 = view.findViewById(C0404R.id.second);
                v3 = view.findViewById(C0404R.id.third);
                v4 = view.findViewById(C0404R.id.fourth);
                ((TextView) view.findViewById(C0404R.id.header)).setText(C0404R.string.month_c);
                DatePicker.this.mMonths[0] = (Button) v1.findViewById(C0404R.id.key_left);
                DatePicker.this.mMonths[1] = (Button) v1.findViewById(C0404R.id.key_middle);
                DatePicker.this.mMonths[2] = (Button) v1.findViewById(C0404R.id.key_right);
                DatePicker.this.mMonths[3] = (Button) v2.findViewById(C0404R.id.key_left);
                DatePicker.this.mMonths[4] = (Button) v2.findViewById(C0404R.id.key_middle);
                DatePicker.this.mMonths[5] = (Button) v2.findViewById(C0404R.id.key_right);
                DatePicker.this.mMonths[6] = (Button) v3.findViewById(C0404R.id.key_left);
                DatePicker.this.mMonths[7] = (Button) v3.findViewById(C0404R.id.key_middle);
                DatePicker.this.mMonths[8] = (Button) v3.findViewById(C0404R.id.key_right);
                DatePicker.this.mMonths[9] = (Button) v4.findViewById(C0404R.id.key_left);
                DatePicker.this.mMonths[10] = (Button) v4.findViewById(C0404R.id.key_middle);
                DatePicker.this.mMonths[11] = (Button) v4.findViewById(C0404R.id.key_right);
                for (i = 0; i < 12; i++) {
                    DatePicker.this.mMonths[i].setOnClickListener(DatePicker.this);
                    DatePicker.this.mMonths[i].setText(DatePicker.this.mMonthAbbreviations[i]);
                    DatePicker.this.mMonths[i].setTextColor(DatePicker.this.mTextColor);
                    DatePicker.this.mMonths[i].setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                    DatePicker.this.mMonths[i].setTag(C0404R.id.date_keyboard, DatePicker.KEYBOARD_MONTH);
                    DatePicker.this.mMonths[i].setTag(C0404R.id.date_month_int, Integer.valueOf(i));
                }
            } else if (DatePicker.this.mDateFormatOrder[position] == 'd') {
                DatePicker.sDateKeyboardPosition = position;
                view = this.mInflater.inflate(C0404R.layout.keyboard_right_drawable_with_header, null);
                v1 = view.findViewById(C0404R.id.first);
                v2 = view.findViewById(C0404R.id.second);
                v3 = view.findViewById(C0404R.id.third);
                v4 = view.findViewById(C0404R.id.fourth);
                ((TextView) view.findViewById(C0404R.id.header)).setText(C0404R.string.day_c);
                DatePicker.this.mDateNumbers[1] = (Button) v1.findViewById(C0404R.id.key_left);
                DatePicker.this.mDateNumbers[2] = (Button) v1.findViewById(C0404R.id.key_middle);
                DatePicker.this.mDateNumbers[3] = (Button) v1.findViewById(C0404R.id.key_right);
                DatePicker.this.mDateNumbers[4] = (Button) v2.findViewById(C0404R.id.key_left);
                DatePicker.this.mDateNumbers[5] = (Button) v2.findViewById(C0404R.id.key_middle);
                DatePicker.this.mDateNumbers[6] = (Button) v2.findViewById(C0404R.id.key_right);
                DatePicker.this.mDateNumbers[7] = (Button) v3.findViewById(C0404R.id.key_left);
                DatePicker.this.mDateNumbers[8] = (Button) v3.findViewById(C0404R.id.key_middle);
                DatePicker.this.mDateNumbers[9] = (Button) v3.findViewById(C0404R.id.key_right);
                DatePicker.this.mDateLeft = (Button) v4.findViewById(C0404R.id.key_left);
                DatePicker.this.mDateLeft.setTextColor(DatePicker.this.mTextColor);
                DatePicker.this.mDateLeft.setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                DatePicker.this.mDateNumbers[0] = (Button) v4.findViewById(C0404R.id.key_middle);
                DatePicker.this.mDateRight = (ImageButton) v4.findViewById(C0404R.id.key_right);
                for (i = 0; i < 10; i++) {
                    DatePicker.this.mDateNumbers[i].setOnClickListener(DatePicker.this);
                    DatePicker.this.mDateNumbers[i].setText(String.format("%d", new Object[]{Integer.valueOf(i)}));
                    DatePicker.this.mDateNumbers[i].setTextColor(DatePicker.this.mTextColor);
                    DatePicker.this.mDateNumbers[i].setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                    DatePicker.this.mDateNumbers[i].setTag(C0404R.id.date_keyboard, DatePicker.KEYBOARD_DATE);
                    DatePicker.this.mDateNumbers[i].setTag(C0404R.id.numbers_key, Integer.valueOf(i));
                }
                DatePicker.this.mDateRight.setImageDrawable(res.getDrawable(DatePicker.this.mCheckDrawableSrcResId));
                DatePicker.this.mDateRight.setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                DatePicker.this.mDateRight.setOnClickListener(DatePicker.this);
            } else if (DatePicker.this.mDateFormatOrder[position] == 'y') {
                DatePicker.sYearKeyboardPosition = position;
                view = this.mInflater.inflate(C0404R.layout.keyboard_with_header, null);
                v1 = view.findViewById(C0404R.id.first);
                v2 = view.findViewById(C0404R.id.second);
                v3 = view.findViewById(C0404R.id.third);
                v4 = view.findViewById(C0404R.id.fourth);
                ((TextView) view.findViewById(C0404R.id.header)).setText(C0404R.string.year_c);
                DatePicker.this.mYearNumbers[1] = (Button) v1.findViewById(C0404R.id.key_left);
                DatePicker.this.mYearNumbers[2] = (Button) v1.findViewById(C0404R.id.key_middle);
                DatePicker.this.mYearNumbers[3] = (Button) v1.findViewById(C0404R.id.key_right);
                DatePicker.this.mYearNumbers[4] = (Button) v2.findViewById(C0404R.id.key_left);
                DatePicker.this.mYearNumbers[5] = (Button) v2.findViewById(C0404R.id.key_middle);
                DatePicker.this.mYearNumbers[6] = (Button) v2.findViewById(C0404R.id.key_right);
                DatePicker.this.mYearNumbers[7] = (Button) v3.findViewById(C0404R.id.key_left);
                DatePicker.this.mYearNumbers[8] = (Button) v3.findViewById(C0404R.id.key_middle);
                DatePicker.this.mYearNumbers[9] = (Button) v3.findViewById(C0404R.id.key_right);
                DatePicker.this.mYearLeft = (Button) v4.findViewById(C0404R.id.key_left);
                DatePicker.this.mYearLeft.setTextColor(DatePicker.this.mTextColor);
                DatePicker.this.mYearLeft.setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                DatePicker.this.mYearNumbers[0] = (Button) v4.findViewById(C0404R.id.key_middle);
                DatePicker.this.mYearRight = (Button) v4.findViewById(C0404R.id.key_right);
                DatePicker.this.mYearRight.setTextColor(DatePicker.this.mTextColor);
                DatePicker.this.mYearRight.setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                for (i = 0; i < 10; i++) {
                    DatePicker.this.mYearNumbers[i].setOnClickListener(DatePicker.this);
                    DatePicker.this.mYearNumbers[i].setText(String.format("%d", new Object[]{Integer.valueOf(i)}));
                    DatePicker.this.mYearNumbers[i].setTextColor(DatePicker.this.mTextColor);
                    DatePicker.this.mYearNumbers[i].setBackgroundResource(DatePicker.this.mKeyBackgroundResId);
                    DatePicker.this.mYearNumbers[i].setTag(C0404R.id.date_keyboard, DatePicker.KEYBOARD_YEAR);
                    DatePicker.this.mYearNumbers[i].setTag(C0404R.id.numbers_key, Integer.valueOf(i));
                }
            } else {
                view = new View(DatePicker.this.mContext);
            }
            DatePicker.this.setLeftRightEnabled();
            DatePicker.this.updateDate();
            DatePicker.this.updateKeypad();
            collection.addView(view, 0);
            return view;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        public int getCount() {
            return 3;
        }

        public boolean isViewFromObject(View view, Object o) {
            return view == o;
        }
    }

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR;
        int[] mDateInput;
        int mDateInputPointer;
        int mMonthInput;
        int[] mYearInput;
        int mYearInputPointer;

        /* renamed from: com.doomonafireball.betterpickers.datepicker.DatePicker.SavedState.1 */
        static class C04101 implements Creator<SavedState> {
            C04101() {
            }

            public SavedState createFromParcel(Parcel in) {
                return new SavedState(null);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.mDateInputPointer = in.readInt();
            this.mYearInputPointer = in.readInt();
            in.readIntArray(this.mDateInput);
            in.readIntArray(this.mYearInput);
            this.mMonthInput = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.mDateInputPointer);
            dest.writeInt(this.mYearInputPointer);
            dest.writeIntArray(this.mDateInput);
            dest.writeIntArray(this.mYearInput);
            dest.writeInt(this.mMonthInput);
        }

        static {
            CREATOR = new C04101();
        }
    }

    static {
        sMonthKeyboardPosition = -1;
        sDateKeyboardPosition = -1;
        sYearKeyboardPosition = -1;
    }

    public DatePicker(Context context) {
        this(context, null);
    }

    public DatePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mDateInputSize = 2;
        this.mYearInputSize = 4;
        this.mMonthInput = -1;
        this.mDateInput = new int[this.mDateInputSize];
        this.mYearInput = new int[this.mYearInputSize];
        this.mDateInputPointer = -1;
        this.mYearInputPointer = -1;
        this.mMonths = new Button[12];
        this.mDateNumbers = new Button[10];
        this.mYearNumbers = new Button[10];
        this.mTheme = -1;
        this.mContext = context;
        this.mDateFormatOrder = DateFormat.getDateFormatOrder(this.mContext);
        this.mMonthAbbreviations = makeLocalizedMonthAbbreviations();
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(getLayoutId(), this);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mKeyBackgroundResId = C0404R.drawable.key_background_dark;
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mTitleDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
        this.mKeyboardIndicatorColor = getResources().getColor(C0404R.color.default_keyboard_indicator_color_dark);
        this.mDeleteDrawableSrcResId = C0404R.drawable.ic_backspace_dark;
        this.mCheckDrawableSrcResId = C0404R.drawable.ic_check_dark;
    }

    protected int getLayoutId() {
        return C0404R.layout.date_picker_view;
    }

    public void setTheme(int themeResId) {
        this.mTheme = themeResId;
        if (this.mTheme != -1) {
            TypedArray a = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mKeyBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpKeyBackground, this.mKeyBackgroundResId);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mCheckDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpCheckIcon, this.mCheckDrawableSrcResId);
            this.mTitleDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpTitleDividerColor, this.mTitleDividerColor);
            this.mKeyboardIndicatorColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpKeyboardIndicatorColor, this.mKeyboardIndicatorColor);
            this.mDeleteDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDeleteIcon, this.mDeleteDrawableSrcResId);
        }
        restyleViews();
    }

    private void restyleViews() {
        int i = 0;
        for (Button month : this.mMonths) {
            if (month != null) {
                month.setTextColor(this.mTextColor);
                month.setBackgroundResource(this.mKeyBackgroundResId);
            }
        }
        for (Button dateNumber : this.mDateNumbers) {
            if (dateNumber != null) {
                dateNumber.setTextColor(this.mTextColor);
                dateNumber.setBackgroundResource(this.mKeyBackgroundResId);
            }
        }
        Button[] buttonArr = this.mYearNumbers;
        int length = buttonArr.length;
        while (i < length) {
            Button yearNumber = buttonArr[i];
            if (yearNumber != null) {
                yearNumber.setTextColor(this.mTextColor);
                yearNumber.setBackgroundResource(this.mKeyBackgroundResId);
            }
            i++;
        }
        if (this.mKeyboardIndicator != null) {
            this.mKeyboardIndicator.setSelectedColor(this.mKeyboardIndicatorColor);
        }
        if (this.mDivider != null) {
            this.mDivider.setBackgroundColor(this.mTitleDividerColor);
        }
        if (this.mDateLeft != null) {
            this.mDateLeft.setTextColor(this.mTextColor);
            this.mDateLeft.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mDateRight != null) {
            this.mDateRight.setBackgroundResource(this.mKeyBackgroundResId);
            this.mDateRight.setImageDrawable(getResources().getDrawable(this.mCheckDrawableSrcResId));
        }
        if (this.mDelete != null) {
            this.mDelete.setBackgroundResource(this.mButtonBackgroundResId);
            this.mDelete.setImageDrawable(getResources().getDrawable(this.mDeleteDrawableSrcResId));
        }
        if (this.mYearLeft != null) {
            this.mYearLeft.setTextColor(this.mTextColor);
            this.mYearLeft.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mYearRight != null) {
            this.mYearRight.setTextColor(this.mTextColor);
            this.mYearRight.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mEnteredDate != null) {
            this.mEnteredDate.setTheme(this.mTheme);
        }
    }

    protected void onFinishInflate() {
        int i;
        super.onFinishInflate();
        this.mDivider = findViewById(C0404R.id.divider);
        for (i = 0; i < this.mDateInput.length; i++) {
            this.mDateInput[i] = 0;
        }
        for (i = 0; i < this.mYearInput.length; i++) {
            this.mYearInput[i] = 0;
        }
        this.mKeyboardIndicator = (UnderlinePageIndicatorPicker) findViewById(C0404R.id.keyboard_indicator);
        this.mKeyboardPager = (ViewPager) findViewById(C0404R.id.keyboard_pager);
        this.mKeyboardPager.setOffscreenPageLimit(2);
        this.mKeyboardPagerAdapter = new KeyboardPagerAdapter((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        this.mKeyboardPager.setAdapter(this.mKeyboardPagerAdapter);
        this.mKeyboardIndicator.setViewPager(this.mKeyboardPager);
        this.mKeyboardPager.setCurrentItem(0);
        this.mEnteredDate = (DateView) findViewById(C0404R.id.date_text);
        this.mEnteredDate.setTheme(this.mTheme);
        this.mEnteredDate.setUnderlinePage(this.mKeyboardIndicator);
        this.mEnteredDate.setOnClick(this);
        this.mDelete = (ImageButton) findViewById(C0404R.id.delete);
        this.mDelete.setOnClickListener(this);
        this.mDelete.setOnLongClickListener(this);
        setLeftRightEnabled();
        updateDate();
        updateKeypad();
    }

    public void updateDeleteButton() {
        boolean enabled = (this.mMonthInput == -1 && this.mDateInputPointer == -1 && this.mYearInputPointer == -1) ? false : true;
        if (this.mDelete != null) {
            this.mDelete.setEnabled(enabled);
        }
    }

    public void onClick(View v) {
        v.performHapticFeedback(1);
        doOnClick(v);
        updateDeleteButton();
    }

    protected void doOnClick(View v) {
        if (v == this.mDelete) {
            int i;
            switch (this.mDateFormatOrder[this.mKeyboardPager.getCurrentItem()]) {
                case C0585R.styleable.Theme_textAppearanceListItemSmall /*77*/:
                    if (this.mMonthInput != -1) {
                        this.mMonthInput = -1;
                        break;
                    }
                    break;
                case C0585R.styleable.Theme_buttonStyle /*100*/:
                    if (this.mDateInputPointer < 0) {
                        if (this.mKeyboardPager.getCurrentItem() > 0) {
                            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() - 1, true);
                            break;
                        }
                    }
                    for (i = 0; i < this.mDateInputPointer; i++) {
                        this.mDateInput[i] = this.mDateInput[i + 1];
                    }
                    this.mDateInput[this.mDateInputPointer] = 0;
                    this.mDateInputPointer--;
                    break;
                    break;
                case 'y':
                    if (this.mYearInputPointer < 0) {
                        if (this.mKeyboardPager.getCurrentItem() > 0) {
                            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() - 1, true);
                            break;
                        }
                    }
                    for (i = 0; i < this.mYearInputPointer; i++) {
                        this.mYearInput[i] = this.mYearInput[i + 1];
                    }
                    this.mYearInput[this.mYearInputPointer] = 0;
                    this.mYearInputPointer--;
                    break;
                    break;
            }
        } else if (v == this.mDateRight) {
            onDateRightClicked();
        } else if (v == this.mEnteredDate.getDate()) {
            this.mKeyboardPager.setCurrentItem(sDateKeyboardPosition);
        } else if (v == this.mEnteredDate.getMonth()) {
            this.mKeyboardPager.setCurrentItem(sMonthKeyboardPosition);
        } else if (v == this.mEnteredDate.getYear()) {
            this.mKeyboardPager.setCurrentItem(sYearKeyboardPosition);
        } else if (v.getTag(C0404R.id.date_keyboard).equals(KEYBOARD_MONTH)) {
            this.mMonthInput = ((Integer) v.getTag(C0404R.id.date_month_int)).intValue();
            if (this.mKeyboardPager.getCurrentItem() < 2) {
                this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() + 1, true);
            }
        } else if (v.getTag(C0404R.id.date_keyboard).equals(KEYBOARD_DATE)) {
            addClickedDateNumber(((Integer) v.getTag(C0404R.id.numbers_key)).intValue());
        } else if (v.getTag(C0404R.id.date_keyboard).equals(KEYBOARD_YEAR)) {
            addClickedYearNumber(((Integer) v.getTag(C0404R.id.numbers_key)).intValue());
        }
        updateKeypad();
    }

    public boolean onLongClick(View v) {
        v.performHapticFeedback(0);
        if (v != this.mDelete) {
            return false;
        }
        this.mDelete.setPressed(false);
        reset();
        updateKeypad();
        return true;
    }

    private void updateKeypad() {
        updateLeftRightButtons();
        updateDate();
        enableSetButton();
        updateDeleteButton();
        updateMonthKeys();
        updateDateKeys();
        updateYearKeys();
    }

    public void reset() {
        int i;
        for (i = 0; i < this.mDateInputSize; i++) {
            this.mDateInput[i] = 0;
        }
        for (i = 0; i < this.mYearInputSize; i++) {
            this.mYearInput[i] = 0;
        }
        this.mDateInputPointer = -1;
        this.mYearInputPointer = -1;
        this.mMonthInput = -1;
        this.mKeyboardPager.setCurrentItem(0, true);
        updateDate();
    }

    protected void updateDate() {
        String month;
        if (this.mMonthInput < 0) {
            month = BuildConfig.FLAVOR;
        } else {
            month = this.mMonthAbbreviations[this.mMonthInput];
        }
        this.mEnteredDate.setDate(month, getDayOfMonth(), getYear());
    }

    protected void setLeftRightEnabled() {
        if (this.mDateLeft != null) {
            this.mDateLeft.setEnabled(false);
        }
        if (this.mDateRight != null) {
            this.mDateRight.setEnabled(canGoToYear());
        }
        if (this.mYearLeft != null) {
            this.mYearLeft.setEnabled(false);
        }
        if (this.mYearRight != null) {
            this.mYearRight.setEnabled(false);
        }
    }

    private void addClickedDateNumber(int val) {
        if (this.mDateInputPointer < this.mDateInputSize - 1) {
            for (int i = this.mDateInputPointer; i >= 0; i--) {
                this.mDateInput[i + 1] = this.mDateInput[i];
            }
            this.mDateInputPointer++;
            this.mDateInput[0] = val;
        }
        if ((getDayOfMonth() >= 4 || (getMonthOfYear() == 1 && getDayOfMonth() >= 3)) && this.mKeyboardPager.getCurrentItem() < 2) {
            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() + 1, true);
        }
    }

    private void addClickedYearNumber(int val) {
        if (this.mYearInputPointer < this.mYearInputSize - 1) {
            for (int i = this.mYearInputPointer; i >= 0; i--) {
                this.mYearInput[i + 1] = this.mYearInput[i];
            }
            this.mYearInputPointer++;
            this.mYearInput[0] = val;
        }
        if (getYear() >= 1000 && this.mKeyboardPager.getCurrentItem() < 2) {
            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() + 1, true);
        }
    }

    private void onDateRightClicked() {
        if (this.mKeyboardPager.getCurrentItem() < 2) {
            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() + 1, true);
        }
    }

    private void updateMonthKeys() {
        int date = getDayOfMonth();
        for (int i = 0; i < this.mMonths.length; i++) {
            if (this.mMonths[i] != null) {
                this.mMonths[i].setEnabled(true);
            }
        }
        if (date > 29 && this.mMonths[1] != null) {
            this.mMonths[1].setEnabled(false);
        }
        if (date > 30) {
            if (this.mMonths[3] != null) {
                this.mMonths[3].setEnabled(false);
            }
            if (this.mMonths[5] != null) {
                this.mMonths[5].setEnabled(false);
            }
            if (this.mMonths[8] != null) {
                this.mMonths[8].setEnabled(false);
            }
            if (this.mMonths[10] != null) {
                this.mMonths[10].setEnabled(false);
            }
        }
    }

    private void updateDateKeys() {
        int date = getDayOfMonth();
        if (date >= 4) {
            setDateKeyRange(-1);
        } else if (date >= 3) {
            if (this.mMonthInput == 1) {
                setDateKeyRange(-1);
            } else if (this.mMonthInput == 3 || this.mMonthInput == 5 || this.mMonthInput == 8 || this.mMonthInput == 10) {
                setDateKeyRange(0);
            } else {
                setDateKeyRange(1);
            }
        } else if (date >= 2) {
            setDateKeyRange(9);
        } else if (date >= 1) {
            setDateKeyRange(9);
        } else {
            setDateMinKeyRange(1);
        }
    }

    private void updateYearKeys() {
        int year = getYear();
        if (year >= 1000) {
            setYearKeyRange(-1);
        } else if (year >= 1) {
            setYearKeyRange(9);
        } else {
            setYearMinKeyRange(1);
        }
    }

    private void setDateKeyRange(int maxKey) {
        int i = 0;
        while (i < this.mDateNumbers.length) {
            if (this.mDateNumbers[i] != null) {
                this.mDateNumbers[i].setEnabled(i <= maxKey);
            }
            i++;
        }
    }

    private void setDateMinKeyRange(int minKey) {
        int i = 0;
        while (i < this.mDateNumbers.length) {
            if (this.mDateNumbers[i] != null) {
                this.mDateNumbers[i].setEnabled(i >= minKey);
            }
            i++;
        }
    }

    private void setYearKeyRange(int maxKey) {
        int i = 0;
        while (i < this.mYearNumbers.length) {
            if (this.mYearNumbers[i] != null) {
                this.mYearNumbers[i].setEnabled(i <= maxKey);
            }
            i++;
        }
    }

    private void setYearMinKeyRange(int minKey) {
        int i = 0;
        while (i < this.mYearNumbers.length) {
            if (this.mYearNumbers[i] != null) {
                this.mYearNumbers[i].setEnabled(i >= minKey);
            }
            i++;
        }
    }

    private boolean canGoToYear() {
        return getDayOfMonth() > 0;
    }

    private void updateLeftRightButtons() {
        if (this.mDateRight != null) {
            this.mDateRight.setEnabled(canGoToYear());
        }
    }

    private void enableSetButton() {
        if (this.mSetButton != null) {
            Button button = this.mSetButton;
            boolean z = getDayOfMonth() > 0 && getYear() > 0 && getMonthOfYear() >= 0;
            button.setEnabled(z);
        }
    }

    public void setSetButton(Button b) {
        this.mSetButton = b;
        enableSetButton();
    }

    public int getYear() {
        return (((this.mYearInput[3] * 1000) + (this.mYearInput[2] * 100)) + (this.mYearInput[1] * 10)) + this.mYearInput[0];
    }

    public int getMonthOfYear() {
        return this.mMonthInput;
    }

    public int getDayOfMonth() {
        return (this.mDateInput[1] * 10) + this.mDateInput[0];
    }

    public void setDate(int year, int monthOfYear, int dayOfMonth) {
        this.mMonthInput = monthOfYear;
        this.mYearInput[3] = year / 1000;
        this.mYearInput[2] = (year % 1000) / 100;
        this.mYearInput[1] = (year % 100) / 10;
        this.mYearInput[0] = year % 10;
        if (year >= 1000) {
            this.mYearInputPointer = 3;
        } else if (year >= 100) {
            this.mYearInputPointer = 2;
        } else if (year >= 10) {
            this.mYearInputPointer = 1;
        } else if (year > 0) {
            this.mYearInputPointer = 0;
        }
        this.mDateInput[1] = dayOfMonth / 10;
        this.mDateInput[0] = dayOfMonth % 10;
        if (dayOfMonth >= 10) {
            this.mDateInputPointer = 1;
        } else if (dayOfMonth > 0) {
            this.mDateInputPointer = 0;
        }
        int i = 0;
        while (i < this.mDateFormatOrder.length) {
            char c = this.mDateFormatOrder[i];
            if (c != 'M' || monthOfYear != -1) {
                if (c != 'd' || dayOfMonth > 0) {
                    if (c == 'y' && year <= 0) {
                        this.mKeyboardPager.setCurrentItem(i, true);
                        break;
                    }
                    i++;
                } else {
                    this.mKeyboardPager.setCurrentItem(i, true);
                    break;
                }
            }
            this.mKeyboardPager.setCurrentItem(i, true);
            break;
        }
        updateKeypad();
    }

    public static String[] makeLocalizedMonthAbbreviations() {
        return makeLocalizedMonthAbbreviations(Locale.getDefault());
    }

    public static String[] makeLocalizedMonthAbbreviations(Locale locale) {
        boolean hasLocale;
        Calendar date;
        if (locale != null) {
            hasLocale = true;
        } else {
            hasLocale = false;
        }
        SimpleDateFormat monthAbbreviationFormat = hasLocale ? new SimpleDateFormat("MMM", locale) : new SimpleDateFormat("MMM");
        if (hasLocale) {
            date = new GregorianCalendar(locale);
        } else {
            date = new GregorianCalendar();
        }
        date.set(1, 0);
        date.set(5, 1);
        date.set(11, 0);
        date.set(12, 0);
        date.set(13, 0);
        date.set(14, 0);
        String[] months = new String[12];
        for (int i = 0; i < months.length; i++) {
            date.set(2, i);
            months[i] = monthAbbreviationFormat.format(date.getTime()).toUpperCase();
        }
        return months;
    }

    public Parcelable onSaveInstanceState() {
        SavedState state = new SavedState(super.onSaveInstanceState());
        state.mMonthInput = this.mMonthInput;
        state.mDateInput = this.mDateInput;
        state.mDateInputPointer = this.mDateInputPointer;
        state.mYearInput = this.mYearInput;
        state.mYearInputPointer = this.mYearInputPointer;
        return state;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState savedState = (SavedState) state;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mDateInputPointer = savedState.mDateInputPointer;
            this.mYearInputPointer = savedState.mYearInputPointer;
            this.mDateInput = savedState.mDateInput;
            this.mYearInput = savedState.mYearInput;
            if (this.mDateInput == null) {
                this.mDateInput = new int[this.mDateInputSize];
                this.mDateInputPointer = -1;
            }
            if (this.mYearInput == null) {
                this.mYearInput = new int[this.mYearInputSize];
                this.mYearInputPointer = -1;
            }
            this.mMonthInput = savedState.mMonthInput;
            updateKeypad();
            return;
        }
        super.onRestoreInstanceState(state);
    }
}
