package com.doomonafireball.betterpickers.datepicker;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import com.doomonafireball.betterpickers.datepicker.DatePickerDialogFragment.DatePickerDialogHandler;
import java.util.Vector;

public class DatePickerBuilder {
    private Integer dayOfMonth;
    private Vector<DatePickerDialogHandler> mDatePickerDialogHandlers;
    private int mReference;
    private FragmentManager manager;
    private Integer monthOfYear;
    private Integer styleResId;
    private Fragment targetFragment;
    private Integer year;

    public DatePickerBuilder() {
        this.mReference = -1;
        this.mDatePickerDialogHandlers = new Vector();
    }

    public DatePickerBuilder setFragmentManager(FragmentManager manager) {
        this.manager = manager;
        return this;
    }

    public DatePickerBuilder setStyleResId(int styleResId) {
        this.styleResId = Integer.valueOf(styleResId);
        return this;
    }

    public DatePickerBuilder setTargetFragment(Fragment targetFragment) {
        this.targetFragment = targetFragment;
        return this;
    }

    public DatePickerBuilder setReference(int reference) {
        this.mReference = reference;
        return this;
    }

    public DatePickerBuilder setMonthOfYear(int monthOfYear) {
        this.monthOfYear = Integer.valueOf(monthOfYear);
        return this;
    }

    public DatePickerBuilder setDayOfMonth(int dayOfMonth) {
        this.dayOfMonth = Integer.valueOf(dayOfMonth);
        return this;
    }

    public DatePickerBuilder setYear(int year) {
        this.year = Integer.valueOf(year);
        return this;
    }

    public DatePickerBuilder addDatePickerDialogHandler(DatePickerDialogHandler handler) {
        this.mDatePickerDialogHandlers.add(handler);
        return this;
    }

    public DatePickerBuilder removeDatePickerDialogHandler(DatePickerDialogHandler handler) {
        this.mDatePickerDialogHandlers.remove(handler);
        return this;
    }

    public void show() {
        if (this.manager == null || this.styleResId == null) {
            Log.e("DatePickerBuilder", "setFragmentManager() and setStyleResId() must be called.");
            return;
        }
        FragmentTransaction ft = this.manager.beginTransaction();
        Fragment prev = this.manager.findFragmentByTag("date_dialog");
        if (prev != null) {
            ft.remove(prev);
        }
        ft.addToBackStack(null);
        DatePickerDialogFragment fragment = DatePickerDialogFragment.newInstance(this.mReference, this.styleResId.intValue(), this.monthOfYear, this.dayOfMonth, this.year);
        if (this.targetFragment != null) {
            fragment.setTargetFragment(this.targetFragment, 0);
        }
        fragment.setDatePickerDialogHandlers(this.mDatePickerDialogHandlers);
        fragment.show(ft, "date_dialog");
    }
}
