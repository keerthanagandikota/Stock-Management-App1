package com.doomonafireball.betterpickers.widget;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.util.AttributeSet;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;
import io.buildup.pkg20170504080645.BuildConfig;

public class ZeroTopPaddingTextView extends TextView {
    private static final float BOLD_FONT_BOTTOM_PADDING_RATIO = 0.208f;
    private static final float BOLD_FONT_PADDING_RATIO = 0.208f;
    private static final float NORMAL_FONT_BOTTOM_PADDING_RATIO = 0.25f;
    private static final float NORMAL_FONT_PADDING_RATIO = 0.328f;
    private static final float PRE_ICS_BOTTOM_PADDING_RATIO = 0.233f;
    private static final Typeface SAN_SERIF_BOLD;
    private static final Typeface SAN_SERIF_CONDENSED_BOLD;
    private String decimalSeperator;
    private int mPaddingRight;
    private String timeSeperator;

    static {
        SAN_SERIF_BOLD = Typeface.create("san-serif", 1);
        SAN_SERIF_CONDENSED_BOLD = Typeface.create("sans-serif-condensed", 1);
    }

    public ZeroTopPaddingTextView(Context context) {
        this(context, null);
    }

    public ZeroTopPaddingTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ZeroTopPaddingTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.mPaddingRight = 0;
        this.decimalSeperator = BuildConfig.FLAVOR;
        this.timeSeperator = BuildConfig.FLAVOR;
        init();
        setIncludeFontPadding(false);
        updatePadding();
    }

    private void init() {
        this.decimalSeperator = getResources().getString(C0404R.string.number_picker_seperator);
        this.timeSeperator = getResources().getString(C0404R.string.time_picker_time_seperator);
    }

    public void updatePadding() {
        float paddingRatio = NORMAL_FONT_PADDING_RATIO;
        float bottomPaddingRatio = NORMAL_FONT_BOTTOM_PADDING_RATIO;
        if (getPaint().getTypeface() != null && getPaint().getTypeface().equals(Typeface.DEFAULT_BOLD)) {
            paddingRatio = BOLD_FONT_PADDING_RATIO;
            bottomPaddingRatio = BOLD_FONT_PADDING_RATIO;
        }
        if (getTypeface() != null && getTypeface().equals(SAN_SERIF_BOLD)) {
            paddingRatio = BOLD_FONT_PADDING_RATIO;
            bottomPaddingRatio = BOLD_FONT_PADDING_RATIO;
        }
        if (getTypeface() != null && getTypeface().equals(SAN_SERIF_CONDENSED_BOLD)) {
            paddingRatio = BOLD_FONT_PADDING_RATIO;
            bottomPaddingRatio = BOLD_FONT_PADDING_RATIO;
        }
        if (VERSION.SDK_INT < 14 && getText() != null && (getText().toString().equals(this.decimalSeperator) || getText().toString().equals(this.timeSeperator))) {
            bottomPaddingRatio = PRE_ICS_BOTTOM_PADDING_RATIO;
        }
        setPadding(0, (int) ((-paddingRatio) * getTextSize()), this.mPaddingRight, (int) ((-bottomPaddingRatio) * getTextSize()));
    }

    public void updatePaddingForBoldDate() {
        setPadding(0, (int) ((-BOLD_FONT_PADDING_RATIO) * getTextSize()), this.mPaddingRight, (int) ((-BOLD_FONT_PADDING_RATIO) * getTextSize()));
    }

    public void setPaddingRight(int padding) {
        this.mPaddingRight = padding;
        updatePadding();
    }
}
