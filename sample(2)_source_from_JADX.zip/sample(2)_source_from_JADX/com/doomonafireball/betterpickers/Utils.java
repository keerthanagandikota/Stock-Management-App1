package com.doomonafireball.betterpickers;

import android.annotation.SuppressLint;
import android.os.Build.VERSION;
import android.view.View;
import com.nineoldandroids.animation.Keyframe;
import com.nineoldandroids.animation.ObjectAnimator;
import com.nineoldandroids.animation.PropertyValuesHolder;
import com.nineoldandroids.view.animation.AnimatorProxy;
import io.buildup.pkg20170504080645.C0585R;
import org.jraf.android.backport.switchwidget.C0678R;

public class Utils {
    public static final int FULL_ALPHA = 255;
    public static final int MONDAY_BEFORE_JULIAN_EPOCH = 2440585;
    public static final int PULSE_ANIMATOR_DURATION = 544;
    static final String SHARED_PREFS_NAME = "com.android.calendar_preferences";

    public static boolean isJellybeanOrLater() {
        return VERSION.SDK_INT >= 16;
    }

    @SuppressLint({"NewApi"})
    public static void tryAccessibilityAnnounce(View view, CharSequence text) {
        if (isJellybeanOrLater() && view != null && text != null) {
            view.announceForAccessibility(text);
        }
    }

    public static int getDaysInMonth(int month, int year) {
        switch (month) {
            case C0678R.styleable.Switch_asb_thumb /*0*/:
            case C0678R.styleable.Switch_asb_textOn /*2*/:
            case C0678R.styleable.Switch_asb_thumbTextPadding /*4*/:
            case C0678R.styleable.Switch_asb_switchMinWidth /*6*/:
            case C0678R.styleable.Switch_asb_switchPadding /*7*/:
            case C0585R.styleable.Toolbar_popupTheme /*9*/:
            case C0585R.styleable.Toolbar_subtitleTextAppearance /*11*/:
                return 31;
            case C0678R.styleable.Switch_asb_track /*1*/:
                return year % 4 == 0 ? 29 : 28;
            case C0678R.styleable.Switch_asb_textOff /*3*/:
            case C0678R.styleable.Switch_asb_switchTextAppearance /*5*/:
            case C0585R.styleable.Toolbar_contentInsetRight /*8*/:
            case C0585R.styleable.Toolbar_titleTextAppearance /*10*/:
                return 30;
            default:
                throw new IllegalArgumentException("Invalid Month");
        }
    }

    public static int getJulianMondayFromWeeksSinceEpoch(int week) {
        return MONDAY_BEFORE_JULIAN_EPOCH + (week * 7);
    }

    public static int getWeeksSinceEpochFromJulianDay(int julianDay, int firstDayOfWeek) {
        int diff = 4 - firstDayOfWeek;
        if (diff < 0) {
            diff += 7;
        }
        return (julianDay - (2440588 - diff)) / 7;
    }

    public static ObjectAnimator getPulseAnimator(View labelToAnimate, float decreaseRatio, float increaseRatio) {
        Object labelToAnimate2;
        Keyframe k0 = Keyframe.ofFloat(0.0f, 1.0f);
        Keyframe k1 = Keyframe.ofFloat(0.275f, decreaseRatio);
        Keyframe k2 = Keyframe.ofFloat(0.69f, increaseRatio);
        Keyframe k3 = Keyframe.ofFloat(1.0f, 1.0f);
        PropertyValuesHolder scaleX = PropertyValuesHolder.ofKeyframe("scaleX", k0, k1, k2, k3);
        PropertyValuesHolder scaleY = PropertyValuesHolder.ofKeyframe("scaleY", k0, k1, k2, k3);
        if (AnimatorProxy.NEEDS_PROXY) {
            labelToAnimate2 = AnimatorProxy.wrap(labelToAnimate);
        }
        ObjectAnimator pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(labelToAnimate2, scaleX, scaleY);
        pulseAnimator.setDuration(544);
        return pulseAnimator;
    }
}
