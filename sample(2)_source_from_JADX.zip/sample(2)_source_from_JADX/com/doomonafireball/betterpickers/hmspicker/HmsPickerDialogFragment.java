package com.doomonafireball.betterpickers.hmspicker;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import com.doomonafireball.betterpickers.C0404R;
import java.util.Iterator;
import java.util.Vector;

public class HmsPickerDialogFragment extends DialogFragment {
    private static final String REFERENCE_KEY = "HmsPickerDialogFragment_ReferenceKey";
    private static final String THEME_RES_ID_KEY = "HmsPickerDialogFragment_ThemeResIdKey";
    private int mButtonBackgroundResId;
    private Button mCancel;
    private int mDialogBackgroundResId;
    private int mDividerColor;
    private View mDividerOne;
    private View mDividerTwo;
    private Vector<HmsPickerDialogHandler> mHmsPickerDialogHandlers;
    private int mHours;
    private int mMinutes;
    private HmsPicker mPicker;
    private int mReference;
    private int mSeconds;
    private Button mSet;
    private ColorStateList mTextColor;
    private int mTheme;

    /* renamed from: com.doomonafireball.betterpickers.hmspicker.HmsPickerDialogFragment.1 */
    class C04191 implements OnClickListener {
        C04191() {
        }

        public void onClick(View view) {
            HmsPickerDialogFragment.this.dismiss();
        }
    }

    /* renamed from: com.doomonafireball.betterpickers.hmspicker.HmsPickerDialogFragment.2 */
    class C04202 implements OnClickListener {
        C04202() {
        }

        public void onClick(View view) {
            Iterator it = HmsPickerDialogFragment.this.mHmsPickerDialogHandlers.iterator();
            while (it.hasNext()) {
                ((HmsPickerDialogHandler) it.next()).onDialogHmsSet(HmsPickerDialogFragment.this.mReference, HmsPickerDialogFragment.this.mPicker.getHours(), HmsPickerDialogFragment.this.mPicker.getMinutes(), HmsPickerDialogFragment.this.mPicker.getSeconds());
            }
            Activity activity = HmsPickerDialogFragment.this.getActivity();
            Fragment fragment = HmsPickerDialogFragment.this.getTargetFragment();
            if (activity instanceof HmsPickerDialogHandler) {
                ((HmsPickerDialogHandler) activity).onDialogHmsSet(HmsPickerDialogFragment.this.mReference, HmsPickerDialogFragment.this.mPicker.getHours(), HmsPickerDialogFragment.this.mPicker.getMinutes(), HmsPickerDialogFragment.this.mPicker.getSeconds());
            } else if (fragment instanceof HmsPickerDialogHandler) {
                ((HmsPickerDialogHandler) fragment).onDialogHmsSet(HmsPickerDialogFragment.this.mReference, HmsPickerDialogFragment.this.mPicker.getHours(), HmsPickerDialogFragment.this.mPicker.getMinutes(), HmsPickerDialogFragment.this.mPicker.getSeconds());
            }
            HmsPickerDialogFragment.this.dismiss();
        }
    }

    public interface HmsPickerDialogHandler {
        void onDialogHmsSet(int i, int i2, int i3, int i4);
    }

    public HmsPickerDialogFragment() {
        this.mReference = -1;
        this.mTheme = -1;
        this.mHmsPickerDialogHandlers = new Vector();
    }

    public static HmsPickerDialogFragment newInstance(int reference, int themeResId) {
        HmsPickerDialogFragment frag = new HmsPickerDialogFragment();
        Bundle args = new Bundle();
        args.putInt(REFERENCE_KEY, reference);
        args.putInt(THEME_RES_ID_KEY, themeResId);
        frag.setArguments(args);
        return frag;
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null && args.containsKey(REFERENCE_KEY)) {
            this.mReference = args.getInt(REFERENCE_KEY);
        }
        if (args != null && args.containsKey(THEME_RES_ID_KEY)) {
            this.mTheme = args.getInt(THEME_RES_ID_KEY);
        }
        setStyle(1, 0);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
        this.mDialogBackgroundResId = C0404R.drawable.dialog_full_holo_dark;
        if (this.mTheme != -1) {
            TypedArray a = getActivity().getApplicationContext().obtainStyledAttributes(this.mTheme, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpDividerColor, this.mDividerColor);
            this.mDialogBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDialogBackground, this.mDialogBackgroundResId);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0404R.layout.hms_picker_dialog, null);
        this.mSet = (Button) v.findViewById(C0404R.id.set_button);
        this.mCancel = (Button) v.findViewById(C0404R.id.cancel_button);
        this.mCancel.setOnClickListener(new C04191());
        this.mPicker = (HmsPicker) v.findViewById(C0404R.id.hms_picker);
        this.mPicker.setSetButton(this.mSet);
        this.mPicker.setTime(this.mHours, this.mMinutes, this.mSeconds);
        this.mSet.setOnClickListener(new C04202());
        this.mDividerOne = v.findViewById(C0404R.id.divider_1);
        this.mDividerTwo = v.findViewById(C0404R.id.divider_2);
        this.mDividerOne.setBackgroundColor(this.mDividerColor);
        this.mDividerTwo.setBackgroundColor(this.mDividerColor);
        this.mSet.setTextColor(this.mTextColor);
        this.mSet.setBackgroundResource(this.mButtonBackgroundResId);
        this.mCancel.setTextColor(this.mTextColor);
        this.mCancel.setBackgroundResource(this.mButtonBackgroundResId);
        this.mPicker.setTheme(this.mTheme);
        getDialog().getWindow().setBackgroundDrawableResource(this.mDialogBackgroundResId);
        return v;
    }

    public void setHmsPickerDialogHandlers(Vector<HmsPickerDialogHandler> handlers) {
        this.mHmsPickerDialogHandlers = handlers;
    }

    public void setTime(int hours, int minutes, int seconds) {
        this.mHours = hours;
        this.mMinutes = minutes;
        this.mSeconds = seconds;
        if (this.mPicker != null) {
            this.mPicker.setTime(hours, minutes, seconds);
        }
    }
}
