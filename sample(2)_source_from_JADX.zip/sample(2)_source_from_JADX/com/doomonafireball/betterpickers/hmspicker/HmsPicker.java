package com.doomonafireball.betterpickers.hmspicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;

public class HmsPicker extends LinearLayout implements OnClickListener, OnLongClickListener {
    private int mButtonBackgroundResId;
    protected final Context mContext;
    protected ImageButton mDelete;
    private int mDeleteDrawableSrcResId;
    protected View mDivider;
    private int mDividerColor;
    protected HmsView mEnteredHms;
    private TextView mHoursLabel;
    protected int[] mInput;
    protected int mInputPointer;
    protected int mInputSize;
    private int mKeyBackgroundResId;
    protected Button mLeft;
    private TextView mMinutesLabel;
    protected final Button[] mNumbers;
    protected Button mRight;
    private TextView mSecondsLabel;
    private Button mSetButton;
    private ColorStateList mTextColor;
    private int mTheme;

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR;
        int mAmPmState;
        int[] mInput;
        int mInputPointer;

        /* renamed from: com.doomonafireball.betterpickers.hmspicker.HmsPicker.SavedState.1 */
        static class C04181 implements Creator<SavedState> {
            C04181() {
            }

            public SavedState createFromParcel(Parcel in) {
                return new SavedState(null);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.mInputPointer = in.readInt();
            in.readIntArray(this.mInput);
            this.mAmPmState = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.mInputPointer);
            dest.writeIntArray(this.mInput);
            dest.writeInt(this.mAmPmState);
        }

        static {
            CREATOR = new C04181();
        }
    }

    public HmsPicker(Context context) {
        this(context, null);
    }

    public HmsPicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mInputSize = 5;
        this.mNumbers = new Button[10];
        this.mInput = new int[this.mInputSize];
        this.mInputPointer = -1;
        this.mTheme = -1;
        this.mContext = context;
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(getLayoutId(), this);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mKeyBackgroundResId = C0404R.drawable.key_background_dark;
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
        this.mDeleteDrawableSrcResId = C0404R.drawable.ic_backspace_dark;
    }

    protected int getLayoutId() {
        return C0404R.layout.hms_picker_view;
    }

    public void setTheme(int themeResId) {
        this.mTheme = themeResId;
        if (this.mTheme != -1) {
            TypedArray a = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mKeyBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpKeyBackground, this.mKeyBackgroundResId);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpDividerColor, this.mDividerColor);
            this.mDeleteDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDeleteIcon, this.mDeleteDrawableSrcResId);
        }
        restyleViews();
    }

    private void restyleViews() {
        for (Button number : this.mNumbers) {
            if (number != null) {
                number.setTextColor(this.mTextColor);
                number.setBackgroundResource(this.mKeyBackgroundResId);
            }
        }
        if (this.mDivider != null) {
            this.mDivider.setBackgroundColor(this.mDividerColor);
        }
        if (this.mHoursLabel != null) {
            this.mHoursLabel.setTextColor(this.mTextColor);
            this.mHoursLabel.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mMinutesLabel != null) {
            this.mMinutesLabel.setTextColor(this.mTextColor);
            this.mMinutesLabel.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mSecondsLabel != null) {
            this.mSecondsLabel.setTextColor(this.mTextColor);
            this.mSecondsLabel.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mDelete != null) {
            this.mDelete.setBackgroundResource(this.mButtonBackgroundResId);
            this.mDelete.setImageDrawable(getResources().getDrawable(this.mDeleteDrawableSrcResId));
        }
        if (this.mEnteredHms != null) {
            this.mEnteredHms.setTheme(this.mTheme);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        View v1 = findViewById(C0404R.id.first);
        View v2 = findViewById(C0404R.id.second);
        View v3 = findViewById(C0404R.id.third);
        View v4 = findViewById(C0404R.id.fourth);
        this.mEnteredHms = (HmsView) findViewById(C0404R.id.hms_text);
        this.mDelete = (ImageButton) findViewById(C0404R.id.delete);
        this.mDelete.setOnClickListener(this);
        this.mDelete.setOnLongClickListener(this);
        this.mNumbers[1] = (Button) v1.findViewById(C0404R.id.key_left);
        this.mNumbers[2] = (Button) v1.findViewById(C0404R.id.key_middle);
        this.mNumbers[3] = (Button) v1.findViewById(C0404R.id.key_right);
        this.mNumbers[4] = (Button) v2.findViewById(C0404R.id.key_left);
        this.mNumbers[5] = (Button) v2.findViewById(C0404R.id.key_middle);
        this.mNumbers[6] = (Button) v2.findViewById(C0404R.id.key_right);
        this.mNumbers[7] = (Button) v3.findViewById(C0404R.id.key_left);
        this.mNumbers[8] = (Button) v3.findViewById(C0404R.id.key_middle);
        this.mNumbers[9] = (Button) v3.findViewById(C0404R.id.key_right);
        this.mLeft = (Button) v4.findViewById(C0404R.id.key_left);
        this.mNumbers[0] = (Button) v4.findViewById(C0404R.id.key_middle);
        this.mRight = (Button) v4.findViewById(C0404R.id.key_right);
        setLeftRightEnabled(false);
        for (int i = 0; i < 10; i++) {
            this.mNumbers[i].setOnClickListener(this);
            this.mNumbers[i].setText(String.format("%d", new Object[]{Integer.valueOf(i)}));
            this.mNumbers[i].setTag(C0404R.id.numbers_key, new Integer(i));
        }
        updateHms();
        this.mHoursLabel = (TextView) findViewById(C0404R.id.hours_label);
        this.mMinutesLabel = (TextView) findViewById(C0404R.id.minutes_label);
        this.mSecondsLabel = (TextView) findViewById(C0404R.id.seconds_label);
        this.mDivider = findViewById(C0404R.id.divider);
        restyleViews();
        updateKeypad();
    }

    public void updateDeleteButton() {
        boolean enabled = this.mInputPointer != -1;
        if (this.mDelete != null) {
            this.mDelete.setEnabled(enabled);
        }
    }

    public void onClick(View v) {
        v.performHapticFeedback(1);
        doOnClick(v);
        updateDeleteButton();
    }

    protected void doOnClick(View v) {
        Integer val = (Integer) v.getTag(C0404R.id.numbers_key);
        if (val != null) {
            addClickedNumber(val.intValue());
        } else if (v == this.mDelete && this.mInputPointer >= 0) {
            for (int i = 0; i < this.mInputPointer; i++) {
                this.mInput[i] = this.mInput[i + 1];
            }
            this.mInput[this.mInputPointer] = 0;
            this.mInputPointer--;
        }
        updateKeypad();
    }

    public boolean onLongClick(View v) {
        v.performHapticFeedback(0);
        if (v != this.mDelete) {
            return false;
        }
        this.mDelete.setPressed(false);
        reset();
        updateKeypad();
        return true;
    }

    public void reset() {
        for (int i = 0; i < this.mInputSize; i++) {
            this.mInput[i] = 0;
        }
        this.mInputPointer = -1;
        updateHms();
    }

    private void updateKeypad() {
        updateHms();
        enableSetButton();
        updateDeleteButton();
    }

    protected void updateHms() {
        this.mEnteredHms.setTime(this.mInput[4], this.mInput[3], this.mInput[2], this.mInput[1], this.mInput[0]);
    }

    private void addClickedNumber(int val) {
        if (this.mInputPointer < this.mInputSize - 1) {
            for (int i = this.mInputPointer; i >= 0; i--) {
                this.mInput[i + 1] = this.mInput[i];
            }
            this.mInputPointer++;
            this.mInput[0] = val;
        }
    }

    private void enableSetButton() {
        boolean z = false;
        if (this.mSetButton != null) {
            if (this.mInputPointer == -1) {
                this.mSetButton.setEnabled(false);
                return;
            }
            Button button = this.mSetButton;
            if (this.mInputPointer >= 0) {
                z = true;
            }
            button.setEnabled(z);
        }
    }

    public void setSetButton(Button b) {
        this.mSetButton = b;
        enableSetButton();
    }

    public int getHours() {
        return this.mInput[4];
    }

    public int getMinutes() {
        return (this.mInput[3] * 10) + this.mInput[2];
    }

    public int getSeconds() {
        return (this.mInput[1] * 10) + this.mInput[0];
    }

    public void setTime(int hours, int minutes, int seconds) {
        this.mInput[4] = hours;
        this.mInput[3] = minutes / 10;
        this.mInput[2] = minutes % 10;
        this.mInput[1] = seconds / 10;
        this.mInput[0] = seconds % 10;
        for (int i = 4; i >= 0; i--) {
            if (this.mInput[i] > 0) {
                this.mInputPointer = i;
                break;
            }
        }
        updateKeypad();
    }

    public Parcelable onSaveInstanceState() {
        SavedState state = new SavedState(super.onSaveInstanceState());
        state.mInput = this.mInput;
        state.mInputPointer = this.mInputPointer;
        return state;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState savedState = (SavedState) state;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mInputPointer = savedState.mInputPointer;
            this.mInput = savedState.mInput;
            if (this.mInput == null) {
                this.mInput = new int[this.mInputSize];
                this.mInputPointer = -1;
            }
            updateKeypad();
            return;
        }
        super.onRestoreInstanceState(state);
    }

    public int getTime() {
        return ((((this.mInput[4] * 3600) + (this.mInput[3] * 600)) + (this.mInput[2] * 60)) + (this.mInput[1] * 10)) + this.mInput[0];
    }

    public void saveEntryState(Bundle outState, String key) {
        outState.putIntArray(key, this.mInput);
    }

    public void restoreEntryState(Bundle inState, String key) {
        int[] input = inState.getIntArray(key);
        if (input != null && this.mInputSize == input.length) {
            for (int i = 0; i < this.mInputSize; i++) {
                this.mInput[i] = input[i];
                if (this.mInput[i] != 0) {
                    this.mInputPointer = i;
                }
            }
            updateHms();
        }
    }

    protected void setLeftRightEnabled(boolean enabled) {
        this.mLeft.setEnabled(enabled);
        this.mRight.setEnabled(enabled);
        if (!enabled) {
            this.mLeft.setContentDescription(null);
            this.mRight.setContentDescription(null);
        }
    }
}
