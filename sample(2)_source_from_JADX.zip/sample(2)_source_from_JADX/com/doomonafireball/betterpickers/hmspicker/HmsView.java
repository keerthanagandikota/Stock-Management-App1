package com.doomonafireball.betterpickers.hmspicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.widget.ZeroTopPaddingTextView;

public class HmsView extends LinearLayout {
    private final Typeface mAndroidClockMonoThin;
    private ZeroTopPaddingTextView mHoursOnes;
    private ZeroTopPaddingTextView mMinutesOnes;
    private ZeroTopPaddingTextView mMinutesTens;
    private Typeface mOriginalHoursTypeface;
    private ZeroTopPaddingTextView mSecondsOnes;
    private ZeroTopPaddingTextView mSecondsTens;
    private ColorStateList mTextColor;

    public HmsView(Context context) {
        this(context, null);
    }

    public HmsView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mAndroidClockMonoThin = Typeface.createFromAsset(context.getAssets(), "fonts/AndroidClockMono-Thin.ttf");
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
    }

    public void setTheme(int themeResId) {
        if (themeResId != -1) {
            this.mTextColor = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment).getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
        }
        restyleViews();
    }

    private void restyleViews() {
        if (this.mHoursOnes != null) {
            this.mHoursOnes.setTextColor(this.mTextColor);
        }
        if (this.mMinutesOnes != null) {
            this.mMinutesOnes.setTextColor(this.mTextColor);
        }
        if (this.mMinutesTens != null) {
            this.mMinutesTens.setTextColor(this.mTextColor);
        }
        if (this.mSecondsOnes != null) {
            this.mSecondsOnes.setTextColor(this.mTextColor);
        }
        if (this.mSecondsTens != null) {
            this.mSecondsTens.setTextColor(this.mTextColor);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mHoursOnes = (ZeroTopPaddingTextView) findViewById(C0404R.id.hours_ones);
        this.mMinutesTens = (ZeroTopPaddingTextView) findViewById(C0404R.id.minutes_tens);
        this.mMinutesOnes = (ZeroTopPaddingTextView) findViewById(C0404R.id.minutes_ones);
        this.mSecondsTens = (ZeroTopPaddingTextView) findViewById(C0404R.id.seconds_tens);
        this.mSecondsOnes = (ZeroTopPaddingTextView) findViewById(C0404R.id.seconds_ones);
        if (this.mHoursOnes != null) {
            this.mOriginalHoursTypeface = this.mHoursOnes.getTypeface();
            this.mHoursOnes.updatePaddingForBoldDate();
        }
        if (this.mMinutesTens != null) {
            this.mMinutesTens.updatePaddingForBoldDate();
        }
        if (this.mMinutesOnes != null) {
            this.mMinutesOnes.updatePaddingForBoldDate();
        }
        if (this.mSecondsTens != null) {
            this.mSecondsTens.setTypeface(this.mAndroidClockMonoThin);
            this.mSecondsTens.updatePadding();
        }
        if (this.mSecondsOnes != null) {
            this.mSecondsOnes.setTypeface(this.mAndroidClockMonoThin);
            this.mSecondsOnes.updatePadding();
        }
    }

    public void setTime(int hoursOnesDigit, int minutesTensDigit, int minutesOnesDigit, int secondsTensDigit, int secondsOnesDigit) {
        if (this.mHoursOnes != null) {
            this.mHoursOnes.setText(String.format("%d", new Object[]{Integer.valueOf(hoursOnesDigit)}));
        }
        if (this.mMinutesTens != null) {
            this.mMinutesTens.setText(String.format("%d", new Object[]{Integer.valueOf(minutesTensDigit)}));
        }
        if (this.mMinutesOnes != null) {
            this.mMinutesOnes.setText(String.format("%d", new Object[]{Integer.valueOf(minutesOnesDigit)}));
        }
        if (this.mSecondsTens != null) {
            this.mSecondsTens.setText(String.format("%d", new Object[]{Integer.valueOf(secondsTensDigit)}));
        }
        if (this.mSecondsOnes != null) {
            this.mSecondsOnes.setText(String.format("%d", new Object[]{Integer.valueOf(secondsOnesDigit)}));
        }
    }
}
