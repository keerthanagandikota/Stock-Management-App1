package com.doomonafireball.betterpickers.hmspicker;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import com.doomonafireball.betterpickers.hmspicker.HmsPickerDialogFragment.HmsPickerDialogHandler;
import java.util.Vector;

public class HmsPickerBuilder {
    private Vector<HmsPickerDialogHandler> mHmsPickerDialogHandlers;
    private int mHours;
    private int mMinutes;
    private int mReference;
    private int mSeconds;
    private FragmentManager manager;
    private Integer styleResId;
    private Fragment targetFragment;

    public HmsPickerBuilder() {
        this.mHmsPickerDialogHandlers = new Vector();
    }

    public HmsPickerBuilder setFragmentManager(FragmentManager manager) {
        this.manager = manager;
        return this;
    }

    public HmsPickerBuilder setStyleResId(int styleResId) {
        this.styleResId = Integer.valueOf(styleResId);
        return this;
    }

    public HmsPickerBuilder setTargetFragment(Fragment targetFragment) {
        this.targetFragment = targetFragment;
        return this;
    }

    public HmsPickerBuilder setReference(int reference) {
        this.mReference = reference;
        return this;
    }

    public HmsPickerBuilder addHmsPickerDialogHandler(HmsPickerDialogHandler handler) {
        this.mHmsPickerDialogHandlers.add(handler);
        return this;
    }

    public HmsPickerBuilder removeHmsPickerDialogHandler(HmsPickerDialogHandler handler) {
        this.mHmsPickerDialogHandlers.remove(handler);
        return this;
    }

    public HmsPickerBuilder setTime(int hours, int minutes, int seconds) {
        this.mHours = bounded(hours, 0, 99);
        this.mMinutes = bounded(minutes, 0, 99);
        this.mSeconds = bounded(seconds, 0, 99);
        return this;
    }

    public void show() {
        if (this.manager == null || this.styleResId == null) {
            Log.e("HmsPickerBuilder", "setFragmentManager() and setStyleResId() must be called.");
            return;
        }
        FragmentTransaction ft = this.manager.beginTransaction();
        Fragment prev = this.manager.findFragmentByTag("hms_dialog");
        if (prev != null) {
            ft.remove(prev);
        }
        ft.addToBackStack(null);
        HmsPickerDialogFragment fragment = HmsPickerDialogFragment.newInstance(this.mReference, this.styleResId.intValue());
        if (this.targetFragment != null) {
            fragment.setTargetFragment(this.targetFragment, 0);
        }
        fragment.setHmsPickerDialogHandlers(this.mHmsPickerDialogHandlers);
        if (((this.mHours | this.mMinutes) | this.mSeconds) != 0) {
            fragment.setTime(this.mHours, this.mMinutes, this.mSeconds);
        }
        fragment.show(ft, "hms_dialog");
    }

    private static int bounded(int i, int min, int max) {
        return Math.min(Math.max(i, min), max);
    }
}
