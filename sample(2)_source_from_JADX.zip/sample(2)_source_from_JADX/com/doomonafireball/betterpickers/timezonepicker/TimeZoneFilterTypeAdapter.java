package com.doomonafireball.betterpickers.timezonepicker;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filter.FilterResults;
import android.widget.Filterable;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.TouchExplorationHelper;
import io.buildup.pkg20170504080645.C0585R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class TimeZoneFilterTypeAdapter extends BaseAdapter implements Filterable, OnClickListener {
    private static final boolean DEBUG = false;
    public static final int FILTER_TYPE_COUNTRY = 1;
    public static final int FILTER_TYPE_EMPTY = -1;
    public static final int FILTER_TYPE_GMT = 3;
    public static final int FILTER_TYPE_NONE = 0;
    public static final int FILTER_TYPE_STATE = 2;
    public static final String TAG = "TimeZoneFilterTypeAdapter";
    OnClickListener mDummyListener;
    private ArrayFilter mFilter;
    private LayoutInflater mInflater;
    private OnSetFilterListener mListener;
    private ArrayList<FilterTypeResult> mLiveResults;
    private int mLiveResultsCount;
    private Typeface mSansSerifLightTypeface;
    private TimeZoneData mTimeZoneData;

    /* renamed from: com.doomonafireball.betterpickers.timezonepicker.TimeZoneFilterTypeAdapter.1 */
    class C04451 implements OnClickListener {
        C04451() {
        }

        public void onClick(View v) {
        }
    }

    private class ArrayFilter extends Filter {
        private ArrayFilter() {
        }

        protected FilterResults performFiltering(CharSequence prefix) {
            FilterResults results = new FilterResults();
            String prefixString = null;
            if (prefix != null) {
                prefixString = prefix.toString().trim().toLowerCase();
            }
            if (TextUtils.isEmpty(prefixString)) {
                results.values = null;
                results.count = TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE;
            } else {
                ArrayList<FilterTypeResult> filtered = new ArrayList();
                int startParsePosition = TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE;
                if (prefixString.charAt(TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE) == '+' || prefixString.charAt(TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE) == '-') {
                }
                if (prefixString.startsWith("gmt")) {
                    startParsePosition = TimeZoneFilterTypeAdapter.FILTER_TYPE_GMT;
                }
                int num = parseNum(prefixString, startParsePosition);
                if (num != Integer.MIN_VALUE) {
                    boolean positiveOnly = (prefixString.length() <= startParsePosition || prefixString.charAt(startParsePosition) != '+') ? TimeZoneFilterTypeAdapter.DEBUG : true;
                    handleSearchByGmt(filtered, num, positiveOnly);
                }
                ArrayList<String> countries = new ArrayList();
                for (String country : TimeZoneFilterTypeAdapter.this.mTimeZoneData.mTimeZonesByCountry.keySet()) {
                    if (!TextUtils.isEmpty(country)) {
                        String lowerCaseCountry = country.toLowerCase();
                        boolean isMatch = TimeZoneFilterTypeAdapter.DEBUG;
                        if (lowerCaseCountry.startsWith(prefixString) || (lowerCaseCountry.charAt(TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE) == prefixString.charAt(TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE) && isStartingInitialsFor(prefixString, lowerCaseCountry))) {
                            isMatch = true;
                        } else {
                            if (lowerCaseCountry.contains(" ")) {
                                String[] split = lowerCaseCountry.split(" ");
                                int length = split.length;
                                for (int i = TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE; i < length; i += TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY) {
                                    if (split[i].startsWith(prefixString)) {
                                        isMatch = true;
                                        break;
                                    }
                                }
                            }
                        }
                        if (isMatch) {
                            countries.add(country);
                        }
                    }
                }
                if (countries.size() > 0) {
                    Collections.sort(countries);
                    Iterator it = countries.iterator();
                    while (it.hasNext()) {
                        filtered.add(new FilterTypeResult(TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY, (String) it.next(), TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE));
                    }
                }
                results.values = filtered;
                results.count = filtered.size();
            }
            return results;
        }

        private boolean isStartingInitialsFor(String prefixString, String string) {
            int initialLen = prefixString.length();
            int strLen = string.length();
            boolean wasWordBreak = true;
            int i = TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE;
            int initialIdx = TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE;
            while (i < strLen) {
                int initialIdx2;
                if (!Character.isLetter(string.charAt(i))) {
                    wasWordBreak = true;
                    initialIdx2 = initialIdx;
                } else if (wasWordBreak) {
                    initialIdx2 = initialIdx + TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY;
                    if (prefixString.charAt(initialIdx) != string.charAt(i)) {
                        return TimeZoneFilterTypeAdapter.DEBUG;
                    }
                    if (initialIdx2 == initialLen) {
                        return true;
                    }
                    wasWordBreak = TimeZoneFilterTypeAdapter.DEBUG;
                } else {
                    initialIdx2 = initialIdx;
                }
                i += TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY;
                initialIdx = initialIdx2;
            }
            if (prefixString.equals("usa") && string.equals("united states")) {
                initialIdx2 = initialIdx;
                return true;
            }
            return TimeZoneFilterTypeAdapter.DEBUG;
        }

        private void handleSearchByGmt(ArrayList<FilterTypeResult> filtered, int num, boolean positiveOnly) {
            int i;
            if (num >= 0) {
                if (num == TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY) {
                    for (i = 19; i >= 10; i += TimeZoneFilterTypeAdapter.FILTER_TYPE_EMPTY) {
                        if (TimeZoneFilterTypeAdapter.this.mTimeZoneData.hasTimeZonesInHrOffset(i)) {
                            filtered.add(new FilterTypeResult(TimeZoneFilterTypeAdapter.FILTER_TYPE_GMT, "GMT+" + i, i));
                        }
                    }
                }
                if (TimeZoneFilterTypeAdapter.this.mTimeZoneData.hasTimeZonesInHrOffset(num)) {
                    filtered.add(new FilterTypeResult(TimeZoneFilterTypeAdapter.FILTER_TYPE_GMT, "GMT+" + num, num));
                }
                num *= TimeZoneFilterTypeAdapter.FILTER_TYPE_EMPTY;
            }
            if (!positiveOnly && num != 0) {
                if (TimeZoneFilterTypeAdapter.this.mTimeZoneData.hasTimeZonesInHrOffset(num)) {
                    filtered.add(new FilterTypeResult(TimeZoneFilterTypeAdapter.FILTER_TYPE_GMT, "GMT" + num, num));
                }
                if (num == TimeZoneFilterTypeAdapter.FILTER_TYPE_EMPTY) {
                    for (i = -10; i >= -19; i += TimeZoneFilterTypeAdapter.FILTER_TYPE_EMPTY) {
                        if (TimeZoneFilterTypeAdapter.this.mTimeZoneData.hasTimeZonesInHrOffset(i)) {
                            filtered.add(new FilterTypeResult(TimeZoneFilterTypeAdapter.FILTER_TYPE_GMT, "GMT" + i, i));
                        }
                    }
                }
            }
        }

        public int parseNum(String str, int startIndex) {
            int idx = startIndex;
            int negativeMultiplier = TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY;
            int idx2 = idx + TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY;
            char ch = str.charAt(idx);
            switch (ch) {
                case C0585R.styleable.Theme_dialogPreferredPadding /*43*/:
                    break;
                case C0585R.styleable.Theme_actionDropDownStyle /*45*/:
                    negativeMultiplier = TimeZoneFilterTypeAdapter.FILTER_TYPE_EMPTY;
                    break;
                default:
                    idx = idx2;
                    break;
            }
            if (idx2 >= str.length()) {
                idx = idx2;
                return TouchExplorationHelper.INVALID_ID;
            }
            idx = idx2 + TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY;
            ch = str.charAt(idx2);
            if (!Character.isDigit(ch)) {
                return TouchExplorationHelper.INVALID_ID;
            }
            int num = Character.digit(ch, 10);
            if (idx < str.length()) {
                idx2 = idx + TimeZoneFilterTypeAdapter.FILTER_TYPE_COUNTRY;
                ch = str.charAt(idx);
                if (Character.isDigit(ch)) {
                    num = (num * 10) + Character.digit(ch, 10);
                    idx = idx2;
                } else {
                    return TouchExplorationHelper.INVALID_ID;
                }
            }
            if (idx == str.length()) {
                return negativeMultiplier * num;
            }
            return TouchExplorationHelper.INVALID_ID;
        }

        protected void publishResults(CharSequence constraint, FilterResults results) {
            if (results.values != null && results.count != 0) {
                TimeZoneFilterTypeAdapter.this.mLiveResults = (ArrayList) results.values;
            } else if (TimeZoneFilterTypeAdapter.this.mListener != null) {
                int filterType;
                if (TextUtils.isEmpty(constraint)) {
                    filterType = TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE;
                } else {
                    filterType = TimeZoneFilterTypeAdapter.FILTER_TYPE_EMPTY;
                }
                TimeZoneFilterTypeAdapter.this.mListener.onSetFilter(filterType, null, TimeZoneFilterTypeAdapter.FILTER_TYPE_NONE);
            }
            TimeZoneFilterTypeAdapter.this.mLiveResultsCount = results.count;
            if (results.count > 0) {
                TimeZoneFilterTypeAdapter.this.notifyDataSetChanged();
            } else {
                TimeZoneFilterTypeAdapter.this.notifyDataSetInvalidated();
            }
        }
    }

    class FilterTypeResult {
        String constraint;
        public int time;
        int type;

        public FilterTypeResult(int type, String constraint, int time) {
            this.type = type;
            this.constraint = constraint;
            this.time = time;
        }

        public String toString() {
            return this.constraint;
        }
    }

    public interface OnSetFilterListener {
        void onSetFilter(int i, String str, int i2);
    }

    static class ViewHolder {
        int filterType;
        String str;
        TextView strTextView;
        int time;

        ViewHolder() {
        }

        static void setupViewHolder(View v) {
            ViewHolder vh = new ViewHolder();
            vh.strTextView = (TextView) v.findViewById(C0404R.id.value);
            v.setTag(vh);
        }
    }

    public TimeZoneFilterTypeAdapter(Context context, TimeZoneData tzd, OnSetFilterListener l) {
        this.mLiveResults = new ArrayList();
        this.mLiveResultsCount = FILTER_TYPE_NONE;
        this.mDummyListener = new C04451();
        this.mTimeZoneData = tzd;
        this.mListener = l;
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.mSansSerifLightTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/Roboto-Light.ttf");
    }

    public int getCount() {
        return this.mLiveResultsCount;
    }

    public FilterTypeResult getItem(int position) {
        return (FilterTypeResult) this.mLiveResults.get(position);
    }

    public long getItemId(int position) {
        return (long) position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v;
        if (convertView != null) {
            v = convertView;
        } else {
            v = this.mInflater.inflate(C0404R.layout.time_zone_filter_item, null);
            ViewHolder.setupViewHolder(v);
        }
        ViewHolder vh = (ViewHolder) v.getTag();
        if (position >= this.mLiveResults.size()) {
            Log.e(TAG, "getView: " + position + " of " + this.mLiveResults.size());
        }
        FilterTypeResult filter = (FilterTypeResult) this.mLiveResults.get(position);
        vh.filterType = filter.type;
        vh.str = filter.constraint;
        vh.time = filter.time;
        vh.strTextView.setText(filter.constraint);
        vh.strTextView.setTypeface(this.mSansSerifLightTypeface);
        return v;
    }

    public void onClick(View v) {
        if (!(this.mListener == null || v == null)) {
            ViewHolder vh = (ViewHolder) v.getTag();
            this.mListener.onSetFilter(vh.filterType, vh.str, vh.time);
        }
        notifyDataSetInvalidated();
    }

    public Filter getFilter() {
        if (this.mFilter == null) {
            this.mFilter = new ArrayFilter();
        }
        return this.mFilter;
    }
}
