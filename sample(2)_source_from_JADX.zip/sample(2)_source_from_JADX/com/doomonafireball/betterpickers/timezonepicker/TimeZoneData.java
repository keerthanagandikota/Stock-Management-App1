package com.doomonafireball.betterpickers.timezonepicker;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.text.format.DateFormat;
import android.util.Log;
import android.util.SparseArray;
import com.doomonafireball.betterpickers.C0404R;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.TimeZone;

public class TimeZoneData {
    private static final boolean DEBUG = false;
    private static final int OFFSET_ARRAY_OFFSET = 20;
    private static final String PALESTINE_COUNTRY_CODE = "PS";
    private static final String TAG = "TimeZoneData";
    public static boolean is24HourFormat;
    private static String[] mBackupCountryCodes;
    private static Locale mBackupCountryLocale;
    private static String[] mBackupCountryNames;
    private String mAlternateDefaultTimeZoneId;
    private Context mContext;
    private HashMap<String, String> mCountryCodeToNameMap;
    private String mDefaultTimeZoneCountry;
    public String mDefaultTimeZoneId;
    private TimeZoneInfo mDefaultTimeZoneInfo;
    private boolean[] mHasTimeZonesInHrOffset;
    private String mPalestineDisplayName;
    private long mTimeMillis;
    HashSet<String> mTimeZoneNames;
    ArrayList<TimeZoneInfo> mTimeZones;
    LinkedHashMap<String, ArrayList<Integer>> mTimeZonesByCountry;
    private HashMap<String, TimeZoneInfo> mTimeZonesById;
    SparseArray<ArrayList<Integer>> mTimeZonesByOffsets;

    public TimeZoneData(Context context, String defaultTimeZoneId, long timeMillis) {
        this.mTimeZoneNames = new HashSet();
        this.mCountryCodeToNameMap = new HashMap();
        this.mHasTimeZonesInHrOffset = new boolean[40];
        this.mContext = context;
        boolean is24HourFormat = DateFormat.is24HourFormat(context);
        TimeZoneInfo.is24HourFormat = is24HourFormat;
        is24HourFormat = is24HourFormat;
        this.mAlternateDefaultTimeZoneId = defaultTimeZoneId;
        this.mDefaultTimeZoneId = defaultTimeZoneId;
        long now = System.currentTimeMillis();
        if (timeMillis == 0) {
            this.mTimeMillis = now;
        } else {
            this.mTimeMillis = timeMillis;
        }
        this.mPalestineDisplayName = context.getResources().getString(C0404R.string.palestine_display_name);
        loadTzs(context);
        Log.i(TAG, "Time to load time zones (ms): " + (System.currentTimeMillis() - now));
    }

    public void setTime(long timeMillis) {
        this.mTimeMillis = timeMillis;
    }

    public TimeZoneInfo get(int position) {
        return (TimeZoneInfo) this.mTimeZones.get(position);
    }

    public int size() {
        return this.mTimeZones.size();
    }

    public int getDefaultTimeZoneIndex() {
        return this.mTimeZones.indexOf(this.mDefaultTimeZoneInfo);
    }

    public int findIndexByTimeZoneIdSlow(String timeZoneId) {
        int idx = 0;
        Iterator it = this.mTimeZones.iterator();
        while (it.hasNext()) {
            if (timeZoneId.equals(((TimeZoneInfo) it.next()).mTzId)) {
                return idx;
            }
            idx++;
        }
        return -1;
    }

    void loadTzs(Context context) {
        this.mTimeZones = new ArrayList();
        HashSet<String> processedTimeZones = loadTzsInZoneTab(context);
        for (String tzId : TimeZone.getAvailableIDs()) {
            if (!processedTimeZones.contains(tzId) && tzId.startsWith("Etc/GMT")) {
                TimeZone tz = TimeZone.getTimeZone(tzId);
                if (tz == null) {
                    Log.e(TAG, "Timezone not found: " + tzId);
                } else {
                    TimeZoneInfo tzInfo = new TimeZoneInfo(tz, null);
                    if (getIdenticalTimeZoneInTheCountry(tzInfo) == -1) {
                        this.mTimeZones.add(tzInfo);
                    }
                }
            }
        }
        Collections.sort(this.mTimeZones);
        this.mTimeZonesByCountry = new LinkedHashMap();
        this.mTimeZonesByOffsets = new SparseArray(this.mHasTimeZonesInHrOffset.length);
        this.mTimeZonesById = new HashMap(this.mTimeZones.size());
        Iterator it = this.mTimeZones.iterator();
        while (it.hasNext()) {
            TimeZoneInfo tz2 = (TimeZoneInfo) it.next();
            this.mTimeZonesById.put(tz2.mTzId, tz2);
        }
        populateDisplayNameOverrides(this.mContext.getResources());
        Date date = new Date(this.mTimeMillis);
        Locale defaultLocal = Locale.getDefault();
        int idx = 0;
        it = this.mTimeZones.iterator();
        while (it.hasNext()) {
            tz2 = (TimeZoneInfo) it.next();
            if (tz2.mDisplayName == null) {
                tz2.mDisplayName = tz2.mTz.getDisplayName(tz2.mTz.inDaylightTime(date), 1, defaultLocal);
            }
            ArrayList<Integer> group = (ArrayList) this.mTimeZonesByCountry.get(tz2.mCountry);
            if (group == null) {
                group = new ArrayList();
                this.mTimeZonesByCountry.put(tz2.mCountry, group);
            }
            group.add(Integer.valueOf(idx));
            indexByOffsets(idx, tz2);
            if (!tz2.mDisplayName.endsWith(":00")) {
                this.mTimeZoneNames.add(tz2.mDisplayName);
            }
            idx++;
        }
    }

    private void printTimeZones() {
        TimeZoneInfo last = null;
        boolean first = true;
        Iterator it = this.mTimeZones.iterator();
        while (it.hasNext()) {
            TimeZoneInfo tz = (TimeZoneInfo) it.next();
            if (tz.mTz.getDisplayName().startsWith("GMT") && !tz.mTzId.startsWith("Etc/GMT")) {
                Log.e("GMT", tz.toString());
            }
            if (last != null) {
                if (last.compareTo(tz) == 0) {
                    if (first) {
                        Log.e("SAME", last.toString());
                        first = DEBUG;
                    }
                    Log.e("SAME", tz.toString());
                } else {
                    first = true;
                }
            }
            last = tz;
        }
        Log.e(TAG, "Total number of tz's = " + this.mTimeZones.size());
    }

    private void populateDisplayNameOverrides(Resources resources) {
        String[] ids = resources.getStringArray(C0404R.array.timezone_rename_ids);
        String[] labels = resources.getStringArray(C0404R.array.timezone_rename_labels);
        int length = ids.length;
        if (ids.length != labels.length) {
            Log.e(TAG, "timezone_rename_ids len=" + ids.length + " timezone_rename_labels len=" + labels.length);
            length = Math.min(ids.length, labels.length);
        }
        for (int i = 0; i < length; i++) {
            TimeZoneInfo tzi = (TimeZoneInfo) this.mTimeZonesById.get(ids[i]);
            if (tzi != null) {
                tzi.mDisplayName = labels[i];
            } else {
                Log.e(TAG, "Could not find timezone with label: " + labels[i]);
            }
        }
    }

    public boolean hasTimeZonesInHrOffset(int offsetHr) {
        int index = offsetHr + OFFSET_ARRAY_OFFSET;
        if (index >= this.mHasTimeZonesInHrOffset.length || index < 0) {
            return DEBUG;
        }
        return this.mHasTimeZonesInHrOffset[index];
    }

    private void indexByOffsets(int idx, TimeZoneInfo tzi) {
        int index = ((int) (((long) tzi.getNowOffsetMillis()) / 3600000)) + OFFSET_ARRAY_OFFSET;
        this.mHasTimeZonesInHrOffset[index] = true;
        ArrayList<Integer> group = (ArrayList) this.mTimeZonesByOffsets.get(index);
        if (group == null) {
            group = new ArrayList();
            this.mTimeZonesByOffsets.put(index, group);
        }
        group.add(Integer.valueOf(idx));
    }

    public ArrayList<Integer> getTimeZonesByOffset(int offsetHr) {
        int index = offsetHr + OFFSET_ARRAY_OFFSET;
        if (index >= this.mHasTimeZonesInHrOffset.length || index < 0) {
            return null;
        }
        return (ArrayList) this.mTimeZonesByOffsets.get(index);
    }

    private HashSet<String> loadTzsInZoneTab(Context context) {
        BufferedReader bufferedReader;
        String line;
        HashSet<String> processedTimeZones = new HashSet();
        AssetManager am = context.getAssets();
        InputStream is = null;
        try {
            is = am.open("backward");
            bufferedReader = new BufferedReader(new InputStreamReader(is));
            while (true) {
                line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                if (!line.startsWith("#") && line.length() > 0) {
                    String[] fields = line.split("\t+");
                    String newTzId = fields[1];
                    String oldTzId = fields[fields.length - 1];
                    if (TimeZone.getTimeZone(newTzId) == null) {
                        Log.e(TAG, "Timezone not found: " + newTzId);
                    } else {
                        processedTimeZones.add(oldTzId);
                        if (this.mDefaultTimeZoneId != null) {
                            if (this.mDefaultTimeZoneId.equals(oldTzId)) {
                                this.mAlternateDefaultTimeZoneId = newTzId;
                            }
                        }
                    }
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                }
            }
        } catch (IOException e2) {
            Log.e(TAG, "Failed to read 'backward' file.");
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e3) {
                }
            }
        } catch (Throwable th) {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e4) {
                }
            }
        }
        try {
            String lang = Locale.getDefault().getLanguage();
            is = am.open("zone.tab");
            bufferedReader = new BufferedReader(new InputStreamReader(is));
            while (true) {
                line = bufferedReader.readLine();
                if (line == null) {
                    break;
                }
                if (!line.startsWith("#")) {
                    fields = line.split("\t");
                    String timeZoneId = fields[2];
                    String countryCode = fields[0];
                    TimeZone tz = TimeZone.getTimeZone(timeZoneId);
                    if (tz == null) {
                        Log.e(TAG, "Timezone not found: " + timeZoneId);
                    } else {
                        if (countryCode == null) {
                            if (!timeZoneId.startsWith("Etc/GMT")) {
                                processedTimeZones.add(timeZoneId);
                            }
                        }
                        String country = (String) this.mCountryCodeToNameMap.get(countryCode);
                        if (country == null) {
                            country = getCountryNames(lang, countryCode);
                            this.mCountryCodeToNameMap.put(countryCode, country);
                        }
                        if (this.mDefaultTimeZoneId != null && this.mDefaultTimeZoneCountry == null) {
                            if (timeZoneId.equals(this.mAlternateDefaultTimeZoneId)) {
                                this.mDefaultTimeZoneCountry = country;
                                TimeZone defaultTz = TimeZone.getTimeZone(this.mDefaultTimeZoneId);
                                if (defaultTz != null) {
                                    this.mDefaultTimeZoneInfo = new TimeZoneInfo(defaultTz, country);
                                    int tzToOverride = getIdenticalTimeZoneInTheCountry(this.mDefaultTimeZoneInfo);
                                    if (tzToOverride == -1) {
                                        this.mTimeZones.add(this.mDefaultTimeZoneInfo);
                                    } else {
                                        this.mTimeZones.add(tzToOverride, this.mDefaultTimeZoneInfo);
                                    }
                                }
                            }
                        }
                        TimeZoneInfo timeZoneInfo = new TimeZoneInfo(tz, country);
                        if (getIdenticalTimeZoneInTheCountry(timeZoneInfo) == -1) {
                            this.mTimeZones.add(timeZoneInfo);
                        }
                        processedTimeZones.add(timeZoneId);
                    }
                }
            }
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e5) {
                }
            }
        } catch (IOException e6) {
            Log.e(TAG, "Failed to read 'zone.tab'.");
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e7) {
                }
            }
        } catch (Throwable th2) {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e8) {
                }
            }
        }
        return processedTimeZones;
    }

    private String getCountryNames(String lang, String countryCode) {
        String countryDisplayName;
        Locale defaultLocale = Locale.getDefault();
        if (PALESTINE_COUNTRY_CODE.equalsIgnoreCase(countryCode)) {
            countryDisplayName = this.mPalestineDisplayName;
        } else {
            countryDisplayName = new Locale(lang, countryCode).getDisplayCountry(defaultLocale);
        }
        if (!countryCode.equals(countryDisplayName)) {
            return countryDisplayName;
        }
        if (mBackupCountryCodes == null || !defaultLocale.equals(mBackupCountryLocale)) {
            mBackupCountryLocale = defaultLocale;
            mBackupCountryCodes = this.mContext.getResources().getStringArray(C0404R.array.backup_country_codes);
            mBackupCountryNames = this.mContext.getResources().getStringArray(C0404R.array.backup_country_names);
        }
        int length = Math.min(mBackupCountryCodes.length, mBackupCountryNames.length);
        for (int i = 0; i < length; i++) {
            if (mBackupCountryCodes[i].equals(countryCode)) {
                return mBackupCountryNames[i];
            }
        }
        return countryCode;
    }

    private int getIdenticalTimeZoneInTheCountry(TimeZoneInfo timeZoneInfo) {
        int idx = 0;
        Iterator it = this.mTimeZones.iterator();
        while (it.hasNext()) {
            TimeZoneInfo tzi = (TimeZoneInfo) it.next();
            if (tzi.hasSameRules(timeZoneInfo)) {
                if (tzi.mCountry == null) {
                    if (timeZoneInfo.mCountry == null) {
                        return idx;
                    }
                } else if (tzi.mCountry.equals(timeZoneInfo.mCountry)) {
                    return idx;
                }
            }
            idx++;
        }
        return -1;
    }
}
