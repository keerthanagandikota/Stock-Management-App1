package com.doomonafireball.betterpickers.timezonepicker;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AutoCompleteTextView;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import com.doomonafireball.betterpickers.C0404R;

public class TimeZonePickerView extends LinearLayout implements TextWatcher, OnItemClickListener, OnClickListener {
    private static final String TAG = "TimeZonePickerView";
    private AutoCompleteTextView mAutoCompleteTextView;
    private ImageButton mClearButton;
    private Context mContext;
    private TimeZoneFilterTypeAdapter mFilterAdapter;
    private boolean mFirstTime;
    private boolean mHideFilterSearchOnStart;
    TimeZoneResultAdapter mResultAdapter;
    private Typeface mSansSerifLightTypeface;

    public interface OnTimeZoneSetListener {
        void onTimeZoneSet(TimeZoneInfo timeZoneInfo);
    }

    /* renamed from: com.doomonafireball.betterpickers.timezonepicker.TimeZonePickerView.1 */
    class C04461 implements OnClickListener {
        C04461() {
        }

        public void onClick(View v) {
            TimeZonePickerView.this.mAutoCompleteTextView.getEditableText().clear();
        }
    }

    public TimeZonePickerView(Context context, AttributeSet attrs, String timeZone, long timeMillis, OnTimeZoneSetListener l, boolean hideFilterSearch) {
        super(context, attrs);
        this.mHideFilterSearchOnStart = false;
        this.mFirstTime = true;
        this.mContext = context;
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(C0404R.layout.timezonepickerview, this, true);
        this.mSansSerifLightTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/Roboto-Light.ttf");
        this.mHideFilterSearchOnStart = hideFilterSearch;
        TimeZoneData tzd = new TimeZoneData(this.mContext, timeZone, timeMillis);
        this.mResultAdapter = new TimeZoneResultAdapter(this.mContext, tzd, l);
        ListView timeZoneList = (ListView) findViewById(C0404R.id.timezonelist);
        timeZoneList.setAdapter(this.mResultAdapter);
        timeZoneList.setOnItemClickListener(this.mResultAdapter);
        this.mFilterAdapter = new TimeZoneFilterTypeAdapter(this.mContext, tzd, this.mResultAdapter);
        this.mAutoCompleteTextView = (AutoCompleteTextView) findViewById(C0404R.id.searchBox);
        this.mAutoCompleteTextView.setTypeface(this.mSansSerifLightTypeface);
        this.mAutoCompleteTextView.addTextChangedListener(this);
        this.mAutoCompleteTextView.setOnItemClickListener(this);
        this.mAutoCompleteTextView.setOnClickListener(this);
        updateHint(C0404R.string.hint_time_zone_search, C0404R.drawable.ic_search_holo_light);
        this.mClearButton = (ImageButton) findViewById(C0404R.id.clear_search);
        this.mClearButton.setOnClickListener(new C04461());
    }

    public void showFilterResults(int type, String string, int time) {
        if (this.mResultAdapter != null) {
            this.mResultAdapter.onSetFilter(type, string, time);
        }
    }

    public boolean hasResults() {
        return this.mResultAdapter != null && this.mResultAdapter.hasResults();
    }

    public int getLastFilterType() {
        return this.mResultAdapter != null ? this.mResultAdapter.getLastFilterType() : -1;
    }

    public String getLastFilterString() {
        return this.mResultAdapter != null ? this.mResultAdapter.getLastFilterString() : null;
    }

    public int getLastFilterTime() {
        return this.mResultAdapter != null ? this.mResultAdapter.getLastFilterType() : -1;
    }

    public boolean getHideFilterSearchOnStart() {
        return this.mHideFilterSearchOnStart;
    }

    private void updateHint(int hintTextId, int imageDrawableId) {
        String hintText = getResources().getString(hintTextId);
        Drawable searchIcon = getResources().getDrawable(imageDrawableId);
        SpannableStringBuilder ssb = new SpannableStringBuilder("   ");
        ssb.append(hintText);
        int textSize = (int) (((double) this.mAutoCompleteTextView.getTextSize()) * 1.25d);
        searchIcon.setBounds(0, 0, textSize, textSize);
        ssb.setSpan(new ImageSpan(searchIcon), 1, 2, 33);
        this.mAutoCompleteTextView.setHint(ssb);
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {
        if (this.mFirstTime && this.mHideFilterSearchOnStart) {
            this.mFirstTime = false;
        } else {
            filterOnString(s.toString());
        }
    }

    public void afterTextChanged(Editable s) {
        if (this.mClearButton != null) {
            this.mClearButton.setVisibility(s.length() > 0 ? 0 : 8);
        }
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        ((InputMethodManager) getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.mAutoCompleteTextView.getWindowToken(), 0);
        this.mHideFilterSearchOnStart = true;
        this.mFilterAdapter.onClick(view);
    }

    public void onClick(View v) {
        if (this.mAutoCompleteTextView != null && !this.mAutoCompleteTextView.isPopupShowing()) {
            filterOnString(this.mAutoCompleteTextView.getText().toString());
        }
    }

    private void filterOnString(String string) {
        if (this.mAutoCompleteTextView.getAdapter() == null) {
            this.mAutoCompleteTextView.setAdapter(this.mFilterAdapter);
        }
        this.mHideFilterSearchOnStart = false;
        this.mFilterAdapter.getFilter().filter(string);
    }
}
