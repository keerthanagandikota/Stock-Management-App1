package com.doomonafireball.betterpickers.timezonepicker;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.timezonepicker.TimeZoneFilterTypeAdapter.OnSetFilterListener;
import com.doomonafireball.betterpickers.timezonepicker.TimeZonePickerView.OnTimeZoneSetListener;
import com.nineoldandroids.animation.ValueAnimator;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import org.jraf.android.backport.switchwidget.C0678R;

public class TimeZoneResultAdapter extends BaseAdapter implements OnItemClickListener, OnSetFilterListener {
    private static final boolean DEBUG = false;
    private static final int EMPTY_INDEX = -100;
    private static final String KEY_RECENT_TIMEZONES = "preferences_recent_timezones";
    private static final int MAX_RECENT_TIMEZONES = 3;
    private static final String RECENT_TIMEZONES_DELIMITER = ",";
    private static final String SHARED_PREFS_NAME = "com.android.calendar_preferences";
    private static final String TAG = "TimeZoneResultAdapter";
    private static final int VIEW_TAG_TIME_ZONE;
    private Context mContext;
    private int[] mFilteredTimeZoneIndices;
    private int mFilteredTimeZoneLength;
    private boolean mHasResults;
    private LayoutInflater mInflater;
    private String mLastFilterString;
    private int mLastFilterTime;
    private int mLastFilterType;
    private Typeface mSansSerifLightTypeface;
    private TimeZoneData mTimeZoneData;
    private OnTimeZoneSetListener mTimeZoneSetListener;

    static class ViewHolder {
        TextView location;
        TextView timeOffset;
        TextView timeZone;

        ViewHolder() {
        }

        static void setupViewHolder(View v) {
            ViewHolder vh = new ViewHolder();
            vh.timeZone = (TextView) v.findViewById(C0404R.id.time_zone);
            vh.timeOffset = (TextView) v.findViewById(C0404R.id.time_offset);
            vh.location = (TextView) v.findViewById(C0404R.id.location);
            v.setTag(vh);
        }
    }

    static {
        VIEW_TAG_TIME_ZONE = C0404R.id.time_zone;
    }

    public TimeZoneResultAdapter(Context context, TimeZoneData tzd, OnTimeZoneSetListener l) {
        this.mHasResults = DEBUG;
        this.mFilteredTimeZoneLength = 0;
        this.mContext = context;
        this.mTimeZoneData = tzd;
        this.mTimeZoneSetListener = l;
        this.mInflater = (LayoutInflater) context.getSystemService("layout_inflater");
        this.mFilteredTimeZoneIndices = new int[this.mTimeZoneData.size()];
        this.mSansSerifLightTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/Roboto-Light.ttf");
        onSetFilter(0, null, 0);
    }

    public boolean hasResults() {
        return this.mHasResults;
    }

    public int getLastFilterType() {
        return this.mLastFilterType;
    }

    public String getLastFilterString() {
        return this.mLastFilterString;
    }

    public int getLastFilterTime() {
        return this.mLastFilterTime;
    }

    public void onSetFilter(int filterType, String str, int time) {
        this.mLastFilterType = filterType;
        this.mLastFilterString = str;
        this.mLastFilterTime = time;
        this.mFilteredTimeZoneLength = 0;
        int[] iArr;
        int i;
        Iterator it;
        int[] iArr2;
        int i2;
        switch (filterType) {
            case ValueAnimator.INFINITE /*-1*/:
                iArr = this.mFilteredTimeZoneIndices;
                i = this.mFilteredTimeZoneLength;
                this.mFilteredTimeZoneLength = i + 1;
                iArr[i] = EMPTY_INDEX;
                break;
            case C0678R.styleable.Switch_asb_thumb /*0*/:
                int defaultTzIndex = this.mTimeZoneData.getDefaultTimeZoneIndex();
                if (defaultTzIndex != -1) {
                    iArr = this.mFilteredTimeZoneIndices;
                    i = this.mFilteredTimeZoneLength;
                    this.mFilteredTimeZoneLength = i + 1;
                    iArr[i] = defaultTzIndex;
                }
                String recentsString = this.mContext.getSharedPreferences(SHARED_PREFS_NAME, 0).getString(KEY_RECENT_TIMEZONES, null);
                if (!TextUtils.isEmpty(recentsString)) {
                    String[] recents = recentsString.split(RECENT_TIMEZONES_DELIMITER);
                    int i3 = recents.length - 1;
                    while (i3 >= 0) {
                        if (!(TextUtils.isEmpty(recents[i3]) || recents[i3].equals(this.mTimeZoneData.mDefaultTimeZoneId))) {
                            int index = this.mTimeZoneData.findIndexByTimeZoneIdSlow(recents[i3]);
                            if (index != -1) {
                                iArr = this.mFilteredTimeZoneIndices;
                                i = this.mFilteredTimeZoneLength;
                                this.mFilteredTimeZoneLength = i + 1;
                                iArr[i] = index;
                            }
                        }
                        i3--;
                    }
                    break;
                }
                break;
            case C0678R.styleable.Switch_asb_track /*1*/:
                ArrayList<Integer> tzIds = (ArrayList) this.mTimeZoneData.mTimeZonesByCountry.get(str);
                if (tzIds != null) {
                    it = tzIds.iterator();
                    while (it.hasNext()) {
                        Integer tzi = (Integer) it.next();
                        iArr2 = this.mFilteredTimeZoneIndices;
                        i2 = this.mFilteredTimeZoneLength;
                        this.mFilteredTimeZoneLength = i2 + 1;
                        iArr2[i2] = tzi.intValue();
                    }
                    break;
                }
                break;
            case C0678R.styleable.Switch_asb_textOn /*2*/:
                break;
            case MAX_RECENT_TIMEZONES /*3*/:
                ArrayList<Integer> indices = this.mTimeZoneData.getTimeZonesByOffset(time);
                if (indices != null) {
                    it = indices.iterator();
                    while (it.hasNext()) {
                        Integer i4 = (Integer) it.next();
                        iArr2 = this.mFilteredTimeZoneIndices;
                        i2 = this.mFilteredTimeZoneLength;
                        this.mFilteredTimeZoneLength = i2 + 1;
                        iArr2[i2] = i4.intValue();
                    }
                    break;
                }
                break;
            default:
                throw new IllegalArgumentException();
        }
        this.mHasResults = this.mFilteredTimeZoneLength > 0 ? true : DEBUG;
        notifyDataSetChanged();
    }

    public void saveRecentTimezone(String id) {
        int i = 0;
        SharedPreferences prefs = this.mContext.getSharedPreferences(SHARED_PREFS_NAME, 0);
        String recentsString = prefs.getString(KEY_RECENT_TIMEZONES, null);
        if (recentsString == null) {
            recentsString = id;
        } else {
            LinkedHashSet<String> recents = new LinkedHashSet();
            String[] split = recentsString.split(RECENT_TIMEZONES_DELIMITER);
            int length = split.length;
            while (i < length) {
                String tzId = split[i];
                if (!(recents.contains(tzId) || id.equals(tzId))) {
                    recents.add(tzId);
                }
                i++;
            }
            Iterator<String> it = recents.iterator();
            while (recents.size() >= MAX_RECENT_TIMEZONES && it.hasNext()) {
                it.next();
                it.remove();
            }
            recents.add(id);
            StringBuilder builder = new StringBuilder();
            boolean first = true;
            Iterator it2 = recents.iterator();
            while (it2.hasNext()) {
                String recent = (String) it2.next();
                if (first) {
                    first = DEBUG;
                } else {
                    builder.append(RECENT_TIMEZONES_DELIMITER);
                }
                builder.append(recent);
            }
            recentsString = builder.toString();
        }
        prefs.edit().putString(KEY_RECENT_TIMEZONES, recentsString).apply();
    }

    public int getCount() {
        return this.mFilteredTimeZoneLength;
    }

    public Object getItem(int position) {
        if (position < 0 || position >= this.mFilteredTimeZoneLength) {
            return null;
        }
        return this.mTimeZoneData.get(this.mFilteredTimeZoneIndices[position]);
    }

    public boolean areAllItemsEnabled() {
        return DEBUG;
    }

    public boolean isEnabled(int position) {
        return this.mFilteredTimeZoneIndices[position] >= 0 ? true : DEBUG;
    }

    public long getItemId(int position) {
        return (long) this.mFilteredTimeZoneIndices[position];
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (this.mFilteredTimeZoneIndices[position] == EMPTY_INDEX) {
            v = this.mInflater.inflate(C0404R.layout.empty_time_zone_item, null);
            ((TextView) v.findViewById(C0404R.id.empty_item)).setTypeface(this.mSansSerifLightTypeface);
            return v;
        }
        if (v == null || v.findViewById(C0404R.id.empty_item) != null) {
            v = this.mInflater.inflate(C0404R.layout.time_zone_item, null);
            ViewHolder.setupViewHolder(v);
        }
        ViewHolder vh = (ViewHolder) v.getTag();
        TimeZoneInfo tzi = this.mTimeZoneData.get(this.mFilteredTimeZoneIndices[position]);
        v.setTag(VIEW_TAG_TIME_ZONE, tzi);
        vh.timeZone.setTypeface(this.mSansSerifLightTypeface);
        vh.timeOffset.setTypeface(this.mSansSerifLightTypeface);
        vh.location.setTypeface(this.mSansSerifLightTypeface);
        vh.timeZone.setText(tzi.mDisplayName);
        vh.timeOffset.setText(tzi.getGmtDisplayName(this.mContext));
        String location = tzi.mCountry;
        if (location == null) {
            vh.location.setVisibility(4);
        } else {
            vh.location.setText(location);
            vh.location.setVisibility(0);
        }
        return v;
    }

    public boolean hasStableIds() {
        return true;
    }

    public void onItemClick(AdapterView<?> adapterView, View v, int position, long id) {
        if (this.mTimeZoneSetListener != null) {
            TimeZoneInfo tzi = (TimeZoneInfo) v.getTag(VIEW_TAG_TIME_ZONE);
            if (tzi != null) {
                this.mTimeZoneSetListener.onTimeZoneSet(tzi);
                saveRecentTimezone(tzi.mTzId);
            }
        }
    }
}
