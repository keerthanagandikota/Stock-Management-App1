package com.doomonafireball.betterpickers.timezonepicker;

import android.content.Context;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.text.Spannable;
import android.text.Spannable.Factory;
import android.text.format.DateUtils;
import android.text.format.Time;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.util.SparseArray;
import com.doomonafireball.betterpickers.recurrencepicker.EventRecurrence;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Formatter;
import java.util.Locale;
import java.util.TimeZone;

public class TimeZoneInfo implements Comparable<TimeZoneInfo> {
    private static final int DST_SYMBOL_COLOR = -4210753;
    private static final int GMT_TEXT_COLOR = -7829368;
    public static int NUM_OF_TRANSITIONS = 0;
    private static final char SEPARATOR = ',';
    private static final String TAG;
    public static boolean is24HourFormat;
    private static Formatter mFormatter;
    private static SparseArray<CharSequence> mGmtDisplayNameCache;
    private static long mGmtDisplayNameUpdateTime;
    private static StringBuilder mSB;
    private static final Factory mSpannableFactory;
    public static long time;
    public int groupId;
    public String mCountry;
    public String mDisplayName;
    SparseArray<String> mLocalTimeCache;
    long mLocalTimeCacheReferenceTime;
    int mRawoffset;
    public int[] mTransitions;
    TimeZone mTz;
    public String mTzId;
    private Time recycledTime;

    static {
        TAG = null;
        NUM_OF_TRANSITIONS = 6;
        time = System.currentTimeMillis() / 1000;
        mSpannableFactory = Factory.getInstance();
        mSB = new StringBuilder(50);
        mFormatter = new Formatter(mSB, Locale.getDefault());
        mGmtDisplayNameCache = new SparseArray();
    }

    public TimeZoneInfo(TimeZone tz, String country) {
        this.recycledTime = new Time();
        this.mLocalTimeCache = new SparseArray();
        this.mLocalTimeCacheReferenceTime = 0;
        this.mTz = tz;
        this.mTzId = tz.getID();
        this.mCountry = country;
        this.mRawoffset = tz.getRawOffset();
        try {
            this.mTransitions = getTransitions(tz, time);
        } catch (NoSuchFieldException e) {
        } catch (IllegalAccessException ignored) {
            ignored.printStackTrace();
        }
    }

    public String getLocalTime(long referenceTime) {
        this.recycledTime.timezone = TimeZone.getDefault().getID();
        this.recycledTime.set(referenceTime);
        int currYearDay = (this.recycledTime.year * 366) + this.recycledTime.yearDay;
        this.recycledTime.timezone = this.mTzId;
        this.recycledTime.set(referenceTime);
        String localTimeStr = null;
        int hourMinute = (this.recycledTime.hour * 60) + this.recycledTime.minute;
        if (this.mLocalTimeCacheReferenceTime != referenceTime) {
            this.mLocalTimeCacheReferenceTime = referenceTime;
            this.mLocalTimeCache.clear();
        } else {
            localTimeStr = (String) this.mLocalTimeCache.get(hourMinute);
        }
        if (localTimeStr != null) {
            return localTimeStr;
        }
        String format = "%I:%M %p";
        if (currYearDay != (this.recycledTime.year * 366) + this.recycledTime.yearDay) {
            if (is24HourFormat) {
                format = "%b %d %H:%M";
            } else {
                format = "%b %d %I:%M %p";
            }
        } else if (is24HourFormat) {
            format = "%H:%M";
        }
        localTimeStr = this.recycledTime.format(format);
        this.mLocalTimeCache.put(hourMinute, localTimeStr);
        return localTimeStr;
    }

    public int getLocalHr(long referenceTime) {
        this.recycledTime.timezone = this.mTzId;
        this.recycledTime.set(referenceTime);
        return this.recycledTime.hour;
    }

    public int getNowOffsetMillis() {
        return this.mTz.getOffset(System.currentTimeMillis());
    }

    public synchronized CharSequence getGmtDisplayName(Context context) {
        CharSequence displayName;
        int cacheKey;
        long nowMinute = System.currentTimeMillis() / 60000;
        long now = nowMinute * 60000;
        int gmtOffset = this.mTz.getOffset(now);
        boolean hasFutureDST = this.mTz.useDaylightTime();
        if (hasFutureDST) {
            cacheKey = (int) (((long) gmtOffset) + 129600000);
        } else {
            cacheKey = (int) (((long) gmtOffset) - 129600000);
        }
        displayName = null;
        if (mGmtDisplayNameUpdateTime != nowMinute) {
            mGmtDisplayNameUpdateTime = nowMinute;
            mGmtDisplayNameCache.clear();
        } else {
            displayName = (CharSequence) mGmtDisplayNameCache.get(cacheKey);
        }
        if (displayName == null) {
            mSB.setLength(0);
            int flags = EventRecurrence.WE | 1;
            if (is24HourFormat) {
                flags |= AccessibilityNodeInfoCompat.ACTION_CLEAR_ACCESSIBILITY_FOCUS;
            }
            DateUtils.formatDateRange(context, mFormatter, now, now, flags, this.mTzId);
            mSB.append("  ");
            int gmtStart = mSB.length();
            TimeZonePickerUtils.appendGmtOffset(mSB, gmtOffset);
            int gmtEnd = mSB.length();
            int symbolStart = 0;
            int symbolEnd = 0;
            if (hasFutureDST) {
                mSB.append(' ');
                symbolStart = mSB.length();
                mSB.append(TimeZonePickerUtils.getDstSymbol());
                symbolEnd = mSB.length();
            }
            Spannable spannableText = mSpannableFactory.newSpannable(mSB);
            spannableText.setSpan(new ForegroundColorSpan(GMT_TEXT_COLOR), gmtStart, gmtEnd, 33);
            if (hasFutureDST) {
                spannableText.setSpan(new ForegroundColorSpan(DST_SYMBOL_COLOR), symbolStart, symbolEnd, 33);
            }
            displayName = spannableText;
            mGmtDisplayNameCache.put(cacheKey, displayName);
        }
        return displayName;
    }

    private static int[] getTransitions(TimeZone tz, long time) throws IllegalAccessException, NoSuchFieldException {
        Field mTransitionsField = tz.getClass().getDeclaredField("mTransitions");
        mTransitionsField.setAccessible(true);
        int[] objTransitions = (int[]) mTransitionsField.get(tz);
        int[] transitions = null;
        if (objTransitions.length != 0) {
            transitions = new int[NUM_OF_TRANSITIONS];
            int numOfTransitions = 0;
            for (int i = 0; i < objTransitions.length; i++) {
                if (((long) objTransitions[i]) >= time) {
                    int numOfTransitions2 = numOfTransitions + 1;
                    transitions[numOfTransitions] = objTransitions[i];
                    if (numOfTransitions2 == NUM_OF_TRANSITIONS) {
                        break;
                    }
                    numOfTransitions = numOfTransitions2;
                }
            }
        }
        return transitions;
    }

    public boolean hasSameRules(TimeZoneInfo tzi) {
        return this.mRawoffset == tzi.mRawoffset && Arrays.equals(this.mTransitions, tzi.mTransitions);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        String country = this.mCountry;
        TimeZone tz = this.mTz;
        sb.append(this.mTzId);
        sb.append(SEPARATOR);
        sb.append(tz.getDisplayName(false, 1));
        sb.append(SEPARATOR);
        sb.append(tz.getDisplayName(false, 0));
        sb.append(SEPARATOR);
        if (tz.useDaylightTime()) {
            sb.append(tz.getDisplayName(true, 1));
            sb.append(SEPARATOR);
            sb.append(tz.getDisplayName(true, 0));
        } else {
            sb.append(SEPARATOR);
        }
        sb.append(SEPARATOR);
        sb.append(((float) tz.getRawOffset()) / 3600000.0f);
        sb.append(SEPARATOR);
        sb.append(((float) tz.getDSTSavings()) / 3600000.0f);
        sb.append(SEPARATOR);
        sb.append(country);
        sb.append(SEPARATOR);
        sb.append(getLocalTime(1357041600000L));
        sb.append(SEPARATOR);
        sb.append(getLocalTime(1363348800000L));
        sb.append(SEPARATOR);
        sb.append(getLocalTime(1372680000000L));
        sb.append(SEPARATOR);
        sb.append(getLocalTime(1383307200000L));
        sb.append(SEPARATOR);
        sb.append('\n');
        return sb.toString();
    }

    private static String formatTime(DateFormat df, int s) {
        return df.format(new Date(((long) s) * 1000));
    }

    public int compareTo(TimeZoneInfo other) {
        if (getNowOffsetMillis() != other.getNowOffsetMillis()) {
            if (other.getNowOffsetMillis() < getNowOffsetMillis()) {
                return -1;
            }
            return 1;
        } else if (this.mCountry == null && other.mCountry != null) {
            return 1;
        } else {
            if (other.mCountry == null) {
                return -1;
            }
            int diff = this.mCountry.compareTo(other.mCountry);
            if (diff != 0) {
                return diff;
            }
            if (Arrays.equals(this.mTransitions, other.mTransitions)) {
                Log.e(TAG, "Not expected to be comparing tz with the same country, same offset, same dst, same transitions:\n" + toString() + "\n" + other.toString());
            }
            if (this.mDisplayName == null || other.mDisplayName == null) {
                return this.mTz.getDisplayName(Locale.getDefault()).compareTo(other.mTz.getDisplayName(Locale.getDefault()));
            }
            return this.mDisplayName.compareTo(other.mDisplayName);
        }
    }
}
