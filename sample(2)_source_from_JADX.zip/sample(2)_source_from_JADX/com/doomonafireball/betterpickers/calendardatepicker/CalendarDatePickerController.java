package com.doomonafireball.betterpickers.calendardatepicker;

import com.doomonafireball.betterpickers.calendardatepicker.CalendarDatePickerDialog.OnDateChangedListener;
import com.doomonafireball.betterpickers.calendardatepicker.MonthAdapter.CalendarDay;

interface CalendarDatePickerController {
    int getFirstDayOfWeek();

    int getMaxYear();

    int getMinYear();

    CalendarDay getSelectedDay();

    void onDayOfMonthSelected(int i, int i2, int i3);

    void onYearSelected(int i);

    void registerOnDateChangedListener(OnDateChangedListener onDateChangedListener);

    void tryVibrate();

    void unregisterOnDateChangedListener(OnDateChangedListener onDateChangedListener);
}
