package com.doomonafireball.betterpickers.calendardatepicker;

import android.content.Context;
import android.util.AttributeSet;

public class SimpleDayPickerView extends DayPickerView {
    public SimpleDayPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public SimpleDayPickerView(Context context, CalendarDatePickerController controller) {
        super(context, controller);
    }

    public MonthAdapter createMonthAdapter(Context context, CalendarDatePickerController controller) {
        return new SimpleMonthAdapter(context, controller);
    }
}
