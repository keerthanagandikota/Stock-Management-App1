package com.doomonafireball.betterpickers.timepicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.widget.ZeroTopPaddingTextView;

public class TimerView extends LinearLayout {
    private final Typeface mAndroidClockMonoThin;
    private ZeroTopPaddingTextView mHoursOnes;
    private ZeroTopPaddingTextView mHoursSeperator;
    private ZeroTopPaddingTextView mHoursTens;
    private ZeroTopPaddingTextView mMinutesOnes;
    private ZeroTopPaddingTextView mMinutesTens;
    private Typeface mOriginalHoursTypeface;
    private ColorStateList mTextColor;

    public TimerView(Context context) {
        this(context, null);
    }

    public TimerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mAndroidClockMonoThin = Typeface.createFromAsset(context.getAssets(), "fonts/AndroidClockMono-Thin.ttf");
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
    }

    public void setTheme(int themeResId) {
        if (themeResId != -1) {
            this.mTextColor = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment).getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
        }
        restyleViews();
    }

    private void restyleViews() {
        if (this.mHoursOnes != null) {
            this.mHoursOnes.setTextColor(this.mTextColor);
        }
        if (this.mMinutesOnes != null) {
            this.mMinutesOnes.setTextColor(this.mTextColor);
        }
        if (this.mHoursTens != null) {
            this.mHoursTens.setTextColor(this.mTextColor);
        }
        if (this.mMinutesTens != null) {
            this.mMinutesTens.setTextColor(this.mTextColor);
        }
        if (this.mHoursSeperator != null) {
            this.mHoursSeperator.setTextColor(this.mTextColor);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mHoursTens = (ZeroTopPaddingTextView) findViewById(C0404R.id.hours_tens);
        this.mMinutesTens = (ZeroTopPaddingTextView) findViewById(C0404R.id.minutes_tens);
        this.mHoursOnes = (ZeroTopPaddingTextView) findViewById(C0404R.id.hours_ones);
        this.mMinutesOnes = (ZeroTopPaddingTextView) findViewById(C0404R.id.minutes_ones);
        this.mHoursSeperator = (ZeroTopPaddingTextView) findViewById(C0404R.id.hours_seperator);
        if (this.mHoursOnes != null) {
            this.mOriginalHoursTypeface = this.mHoursOnes.getTypeface();
        }
        if (this.mMinutesTens != null) {
            this.mMinutesTens.setTypeface(this.mAndroidClockMonoThin);
            this.mMinutesTens.updatePadding();
        }
        if (this.mMinutesOnes != null) {
            this.mMinutesOnes.setTypeface(this.mAndroidClockMonoThin);
            this.mMinutesOnes.updatePadding();
        }
    }

    public void setTime(int hoursTensDigit, int hoursOnesDigit, int minutesTensDigit, int minutesOnesDigit) {
        if (this.mHoursTens != null) {
            if (hoursTensDigit == -2) {
                this.mHoursTens.setVisibility(4);
            } else if (hoursTensDigit == -1) {
                this.mHoursTens.setText("-");
                this.mHoursTens.setTypeface(this.mAndroidClockMonoThin);
                this.mHoursTens.setEnabled(false);
                this.mHoursTens.updatePadding();
                this.mHoursTens.setVisibility(0);
            } else {
                this.mHoursTens.setText(String.format("%d", new Object[]{Integer.valueOf(hoursTensDigit)}));
                this.mHoursTens.setTypeface(this.mOriginalHoursTypeface);
                this.mHoursTens.setEnabled(true);
                this.mHoursTens.updatePaddingForBoldDate();
                this.mHoursTens.setVisibility(0);
            }
        }
        if (this.mHoursOnes != null) {
            if (hoursOnesDigit == -1) {
                this.mHoursOnes.setText("-");
                this.mHoursOnes.setTypeface(this.mAndroidClockMonoThin);
                this.mHoursOnes.setEnabled(false);
                this.mHoursOnes.updatePadding();
            } else {
                this.mHoursOnes.setText(String.format("%d", new Object[]{Integer.valueOf(hoursOnesDigit)}));
                this.mHoursOnes.setTypeface(this.mOriginalHoursTypeface);
                this.mHoursOnes.setEnabled(true);
                this.mHoursOnes.updatePaddingForBoldDate();
            }
        }
        if (this.mMinutesTens != null) {
            if (minutesTensDigit == -1) {
                this.mMinutesTens.setText("-");
                this.mMinutesTens.setEnabled(false);
            } else {
                this.mMinutesTens.setEnabled(true);
                this.mMinutesTens.setText(String.format("%d", new Object[]{Integer.valueOf(minutesTensDigit)}));
            }
        }
        if (this.mMinutesOnes == null) {
            return;
        }
        if (minutesOnesDigit == -1) {
            this.mMinutesOnes.setText("-");
            this.mMinutesOnes.setEnabled(false);
            return;
        }
        this.mMinutesOnes.setText(String.format("%d", new Object[]{Integer.valueOf(minutesOnesDigit)}));
        this.mMinutesOnes.setEnabled(true);
    }
}
