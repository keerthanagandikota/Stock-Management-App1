package com.doomonafireball.betterpickers.timepicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.media.TransportMediator;
import android.support.v7.widget.helper.ItemTouchHelper.Callback;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;
import io.buildup.pkg20170504080645.C0585R;
import java.text.DateFormatSymbols;

public class TimePicker extends LinearLayout implements OnClickListener, OnLongClickListener {
    private static final int AMPM_NOT_SELECTED = 0;
    private static final int AM_SELECTED = 2;
    private static final int HOURS24_MODE = 3;
    private static final int PM_SELECTED = 1;
    private static final String TIME_PICKER_SAVED_AMPM = "timer_picker_saved_ampm";
    private static final String TIME_PICKER_SAVED_BUFFER_POINTER = "timer_picker_saved_buffer_pointer";
    private static final String TIME_PICKER_SAVED_INPUT = "timer_picker_saved_input";
    private TextView mAmPmLabel;
    private int mAmPmState;
    private String[] mAmpm;
    private int mButtonBackgroundResId;
    protected final Context mContext;
    protected ImageButton mDelete;
    private int mDeleteDrawableSrcResId;
    protected View mDivider;
    private int mDividerColor;
    protected TimerView mEnteredTime;
    protected int[] mInput;
    protected int mInputPointer;
    protected int mInputSize;
    private boolean mIs24HoursMode;
    private int mKeyBackgroundResId;
    protected Button mLeft;
    private final String mNoAmPmLabel;
    protected final Button[] mNumbers;
    protected Button mRight;
    private Button mSetButton;
    private ColorStateList mTextColor;
    private int mTheme;

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR;
        int mAmPmState;
        int[] mInput;
        int mInputPointer;

        /* renamed from: com.doomonafireball.betterpickers.timepicker.TimePicker.SavedState.1 */
        static class C04421 implements Creator<SavedState> {
            C04421() {
            }

            public SavedState createFromParcel(Parcel in) {
                return new SavedState(null);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.mInputPointer = in.readInt();
            in.readIntArray(this.mInput);
            this.mAmPmState = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.mInputPointer);
            dest.writeIntArray(this.mInput);
            dest.writeInt(this.mAmPmState);
        }

        static {
            CREATOR = new C04421();
        }
    }

    public TimePicker(Context context) {
        this(context, null);
    }

    public TimePicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mInputSize = 4;
        this.mNumbers = new Button[10];
        this.mInput = new int[this.mInputSize];
        this.mInputPointer = -1;
        this.mIs24HoursMode = false;
        this.mTheme = -1;
        this.mContext = context;
        this.mIs24HoursMode = get24HourMode(this.mContext);
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(getLayoutId(), this);
        this.mNoAmPmLabel = context.getResources().getString(C0404R.string.time_picker_ampm_label);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mKeyBackgroundResId = C0404R.drawable.key_background_dark;
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
        this.mDeleteDrawableSrcResId = C0404R.drawable.ic_backspace_dark;
    }

    protected int getLayoutId() {
        return C0404R.layout.time_picker_view;
    }

    public void setTheme(int themeResId) {
        this.mTheme = themeResId;
        if (this.mTheme != -1) {
            TypedArray a = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mKeyBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpKeyBackground, this.mKeyBackgroundResId);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpDividerColor, this.mDividerColor);
            this.mDeleteDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDeleteIcon, this.mDeleteDrawableSrcResId);
        }
        restyleViews();
    }

    private void restyleViews() {
        Button[] buttonArr = this.mNumbers;
        int length = buttonArr.length;
        for (int i = AMPM_NOT_SELECTED; i < length; i += PM_SELECTED) {
            Button number = buttonArr[i];
            if (number != null) {
                number.setTextColor(this.mTextColor);
                number.setBackgroundResource(this.mKeyBackgroundResId);
            }
        }
        if (this.mDivider != null) {
            this.mDivider.setBackgroundColor(this.mDividerColor);
        }
        if (this.mLeft != null) {
            this.mLeft.setTextColor(this.mTextColor);
            this.mLeft.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mAmPmLabel != null) {
            this.mAmPmLabel.setTextColor(this.mTextColor);
            this.mAmPmLabel.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mRight != null) {
            this.mRight.setTextColor(this.mTextColor);
            this.mRight.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mDelete != null) {
            this.mDelete.setBackgroundResource(this.mButtonBackgroundResId);
            this.mDelete.setImageDrawable(getResources().getDrawable(this.mDeleteDrawableSrcResId));
        }
        if (this.mEnteredTime != null) {
            this.mEnteredTime.setTheme(this.mTheme);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        View v1 = findViewById(C0404R.id.first);
        View v2 = findViewById(C0404R.id.second);
        View v3 = findViewById(C0404R.id.third);
        View v4 = findViewById(C0404R.id.fourth);
        this.mEnteredTime = (TimerView) findViewById(C0404R.id.timer_time_text);
        this.mDelete = (ImageButton) findViewById(C0404R.id.delete);
        this.mDelete.setOnClickListener(this);
        this.mDelete.setOnLongClickListener(this);
        this.mNumbers[PM_SELECTED] = (Button) v1.findViewById(C0404R.id.key_left);
        this.mNumbers[AM_SELECTED] = (Button) v1.findViewById(C0404R.id.key_middle);
        this.mNumbers[HOURS24_MODE] = (Button) v1.findViewById(C0404R.id.key_right);
        this.mNumbers[4] = (Button) v2.findViewById(C0404R.id.key_left);
        this.mNumbers[5] = (Button) v2.findViewById(C0404R.id.key_middle);
        this.mNumbers[6] = (Button) v2.findViewById(C0404R.id.key_right);
        this.mNumbers[7] = (Button) v3.findViewById(C0404R.id.key_left);
        this.mNumbers[8] = (Button) v3.findViewById(C0404R.id.key_middle);
        this.mNumbers[9] = (Button) v3.findViewById(C0404R.id.key_right);
        this.mLeft = (Button) v4.findViewById(C0404R.id.key_left);
        this.mNumbers[AMPM_NOT_SELECTED] = (Button) v4.findViewById(C0404R.id.key_middle);
        this.mRight = (Button) v4.findViewById(C0404R.id.key_right);
        setLeftRightEnabled(false);
        for (int i = AMPM_NOT_SELECTED; i < 10; i += PM_SELECTED) {
            this.mNumbers[i].setOnClickListener(this);
            Button button = this.mNumbers[i];
            Object[] objArr = new Object[PM_SELECTED];
            objArr[AMPM_NOT_SELECTED] = Integer.valueOf(i);
            button.setText(String.format("%d", objArr));
            this.mNumbers[i].setTag(C0404R.id.numbers_key, new Integer(i));
        }
        updateTime();
        Resources res = this.mContext.getResources();
        this.mAmpm = new DateFormatSymbols().getAmPmStrings();
        if (this.mIs24HoursMode) {
            this.mLeft.setText(res.getString(C0404R.string.time_picker_00_label));
            this.mRight.setText(res.getString(C0404R.string.time_picker_30_label));
        } else {
            this.mLeft.setText(this.mAmpm[AMPM_NOT_SELECTED]);
            this.mRight.setText(this.mAmpm[PM_SELECTED]);
        }
        this.mLeft.setOnClickListener(this);
        this.mRight.setOnClickListener(this);
        this.mAmPmLabel = (TextView) findViewById(C0404R.id.ampm_label);
        this.mAmPmState = AMPM_NOT_SELECTED;
        this.mDivider = findViewById(C0404R.id.divider);
        restyleViews();
        updateKeypad();
    }

    public void updateDeleteButton() {
        boolean enabled = this.mInputPointer != -1;
        if (this.mDelete != null) {
            this.mDelete.setEnabled(enabled);
        }
    }

    public void onClick(View v) {
        v.performHapticFeedback(PM_SELECTED);
        doOnClick(v);
        updateDeleteButton();
    }

    protected void doOnClick(View v) {
        Integer val = (Integer) v.getTag(C0404R.id.numbers_key);
        if (val != null) {
            addClickedNumber(val.intValue());
        } else if (v == this.mDelete) {
            if (!this.mIs24HoursMode && this.mAmPmState != 0) {
                this.mAmPmState = AMPM_NOT_SELECTED;
            } else if (this.mInputPointer >= 0) {
                for (int i = AMPM_NOT_SELECTED; i < this.mInputPointer; i += PM_SELECTED) {
                    this.mInput[i] = this.mInput[i + PM_SELECTED];
                }
                this.mInput[this.mInputPointer] = AMPM_NOT_SELECTED;
                this.mInputPointer--;
            }
        } else if (v == this.mLeft) {
            onLeftClicked();
        } else if (v == this.mRight) {
            onRightClicked();
        }
        updateKeypad();
    }

    public boolean onLongClick(View v) {
        v.performHapticFeedback(AMPM_NOT_SELECTED);
        if (v != this.mDelete) {
            return false;
        }
        this.mDelete.setPressed(false);
        this.mAmPmState = AMPM_NOT_SELECTED;
        reset();
        updateKeypad();
        return true;
    }

    public void reset() {
        for (int i = AMPM_NOT_SELECTED; i < this.mInputSize; i += PM_SELECTED) {
            this.mInput[i] = AMPM_NOT_SELECTED;
        }
        this.mInputPointer = -1;
        updateTime();
    }

    private void updateKeypad() {
        showAmPm();
        updateLeftRightButtons();
        updateTime();
        updateNumericKeys();
        enableSetButton();
        updateDeleteButton();
    }

    protected void updateTime() {
        int hours1 = -1;
        int time = getEnteredTime();
        if (this.mInputPointer > -1) {
            if (this.mInputPointer >= 0) {
                int digit = this.mInput[this.mInputPointer];
                if ((this.mIs24HoursMode && digit >= HOURS24_MODE && digit <= 9) || (!this.mIs24HoursMode && digit >= AM_SELECTED && digit <= 9)) {
                    hours1 = -2;
                }
            }
            if (this.mInputPointer > 0 && this.mInputPointer < HOURS24_MODE && hours1 != -2) {
                int digits = (this.mInput[this.mInputPointer] * 10) + this.mInput[this.mInputPointer - 1];
                if ((this.mIs24HoursMode && digits >= 24 && digits <= 25) || (!this.mIs24HoursMode && digits >= 13 && digits <= 15)) {
                    hours1 = -2;
                }
            }
            if (this.mInputPointer == HOURS24_MODE) {
                hours1 = this.mInput[HOURS24_MODE];
            }
        } else {
            hours1 = -1;
        }
        this.mEnteredTime.setTime(hours1, this.mInputPointer < AM_SELECTED ? -1 : this.mInput[AM_SELECTED], this.mInputPointer < PM_SELECTED ? -1 : this.mInput[PM_SELECTED], this.mInputPointer < 0 ? -1 : this.mInput[AMPM_NOT_SELECTED]);
    }

    private void showAmPm() {
        if (this.mIs24HoursMode) {
            this.mAmPmLabel.setVisibility(4);
            this.mAmPmState = HOURS24_MODE;
            return;
        }
        switch (this.mAmPmState) {
            case AMPM_NOT_SELECTED /*0*/:
                this.mAmPmLabel.setText(this.mNoAmPmLabel);
            case PM_SELECTED /*1*/:
                this.mAmPmLabel.setText(this.mAmpm[PM_SELECTED]);
            case AM_SELECTED /*2*/:
                this.mAmPmLabel.setText(this.mAmpm[AMPM_NOT_SELECTED]);
            default:
        }
    }

    private void addClickedNumber(int val) {
        if (this.mInputPointer < this.mInputSize - 1) {
            for (int i = this.mInputPointer; i >= 0; i--) {
                this.mInput[i + PM_SELECTED] = this.mInput[i];
            }
            this.mInputPointer += PM_SELECTED;
            this.mInput[AMPM_NOT_SELECTED] = val;
        }
    }

    private void onLeftClicked() {
        int time = getEnteredTime();
        if (!this.mIs24HoursMode) {
            if (canAddDigits()) {
                addClickedNumber(AMPM_NOT_SELECTED);
                addClickedNumber(AMPM_NOT_SELECTED);
            }
            this.mAmPmState = AM_SELECTED;
        } else if (canAddDigits()) {
            addClickedNumber(AMPM_NOT_SELECTED);
            addClickedNumber(AMPM_NOT_SELECTED);
        }
    }

    private void onRightClicked() {
        int time = getEnteredTime();
        if (!this.mIs24HoursMode) {
            if (canAddDigits()) {
                addClickedNumber(AMPM_NOT_SELECTED);
                addClickedNumber(AMPM_NOT_SELECTED);
            }
            this.mAmPmState = PM_SELECTED;
        } else if (canAddDigits()) {
            addClickedNumber(HOURS24_MODE);
            addClickedNumber(AMPM_NOT_SELECTED);
        }
    }

    private boolean canAddDigits() {
        int time = getEnteredTime();
        if (this.mIs24HoursMode) {
            if (time < 0 || time > 23 || this.mInputPointer <= -1 || this.mInputPointer >= AM_SELECTED) {
                return false;
            }
            return true;
        } else if (time < PM_SELECTED || time > 12) {
            return false;
        } else {
            return true;
        }
    }

    private void updateNumericKeys() {
        int time = getEnteredTime();
        if (this.mIs24HoursMode) {
            if (this.mInputPointer >= HOURS24_MODE) {
                setKeyRange(-1);
            } else if (time == 0) {
                if (this.mInputPointer == -1 || this.mInputPointer == 0 || this.mInputPointer == AM_SELECTED) {
                    setKeyRange(9);
                } else if (this.mInputPointer == PM_SELECTED) {
                    setKeyRange(5);
                } else {
                    setKeyRange(-1);
                }
            } else if (time == PM_SELECTED) {
                if (this.mInputPointer == 0 || this.mInputPointer == AM_SELECTED) {
                    setKeyRange(9);
                } else if (this.mInputPointer == PM_SELECTED) {
                    setKeyRange(5);
                } else {
                    setKeyRange(-1);
                }
            } else if (time == AM_SELECTED) {
                if (this.mInputPointer == AM_SELECTED || this.mInputPointer == PM_SELECTED) {
                    setKeyRange(9);
                } else if (this.mInputPointer == 0) {
                    setKeyRange(HOURS24_MODE);
                } else {
                    setKeyRange(-1);
                }
            } else if (time <= 5) {
                setKeyRange(9);
            } else if (time <= 9) {
                setKeyRange(5);
            } else if (time >= 10 && time <= 15) {
                setKeyRange(9);
            } else if (time >= 16 && time <= 19) {
                setKeyRange(5);
            } else if (time >= 20 && time <= 25) {
                setKeyRange(9);
            } else if (time >= 26 && time <= 29) {
                setKeyRange(-1);
            } else if (time >= 30 && time <= 35) {
                setKeyRange(9);
            } else if (time >= 36 && time <= 39) {
                setKeyRange(-1);
            } else if (time >= 40 && time <= 45) {
                setKeyRange(9);
            } else if (time >= 46 && time <= 49) {
                setKeyRange(-1);
            } else if (time >= 50 && time <= 55) {
                setKeyRange(9);
            } else if (time >= 56 && time <= 59) {
                setKeyRange(-1);
            } else if (time >= 60 && time <= 65) {
                setKeyRange(9);
            } else if (time >= 70 && time <= 75) {
                setKeyRange(9);
            } else if (time >= 80 && time <= 85) {
                setKeyRange(9);
            } else if (time >= 90 && time <= 95) {
                setKeyRange(9);
            } else if (time >= 100 && time <= C0585R.styleable.Theme_radioButtonStyle) {
                setKeyRange(9);
            } else if (time >= C0585R.styleable.Theme_ratingBarStyle && time <= C0585R.styleable.Theme_switchStyle) {
                setKeyRange(-1);
            } else if (time >= 110 && time <= 115) {
                setKeyRange(9);
            } else if (time >= 116 && time <= 119) {
                setKeyRange(-1);
            } else if (time >= 120 && time <= 125) {
                setKeyRange(9);
            } else if (time >= TransportMediator.KEYCODE_MEDIA_PLAY && time <= 129) {
                setKeyRange(-1);
            } else if (time >= TransportMediator.KEYCODE_MEDIA_RECORD && time <= 135) {
                setKeyRange(9);
            } else if (time >= 136 && time <= 139) {
                setKeyRange(-1);
            } else if (time >= 140 && time <= 145) {
                setKeyRange(9);
            } else if (time >= 146 && time <= 149) {
                setKeyRange(-1);
            } else if (time >= 150 && time <= 155) {
                setKeyRange(9);
            } else if (time >= 156 && time <= 159) {
                setKeyRange(-1);
            } else if (time >= 160 && time <= 165) {
                setKeyRange(9);
            } else if (time >= 166 && time <= 169) {
                setKeyRange(-1);
            } else if (time >= 170 && time <= 175) {
                setKeyRange(9);
            } else if (time >= 176 && time <= 179) {
                setKeyRange(-1);
            } else if (time >= 180 && time <= 185) {
                setKeyRange(9);
            } else if (time >= 186 && time <= 189) {
                setKeyRange(-1);
            } else if (time >= 190 && time <= 195) {
                setKeyRange(9);
            } else if (time >= 196 && time <= 199) {
                setKeyRange(-1);
            } else if (time >= Callback.DEFAULT_DRAG_ANIMATION_DURATION && time <= 205) {
                setKeyRange(9);
            } else if (time >= 206 && time <= 209) {
                setKeyRange(-1);
            } else if (time >= 210 && time <= 215) {
                setKeyRange(9);
            } else if (time >= 216 && time <= 219) {
                setKeyRange(-1);
            } else if (time >= 220 && time <= 225) {
                setKeyRange(9);
            } else if (time >= 226 && time <= 229) {
                setKeyRange(-1);
            } else if (time >= 230 && time <= 235) {
                setKeyRange(9);
            } else if (time >= 236) {
                setKeyRange(-1);
            }
        } else if (this.mAmPmState != 0) {
            setKeyRange(-1);
        } else if (time == 0) {
            setKeyRange(9);
            this.mNumbers[AMPM_NOT_SELECTED].setEnabled(false);
        } else if (time <= 9) {
            setKeyRange(5);
        } else if (time <= 95) {
            setKeyRange(9);
        } else if (time >= 100 && time <= C0585R.styleable.Theme_radioButtonStyle) {
            setKeyRange(9);
        } else if (time >= C0585R.styleable.Theme_ratingBarStyle && time <= C0585R.styleable.Theme_switchStyle) {
            setKeyRange(-1);
        } else if (time >= 110 && time <= 115) {
            setKeyRange(9);
        } else if (time >= 116 && time <= 119) {
            setKeyRange(-1);
        } else if (time >= 120 && time <= 125) {
            setKeyRange(9);
        } else if (time >= TransportMediator.KEYCODE_MEDIA_PLAY) {
            setKeyRange(-1);
        }
    }

    private int getEnteredTime() {
        return (((this.mInput[HOURS24_MODE] * 1000) + (this.mInput[AM_SELECTED] * 100)) + (this.mInput[PM_SELECTED] * 10)) + this.mInput[AMPM_NOT_SELECTED];
    }

    private void setKeyRange(int maxKey) {
        int i = AMPM_NOT_SELECTED;
        while (i < this.mNumbers.length) {
            this.mNumbers[i].setEnabled(i <= maxKey);
            i += PM_SELECTED;
        }
    }

    private void updateLeftRightButtons() {
        int time = getEnteredTime();
        if (this.mIs24HoursMode) {
            boolean enable = canAddDigits();
            this.mLeft.setEnabled(enable);
            this.mRight.setEnabled(enable);
        } else if ((time <= 12 || time >= 100) && time != 0 && this.mAmPmState == 0) {
            this.mLeft.setEnabled(true);
            this.mRight.setEnabled(true);
        } else {
            this.mLeft.setEnabled(false);
            this.mRight.setEnabled(false);
        }
    }

    private void enableSetButton() {
        boolean z = true;
        if (this.mSetButton != null) {
            if (this.mInputPointer == -1) {
                this.mSetButton.setEnabled(false);
            } else if (this.mIs24HoursMode) {
                int time = getEnteredTime();
                r3 = this.mSetButton;
                if (this.mInputPointer < AM_SELECTED || (time >= 60 && time <= 95)) {
                    z = false;
                }
                r3.setEnabled(z);
            } else {
                r3 = this.mSetButton;
                if (this.mAmPmState == 0) {
                    z = false;
                }
                r3.setEnabled(z);
            }
        }
    }

    public void setSetButton(Button b) {
        this.mSetButton = b;
        enableSetButton();
    }

    public int getHours() {
        int i = 12;
        int hours = (this.mInput[HOURS24_MODE] * 10) + this.mInput[AM_SELECTED];
        if (hours == 12) {
            switch (this.mAmPmState) {
                case PM_SELECTED /*1*/:
                    return 12;
                case AM_SELECTED /*2*/:
                    return AMPM_NOT_SELECTED;
                case HOURS24_MODE /*3*/:
                    return hours;
            }
        }
        if (this.mAmPmState != PM_SELECTED) {
            i = AMPM_NOT_SELECTED;
        }
        return i + hours;
    }

    public int getMinutes() {
        return (this.mInput[PM_SELECTED] * 10) + this.mInput[AMPM_NOT_SELECTED];
    }

    public Parcelable onSaveInstanceState() {
        SavedState state = new SavedState(super.onSaveInstanceState());
        state.mInput = this.mInput;
        state.mAmPmState = this.mAmPmState;
        state.mInputPointer = this.mInputPointer;
        return state;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState savedState = (SavedState) state;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mInputPointer = savedState.mInputPointer;
            this.mInput = savedState.mInput;
            if (this.mInput == null) {
                this.mInput = new int[this.mInputSize];
                this.mInputPointer = -1;
            }
            this.mAmPmState = savedState.mAmPmState;
            updateKeypad();
            return;
        }
        super.onRestoreInstanceState(state);
    }

    public static boolean get24HourMode(Context context) {
        return DateFormat.is24HourFormat(context);
    }

    public int getTime() {
        return ((((this.mInput[4] * 3600) + (this.mInput[HOURS24_MODE] * 600)) + (this.mInput[AM_SELECTED] * 60)) + (this.mInput[PM_SELECTED] * 10)) + this.mInput[AMPM_NOT_SELECTED];
    }

    public void saveEntryState(Bundle outState, String key) {
        outState.putIntArray(key, this.mInput);
    }

    public void restoreEntryState(Bundle inState, String key) {
        int[] input = inState.getIntArray(key);
        if (input != null && this.mInputSize == input.length) {
            for (int i = AMPM_NOT_SELECTED; i < this.mInputSize; i += PM_SELECTED) {
                this.mInput[i] = input[i];
                if (this.mInput[i] != 0) {
                    this.mInputPointer = i;
                }
            }
            updateTime();
        }
    }

    protected void setLeftRightEnabled(boolean enabled) {
        this.mLeft.setEnabled(enabled);
        this.mRight.setEnabled(enabled);
        if (!enabled) {
            this.mLeft.setContentDescription(null);
            this.mRight.setContentDescription(null);
        }
    }
}
