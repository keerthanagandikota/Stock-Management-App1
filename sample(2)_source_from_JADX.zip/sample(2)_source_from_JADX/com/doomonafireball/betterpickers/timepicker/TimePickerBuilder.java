package com.doomonafireball.betterpickers.timepicker;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import com.doomonafireball.betterpickers.timepicker.TimePickerDialogFragment.TimePickerDialogHandler;
import java.util.Vector;

public class TimePickerBuilder {
    private int mReference;
    private Vector<TimePickerDialogHandler> mTimePickerDialogHandlers;
    private FragmentManager manager;
    private Integer styleResId;
    private Fragment targetFragment;

    public TimePickerBuilder() {
        this.mReference = -1;
        this.mTimePickerDialogHandlers = new Vector();
    }

    public TimePickerBuilder setFragmentManager(FragmentManager manager) {
        this.manager = manager;
        return this;
    }

    public TimePickerBuilder setStyleResId(int styleResId) {
        this.styleResId = Integer.valueOf(styleResId);
        return this;
    }

    public TimePickerBuilder setTargetFragment(Fragment targetFragment) {
        this.targetFragment = targetFragment;
        return this;
    }

    public TimePickerBuilder setReference(int reference) {
        this.mReference = reference;
        return this;
    }

    public TimePickerBuilder addTimePickerDialogHandler(TimePickerDialogHandler handler) {
        this.mTimePickerDialogHandlers.add(handler);
        return this;
    }

    public TimePickerBuilder removeTimePickerDialogHandler(TimePickerDialogHandler handler) {
        this.mTimePickerDialogHandlers.remove(handler);
        return this;
    }

    public void show() {
        if (this.manager == null || this.styleResId == null) {
            Log.e("TimePickerBuilder", "setFragmentManager() and setStyleResId() must be called.");
            return;
        }
        FragmentTransaction ft = this.manager.beginTransaction();
        Fragment prev = this.manager.findFragmentByTag("time_dialog");
        if (prev != null) {
            ft.remove(prev);
        }
        ft.addToBackStack(null);
        TimePickerDialogFragment fragment = TimePickerDialogFragment.newInstance(this.mReference, this.styleResId.intValue());
        if (this.targetFragment != null) {
            fragment.setTargetFragment(this.targetFragment, 0);
        }
        fragment.setTimePickerDialogHandlers(this.mTimePickerDialogHandlers);
        fragment.show(ft, "time_dialog");
    }
}
