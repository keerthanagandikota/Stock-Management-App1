package com.doomonafireball.betterpickers.numberpicker;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class NumberPickerErrorTextView extends TextView {
    private static final long LENGTH_SHORT = 3000;
    private Handler fadeInEndHandler;
    private Runnable hideRunnable;

    /* renamed from: com.doomonafireball.betterpickers.numberpicker.NumberPickerErrorTextView.1 */
    class C04251 implements AnimationListener {
        C04251() {
        }

        public void onAnimationStart(Animation animation) {
        }

        public void onAnimationEnd(Animation animation) {
            NumberPickerErrorTextView.this.fadeInEndHandler.postDelayed(NumberPickerErrorTextView.this.hideRunnable, NumberPickerErrorTextView.LENGTH_SHORT);
            NumberPickerErrorTextView.this.setVisibility(0);
        }

        public void onAnimationRepeat(Animation animation) {
        }
    }

    /* renamed from: com.doomonafireball.betterpickers.numberpicker.NumberPickerErrorTextView.2 */
    class C04262 implements Runnable {
        C04262() {
        }

        public void run() {
            NumberPickerErrorTextView.this.hide();
        }
    }

    /* renamed from: com.doomonafireball.betterpickers.numberpicker.NumberPickerErrorTextView.3 */
    class C04273 implements AnimationListener {
        C04273() {
        }

        public void onAnimationStart(Animation animation) {
        }

        public void onAnimationEnd(Animation animation) {
            NumberPickerErrorTextView.this.setVisibility(4);
        }

        public void onAnimationRepeat(Animation animation) {
        }
    }

    public NumberPickerErrorTextView(Context context) {
        super(context);
        this.hideRunnable = new C04262();
        this.fadeInEndHandler = new Handler();
    }

    public NumberPickerErrorTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.hideRunnable = new C04262();
        this.fadeInEndHandler = new Handler();
    }

    public NumberPickerErrorTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.hideRunnable = new C04262();
        this.fadeInEndHandler = new Handler();
    }

    public void show() {
        this.fadeInEndHandler.removeCallbacks(this.hideRunnable);
        Animation fadeIn = AnimationUtils.loadAnimation(getContext(), 17432576);
        fadeIn.setAnimationListener(new C04251());
        startAnimation(fadeIn);
    }

    public void hide() {
        this.fadeInEndHandler.removeCallbacks(this.hideRunnable);
        Animation fadeOut = AnimationUtils.loadAnimation(getContext(), 17432577);
        fadeOut.setAnimationListener(new C04273());
        startAnimation(fadeOut);
    }

    public void hideImmediately() {
        this.fadeInEndHandler.removeCallbacks(this.hideRunnable);
        setVisibility(4);
    }
}
