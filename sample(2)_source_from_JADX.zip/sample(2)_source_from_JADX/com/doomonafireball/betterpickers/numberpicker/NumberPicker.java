package com.doomonafireball.betterpickers.numberpicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.doomonafireball.betterpickers.C0404R;
import io.buildup.pkg20170504080645.BuildConfig;
import java.math.BigDecimal;

public class NumberPicker extends LinearLayout implements OnClickListener, OnLongClickListener {
    private static final int CLICKED_DECIMAL = 10;
    public static final int SIGN_NEGATIVE = 1;
    public static final int SIGN_POSITIVE = 0;
    private int mButtonBackgroundResId;
    protected final Context mContext;
    protected ImageButton mDelete;
    private int mDeleteDrawableSrcResId;
    protected View mDivider;
    private int mDividerColor;
    protected NumberView mEnteredNumber;
    private NumberPickerErrorTextView mError;
    protected int[] mInput;
    protected int mInputPointer;
    protected int mInputSize;
    private int mKeyBackgroundResId;
    private TextView mLabel;
    private String mLabelText;
    protected Button mLeft;
    private Integer mMaxNumber;
    private Integer mMinNumber;
    protected final Button[] mNumbers;
    protected Button mRight;
    private Button mSetButton;
    private int mSign;
    private ColorStateList mTextColor;
    private int mTheme;

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR;
        int[] mInput;
        int mInputPointer;
        int mSign;

        /* renamed from: com.doomonafireball.betterpickers.numberpicker.NumberPicker.SavedState.1 */
        static class C04221 implements Creator<SavedState> {
            C04221() {
            }

            public SavedState createFromParcel(Parcel in) {
                return new SavedState(null);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.mInputPointer = in.readInt();
            in.readIntArray(this.mInput);
            this.mSign = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.mInputPointer);
            dest.writeIntArray(this.mInput);
            dest.writeInt(this.mSign);
        }

        static {
            CREATOR = new C04221();
        }
    }

    public NumberPicker(Context context) {
        this(context, null);
    }

    public NumberPicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mInputSize = 20;
        this.mNumbers = new Button[CLICKED_DECIMAL];
        this.mInput = new int[this.mInputSize];
        this.mInputPointer = -1;
        this.mLabelText = BuildConfig.FLAVOR;
        this.mTheme = -1;
        this.mMinNumber = null;
        this.mMaxNumber = null;
        this.mContext = context;
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(getLayoutId(), this);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mKeyBackgroundResId = C0404R.drawable.key_background_dark;
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mDeleteDrawableSrcResId = C0404R.drawable.ic_backspace_dark;
        this.mDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
    }

    protected int getLayoutId() {
        return C0404R.layout.number_picker_view;
    }

    public void setTheme(int themeResId) {
        this.mTheme = themeResId;
        if (this.mTheme != -1) {
            TypedArray a = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mKeyBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpKeyBackground, this.mKeyBackgroundResId);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpDividerColor, this.mDividerColor);
            this.mDeleteDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDeleteIcon, this.mDeleteDrawableSrcResId);
        }
        restyleViews();
    }

    private void restyleViews() {
        Button[] buttonArr = this.mNumbers;
        int length = buttonArr.length;
        for (int i = 0; i < length; i += SIGN_NEGATIVE) {
            Button number = buttonArr[i];
            if (number != null) {
                number.setTextColor(this.mTextColor);
                number.setBackgroundResource(this.mKeyBackgroundResId);
            }
        }
        if (this.mDivider != null) {
            this.mDivider.setBackgroundColor(this.mDividerColor);
        }
        if (this.mLeft != null) {
            this.mLeft.setTextColor(this.mTextColor);
            this.mLeft.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mRight != null) {
            this.mRight.setTextColor(this.mTextColor);
            this.mRight.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mDelete != null) {
            this.mDelete.setBackgroundResource(this.mButtonBackgroundResId);
            this.mDelete.setImageDrawable(getResources().getDrawable(this.mDeleteDrawableSrcResId));
        }
        if (this.mEnteredNumber != null) {
            this.mEnteredNumber.setTheme(this.mTheme);
        }
        if (this.mLabel != null) {
            this.mLabel.setTextColor(this.mTextColor);
        }
    }

    protected void onFinishInflate() {
        int i;
        super.onFinishInflate();
        this.mDivider = findViewById(C0404R.id.divider);
        this.mError = (NumberPickerErrorTextView) findViewById(C0404R.id.error);
        for (i = 0; i < this.mInput.length; i += SIGN_NEGATIVE) {
            this.mInput[i] = -1;
        }
        View v1 = findViewById(C0404R.id.first);
        View v2 = findViewById(C0404R.id.second);
        View v3 = findViewById(C0404R.id.third);
        View v4 = findViewById(C0404R.id.fourth);
        this.mEnteredNumber = (NumberView) findViewById(C0404R.id.number_text);
        this.mDelete = (ImageButton) findViewById(C0404R.id.delete);
        this.mDelete.setOnClickListener(this);
        this.mDelete.setOnLongClickListener(this);
        this.mNumbers[SIGN_NEGATIVE] = (Button) v1.findViewById(C0404R.id.key_left);
        this.mNumbers[2] = (Button) v1.findViewById(C0404R.id.key_middle);
        this.mNumbers[3] = (Button) v1.findViewById(C0404R.id.key_right);
        this.mNumbers[4] = (Button) v2.findViewById(C0404R.id.key_left);
        this.mNumbers[5] = (Button) v2.findViewById(C0404R.id.key_middle);
        this.mNumbers[6] = (Button) v2.findViewById(C0404R.id.key_right);
        this.mNumbers[7] = (Button) v3.findViewById(C0404R.id.key_left);
        this.mNumbers[8] = (Button) v3.findViewById(C0404R.id.key_middle);
        this.mNumbers[9] = (Button) v3.findViewById(C0404R.id.key_right);
        this.mLeft = (Button) v4.findViewById(C0404R.id.key_left);
        this.mNumbers[0] = (Button) v4.findViewById(C0404R.id.key_middle);
        this.mRight = (Button) v4.findViewById(C0404R.id.key_right);
        setLeftRightEnabled();
        for (i = 0; i < CLICKED_DECIMAL; i += SIGN_NEGATIVE) {
            this.mNumbers[i].setOnClickListener(this);
            Button button = this.mNumbers[i];
            Object[] objArr = new Object[SIGN_NEGATIVE];
            objArr[0] = Integer.valueOf(i);
            button.setText(String.format("%d", objArr));
            this.mNumbers[i].setTag(C0404R.id.numbers_key, new Integer(i));
        }
        updateNumber();
        Resources res = this.mContext.getResources();
        this.mLeft.setText(res.getString(C0404R.string.number_picker_plus_minus));
        this.mRight.setText(res.getString(C0404R.string.number_picker_seperator));
        this.mLeft.setOnClickListener(this);
        this.mRight.setOnClickListener(this);
        this.mLabel = (TextView) findViewById(C0404R.id.label);
        this.mSign = 0;
        showLabel();
        restyleViews();
        updateKeypad();
    }

    public void setPlusMinusVisibility(int visiblity) {
        if (this.mLeft != null) {
            this.mLeft.setVisibility(visiblity);
        }
    }

    public void setDecimalVisibility(int visiblity) {
        if (this.mRight != null) {
            this.mRight.setVisibility(visiblity);
        }
    }

    public void setMin(int min) {
        this.mMinNumber = Integer.valueOf(min);
    }

    public void setMax(int max) {
        this.mMaxNumber = Integer.valueOf(max);
    }

    public void updateDeleteButton() {
        boolean enabled = this.mInputPointer != -1;
        if (this.mDelete != null) {
            this.mDelete.setEnabled(enabled);
        }
    }

    public NumberPickerErrorTextView getErrorView() {
        return this.mError;
    }

    public void onClick(View v) {
        v.performHapticFeedback(SIGN_NEGATIVE);
        this.mError.hideImmediately();
        doOnClick(v);
        updateDeleteButton();
    }

    protected void doOnClick(View v) {
        Integer val = (Integer) v.getTag(C0404R.id.numbers_key);
        if (val != null) {
            addClickedNumber(val.intValue());
        } else if (v == this.mDelete) {
            if (this.mInputPointer >= 0) {
                for (int i = 0; i < this.mInputPointer; i += SIGN_NEGATIVE) {
                    this.mInput[i] = this.mInput[i + SIGN_NEGATIVE];
                }
                this.mInput[this.mInputPointer] = -1;
                this.mInputPointer--;
            }
        } else if (v == this.mLeft) {
            onLeftClicked();
        } else if (v == this.mRight) {
            onRightClicked();
        }
        updateKeypad();
    }

    public boolean onLongClick(View v) {
        v.performHapticFeedback(0);
        this.mError.hideImmediately();
        if (v != this.mDelete) {
            return false;
        }
        this.mDelete.setPressed(false);
        reset();
        updateKeypad();
        return true;
    }

    private void updateKeypad() {
        updateLeftRightButtons();
        updateNumber();
        enableSetButton();
        updateDeleteButton();
    }

    public void setLabelText(String labelText) {
        this.mLabelText = labelText;
        showLabel();
    }

    private void showLabel() {
        if (this.mLabel != null) {
            this.mLabel.setText(this.mLabelText);
        }
    }

    public void reset() {
        for (int i = 0; i < this.mInputSize; i += SIGN_NEGATIVE) {
            this.mInput[i] = -1;
        }
        this.mInputPointer = -1;
        updateNumber();
    }

    protected void updateNumber() {
        boolean z = false;
        boolean z2 = true;
        String numberString = getEnteredNumberString().replaceAll("\\-", BuildConfig.FLAVOR);
        String[] split = numberString.split("\\.");
        NumberView numberView;
        String str;
        String str2;
        boolean containsDecimal;
        if (split.length >= 2) {
            if (split[0].equals(BuildConfig.FLAVOR)) {
                numberView = this.mEnteredNumber;
                str = "0";
                str2 = split[SIGN_NEGATIVE];
                containsDecimal = containsDecimal();
                if (this.mSign != SIGN_NEGATIVE) {
                    z2 = false;
                }
                numberView.setNumber(str, str2, containsDecimal, z2);
                return;
            }
            numberView = this.mEnteredNumber;
            str = split[0];
            str2 = split[SIGN_NEGATIVE];
            containsDecimal = containsDecimal();
            if (this.mSign != SIGN_NEGATIVE) {
                z2 = false;
            }
            numberView.setNumber(str, str2, containsDecimal, z2);
        } else if (split.length == SIGN_NEGATIVE) {
            numberView = this.mEnteredNumber;
            str = split[0];
            str2 = BuildConfig.FLAVOR;
            containsDecimal = containsDecimal();
            if (this.mSign != SIGN_NEGATIVE) {
                z2 = false;
            }
            numberView.setNumber(str, str2, containsDecimal, z2);
        } else if (numberString.equals(".")) {
            numberView = this.mEnteredNumber;
            str = "0";
            str2 = BuildConfig.FLAVOR;
            if (this.mSign == SIGN_NEGATIVE) {
                z = true;
            }
            numberView.setNumber(str, str2, true, z);
        }
    }

    protected void setLeftRightEnabled() {
        this.mLeft.setEnabled(true);
        this.mRight.setEnabled(canAddDecimal());
        if (!canAddDecimal()) {
            this.mRight.setContentDescription(null);
        }
    }

    private void addClickedNumber(int val) {
        if (this.mInputPointer >= this.mInputSize - 1) {
            return;
        }
        if (this.mInput[0] != 0 || this.mInput[SIGN_NEGATIVE] != -1 || containsDecimal() || val == CLICKED_DECIMAL) {
            for (int i = this.mInputPointer; i >= 0; i--) {
                this.mInput[i + SIGN_NEGATIVE] = this.mInput[i];
            }
            this.mInputPointer += SIGN_NEGATIVE;
            this.mInput[0] = val;
            return;
        }
        this.mInput[0] = val;
    }

    private void onLeftClicked() {
        if (this.mSign == 0) {
            this.mSign = SIGN_NEGATIVE;
        } else {
            this.mSign = 0;
        }
    }

    private void onRightClicked() {
        if (canAddDecimal()) {
            addClickedNumber(CLICKED_DECIMAL);
        }
    }

    private boolean containsDecimal() {
        boolean containsDecimal = false;
        int[] iArr = this.mInput;
        int length = iArr.length;
        for (int i = 0; i < length; i += SIGN_NEGATIVE) {
            if (iArr[i] == CLICKED_DECIMAL) {
                containsDecimal = true;
            }
        }
        return containsDecimal;
    }

    private boolean canAddDecimal() {
        return !containsDecimal();
    }

    private String getEnteredNumberString() {
        String value = BuildConfig.FLAVOR;
        for (int i = this.mInputPointer; i >= 0; i--) {
            if (this.mInput[i] != -1) {
                if (this.mInput[i] == CLICKED_DECIMAL) {
                    value = value + ".";
                } else {
                    value = value + this.mInput[i];
                }
            }
        }
        return value;
    }

    public double getEnteredNumber() {
        String value = "0";
        int i = this.mInputPointer;
        while (i >= 0 && this.mInput[i] != -1) {
            if (this.mInput[i] == CLICKED_DECIMAL) {
                value = value + ".";
            } else {
                value = value + this.mInput[i];
            }
            i--;
        }
        if (this.mSign == SIGN_NEGATIVE) {
            value = "-" + value;
        }
        return Double.parseDouble(value);
    }

    private void updateLeftRightButtons() {
        this.mRight.setEnabled(canAddDecimal());
    }

    private void enableSetButton() {
        boolean z = false;
        if (this.mSetButton != null) {
            if (this.mInputPointer == -1) {
                this.mSetButton.setEnabled(false);
                return;
            }
            Button button = this.mSetButton;
            if (this.mInputPointer >= 0) {
                z = true;
            }
            button.setEnabled(z);
        }
    }

    public void setSetButton(Button b) {
        this.mSetButton = b;
        enableSetButton();
    }

    public int getNumber() {
        return Integer.parseInt(Double.toString(getEnteredNumber()).split("\\.")[0]);
    }

    public double getDecimal() {
        return BigDecimal.valueOf(getEnteredNumber()).divideAndRemainder(BigDecimal.ONE)[SIGN_NEGATIVE].doubleValue();
    }

    public boolean getIsNegative() {
        return this.mSign == SIGN_NEGATIVE;
    }

    public Parcelable onSaveInstanceState() {
        SavedState state = new SavedState(super.onSaveInstanceState());
        state.mInput = this.mInput;
        state.mSign = this.mSign;
        state.mInputPointer = this.mInputPointer;
        return state;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState savedState = (SavedState) state;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mInputPointer = savedState.mInputPointer;
            this.mInput = savedState.mInput;
            if (this.mInput == null) {
                this.mInput = new int[this.mInputSize];
                this.mInputPointer = -1;
            }
            this.mSign = savedState.mSign;
            updateKeypad();
            return;
        }
        super.onRestoreInstanceState(state);
    }

    public void setNumber(Integer integerPart, Double decimalPart, Integer mCurrentSign) {
        if (mCurrentSign != null) {
            this.mSign = mCurrentSign.intValue();
        } else {
            this.mSign = 0;
        }
        if (decimalPart != null) {
            if (decimalPart.equals(Double.valueOf(0.0d))) {
                this.mInputPointer += SIGN_NEGATIVE;
                this.mInput[this.mInputPointer] = 0;
            } else {
                BigDecimal bigDecimal = BigDecimal.valueOf(decimalPart.doubleValue());
                readAndRightDigits(Integer.valueOf(bigDecimal.movePointRight(bigDecimal.scale()).intValue()));
            }
            this.mInputPointer += SIGN_NEGATIVE;
            this.mInput[this.mInputPointer] = CLICKED_DECIMAL;
        }
        if (integerPart != null) {
            if (integerPart.equals(Integer.valueOf(0))) {
                this.mInputPointer += SIGN_NEGATIVE;
                this.mInput[this.mInputPointer] = 0;
            } else {
                readAndRightDigits(integerPart);
            }
        }
        updateKeypad();
    }

    private void readAndRightDigits(Integer digitsToRead) {
        while (digitsToRead.intValue() > 0) {
            int d = digitsToRead.intValue() / CLICKED_DECIMAL;
            int k = digitsToRead.intValue() - (d * CLICKED_DECIMAL);
            digitsToRead = Integer.valueOf(d);
            this.mInputPointer += SIGN_NEGATIVE;
            this.mInput[this.mInputPointer] = k;
        }
    }
}
