package com.doomonafireball.betterpickers.numberpicker;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import com.doomonafireball.betterpickers.numberpicker.NumberPickerDialogFragment.NumberPickerDialogHandler;
import java.math.BigDecimal;
import java.util.Vector;

public class NumberPickerBuilder {
    private Double currentDecimalValue;
    private Integer currentNumberValue;
    private Integer currentSignValue;
    private Integer decimalVisibility;
    private String labelText;
    private Vector<NumberPickerDialogHandler> mNumberPickerDialogHandlers;
    private int mReference;
    private FragmentManager manager;
    private Integer maxNumber;
    private Integer minNumber;
    private Integer plusMinusVisibility;
    private Integer styleResId;
    private Fragment targetFragment;

    public NumberPickerBuilder() {
        this.mNumberPickerDialogHandlers = new Vector();
    }

    public NumberPickerBuilder setFragmentManager(FragmentManager manager) {
        this.manager = manager;
        return this;
    }

    public NumberPickerBuilder setStyleResId(int styleResId) {
        this.styleResId = Integer.valueOf(styleResId);
        return this;
    }

    public NumberPickerBuilder setTargetFragment(Fragment targetFragment) {
        this.targetFragment = targetFragment;
        return this;
    }

    public NumberPickerBuilder setReference(int reference) {
        this.mReference = reference;
        return this;
    }

    public NumberPickerBuilder setCurrentNumber(Integer number) {
        if (number != null) {
            if (number.intValue() >= 0) {
                this.currentSignValue = Integer.valueOf(0);
            } else {
                this.currentSignValue = Integer.valueOf(1);
                number = Integer.valueOf(number.intValue() * -1);
            }
            this.currentNumberValue = number;
            this.currentDecimalValue = null;
        }
        return this;
    }

    public NumberPickerBuilder setCurrentNumber(Double number) {
        if (number != null) {
            if (number.doubleValue() >= 0.0d) {
                this.currentSignValue = Integer.valueOf(0);
            } else {
                this.currentSignValue = Integer.valueOf(1);
                number = Double.valueOf(number.doubleValue() * -1.0d);
            }
            BigDecimal[] numberInput = BigDecimal.valueOf(number.doubleValue()).divideAndRemainder(BigDecimal.ONE);
            this.currentNumberValue = Integer.valueOf(numberInput[0].intValue());
            this.currentDecimalValue = Double.valueOf(numberInput[1].doubleValue());
        }
        return this;
    }

    public NumberPickerBuilder setMinNumber(int minNumber) {
        this.minNumber = Integer.valueOf(minNumber);
        return this;
    }

    public NumberPickerBuilder setMaxNumber(int maxNumber) {
        this.maxNumber = Integer.valueOf(maxNumber);
        return this;
    }

    public NumberPickerBuilder setPlusMinusVisibility(int plusMinusVisibility) {
        this.plusMinusVisibility = Integer.valueOf(plusMinusVisibility);
        return this;
    }

    public NumberPickerBuilder setDecimalVisibility(int decimalVisibility) {
        this.decimalVisibility = Integer.valueOf(decimalVisibility);
        return this;
    }

    public NumberPickerBuilder setLabelText(String labelText) {
        this.labelText = labelText;
        return this;
    }

    public NumberPickerBuilder addNumberPickerDialogHandler(NumberPickerDialogHandler handler) {
        this.mNumberPickerDialogHandlers.add(handler);
        return this;
    }

    public NumberPickerBuilder removeNumberPickerDialogHandler(NumberPickerDialogHandler handler) {
        this.mNumberPickerDialogHandlers.remove(handler);
        return this;
    }

    public void show() {
        if (this.manager == null || this.styleResId == null) {
            Log.e("NumberPickerBuilder", "setFragmentManager() and setStyleResId() must be called.");
            return;
        }
        FragmentTransaction ft = this.manager.beginTransaction();
        Fragment prev = this.manager.findFragmentByTag("number_dialog");
        if (prev != null) {
            ft.remove(prev);
        }
        ft.addToBackStack(null);
        NumberPickerDialogFragment fragment = NumberPickerDialogFragment.newInstance(this.mReference, this.styleResId.intValue(), this.minNumber, this.maxNumber, this.plusMinusVisibility, this.decimalVisibility, this.labelText, this.currentNumberValue, this.currentDecimalValue, this.currentSignValue);
        if (this.targetFragment != null) {
            fragment.setTargetFragment(this.targetFragment, 0);
        }
        fragment.setNumberPickerDialogHandlers(this.mNumberPickerDialogHandlers);
        fragment.show(ft, "number_dialog");
    }
}
