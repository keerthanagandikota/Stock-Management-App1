package com.doomonafireball.betterpickers.numberpicker;

import android.app.Activity;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import com.doomonafireball.betterpickers.C0404R;
import io.buildup.pkg20170504080645.BuildConfig;
import java.util.Iterator;
import java.util.Vector;

public class NumberPickerDialogFragment extends DialogFragment {
    private static final String CURRENT_DECIMAL_KEY = "NumberPickerDialogFragment_CurrentDecimalKey";
    private static final String CURRENT_NUMBER_KEY = "NumberPickerDialogFragment_CurrentNumberKey";
    private static final String CURRENT_SIGN_KEY = "NumberPickerDialogFragment_CurrentSignKey";
    private static final String DECIMAL_VISIBILITY_KEY = "NumberPickerDialogFragment_DecimalVisibilityKey";
    private static final String LABEL_TEXT_KEY = "NumberPickerDialogFragment_LabelTextKey";
    private static final String MAX_NUMBER_KEY = "NumberPickerDialogFragment_MaxNumberKey";
    private static final String MIN_NUMBER_KEY = "NumberPickerDialogFragment_MinNumberKey";
    private static final String PLUS_MINUS_VISIBILITY_KEY = "NumberPickerDialogFragment_PlusMinusVisibilityKey";
    private static final String REFERENCE_KEY = "NumberPickerDialogFragment_ReferenceKey";
    private static final String THEME_RES_ID_KEY = "NumberPickerDialogFragment_ThemeResIdKey";
    private int mButtonBackgroundResId;
    private Button mCancel;
    private Double mCurrentDecimal;
    private Integer mCurrentNumber;
    private Integer mCurrentSign;
    private int mDecimalVisibility;
    private int mDialogBackgroundResId;
    private int mDividerColor;
    private View mDividerOne;
    private View mDividerTwo;
    private String mLabelText;
    private Integer mMaxNumber;
    private Integer mMinNumber;
    private Vector<NumberPickerDialogHandler> mNumberPickerDialogHandlers;
    private NumberPicker mPicker;
    private int mPlusMinusVisibility;
    private int mReference;
    private Button mSet;
    private ColorStateList mTextColor;
    private int mTheme;

    /* renamed from: com.doomonafireball.betterpickers.numberpicker.NumberPickerDialogFragment.1 */
    class C04231 implements OnClickListener {
        C04231() {
        }

        public void onClick(View view) {
            NumberPickerDialogFragment.this.dismiss();
        }
    }

    /* renamed from: com.doomonafireball.betterpickers.numberpicker.NumberPickerDialogFragment.2 */
    class C04242 implements OnClickListener {
        C04242() {
        }

        public void onClick(View view) {
            double number = NumberPickerDialogFragment.this.mPicker.getEnteredNumber();
            if (NumberPickerDialogFragment.this.mMinNumber != null && NumberPickerDialogFragment.this.mMaxNumber != null && (number < ((double) NumberPickerDialogFragment.this.mMinNumber.intValue()) || number > ((double) NumberPickerDialogFragment.this.mMaxNumber.intValue()))) {
                NumberPickerDialogFragment.this.mPicker.getErrorView().setText(String.format(NumberPickerDialogFragment.this.getString(C0404R.string.min_max_error), new Object[]{NumberPickerDialogFragment.this.mMinNumber, NumberPickerDialogFragment.this.mMaxNumber}));
                NumberPickerDialogFragment.this.mPicker.getErrorView().show();
            } else if (NumberPickerDialogFragment.this.mMinNumber != null && number < ((double) NumberPickerDialogFragment.this.mMinNumber.intValue())) {
                NumberPickerDialogFragment.this.mPicker.getErrorView().setText(String.format(NumberPickerDialogFragment.this.getString(C0404R.string.min_error), new Object[]{NumberPickerDialogFragment.this.mMinNumber}));
                NumberPickerDialogFragment.this.mPicker.getErrorView().show();
            } else if (NumberPickerDialogFragment.this.mMaxNumber == null || number <= ((double) NumberPickerDialogFragment.this.mMaxNumber.intValue())) {
                Iterator it = NumberPickerDialogFragment.this.mNumberPickerDialogHandlers.iterator();
                while (it.hasNext()) {
                    ((NumberPickerDialogHandler) it.next()).onDialogNumberSet(NumberPickerDialogFragment.this.mReference, NumberPickerDialogFragment.this.mPicker.getNumber(), NumberPickerDialogFragment.this.mPicker.getDecimal(), NumberPickerDialogFragment.this.mPicker.getIsNegative(), number);
                }
                Activity activity = NumberPickerDialogFragment.this.getActivity();
                Fragment fragment = NumberPickerDialogFragment.this.getTargetFragment();
                if (activity instanceof NumberPickerDialogHandler) {
                    ((NumberPickerDialogHandler) activity).onDialogNumberSet(NumberPickerDialogFragment.this.mReference, NumberPickerDialogFragment.this.mPicker.getNumber(), NumberPickerDialogFragment.this.mPicker.getDecimal(), NumberPickerDialogFragment.this.mPicker.getIsNegative(), number);
                } else if (fragment instanceof NumberPickerDialogHandler) {
                    ((NumberPickerDialogHandler) fragment).onDialogNumberSet(NumberPickerDialogFragment.this.mReference, NumberPickerDialogFragment.this.mPicker.getNumber(), NumberPickerDialogFragment.this.mPicker.getDecimal(), NumberPickerDialogFragment.this.mPicker.getIsNegative(), number);
                }
                NumberPickerDialogFragment.this.dismiss();
            } else {
                NumberPickerDialogFragment.this.mPicker.getErrorView().setText(String.format(NumberPickerDialogFragment.this.getString(C0404R.string.max_error), new Object[]{NumberPickerDialogFragment.this.mMaxNumber}));
                NumberPickerDialogFragment.this.mPicker.getErrorView().show();
            }
        }
    }

    public interface NumberPickerDialogHandler {
        void onDialogNumberSet(int i, int i2, double d, boolean z, double d2);
    }

    public NumberPickerDialogFragment() {
        this.mReference = -1;
        this.mTheme = -1;
        this.mLabelText = BuildConfig.FLAVOR;
        this.mMinNumber = null;
        this.mMaxNumber = null;
        this.mCurrentNumber = null;
        this.mCurrentDecimal = null;
        this.mCurrentSign = null;
        this.mPlusMinusVisibility = 0;
        this.mDecimalVisibility = 0;
        this.mNumberPickerDialogHandlers = new Vector();
    }

    public static NumberPickerDialogFragment newInstance(int reference, int themeResId, Integer minNumber, Integer maxNumber, Integer plusMinusVisibility, Integer decimalVisibility, String labelText, Integer currentNumberValue, Double currentDecimalValue, Integer currentNumberSign) {
        NumberPickerDialogFragment frag = new NumberPickerDialogFragment();
        Bundle args = new Bundle();
        args.putInt(REFERENCE_KEY, reference);
        args.putInt(THEME_RES_ID_KEY, themeResId);
        if (minNumber != null) {
            args.putInt(MIN_NUMBER_KEY, minNumber.intValue());
        }
        if (maxNumber != null) {
            args.putInt(MAX_NUMBER_KEY, maxNumber.intValue());
        }
        if (plusMinusVisibility != null) {
            args.putInt(PLUS_MINUS_VISIBILITY_KEY, plusMinusVisibility.intValue());
        }
        if (decimalVisibility != null) {
            args.putInt(DECIMAL_VISIBILITY_KEY, decimalVisibility.intValue());
        }
        if (labelText != null) {
            args.putString(LABEL_TEXT_KEY, labelText);
        }
        if (currentNumberValue != null) {
            args.putInt(CURRENT_NUMBER_KEY, currentNumberValue.intValue());
        }
        if (currentDecimalValue != null) {
            args.putDouble(CURRENT_DECIMAL_KEY, currentDecimalValue.doubleValue());
        }
        if (currentNumberSign != null) {
            args.putInt(CURRENT_SIGN_KEY, currentNumberSign.intValue());
        }
        frag.setArguments(args);
        return frag;
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle args = getArguments();
        if (args != null && args.containsKey(REFERENCE_KEY)) {
            this.mReference = args.getInt(REFERENCE_KEY);
        }
        if (args != null && args.containsKey(THEME_RES_ID_KEY)) {
            this.mTheme = args.getInt(THEME_RES_ID_KEY);
        }
        if (args != null && args.containsKey(PLUS_MINUS_VISIBILITY_KEY)) {
            this.mPlusMinusVisibility = args.getInt(PLUS_MINUS_VISIBILITY_KEY);
        }
        if (args != null && args.containsKey(DECIMAL_VISIBILITY_KEY)) {
            this.mDecimalVisibility = args.getInt(DECIMAL_VISIBILITY_KEY);
        }
        if (args != null && args.containsKey(MIN_NUMBER_KEY)) {
            this.mMinNumber = Integer.valueOf(args.getInt(MIN_NUMBER_KEY));
        }
        if (args != null && args.containsKey(MAX_NUMBER_KEY)) {
            this.mMaxNumber = Integer.valueOf(args.getInt(MAX_NUMBER_KEY));
        }
        if (args != null && args.containsKey(LABEL_TEXT_KEY)) {
            this.mLabelText = args.getString(LABEL_TEXT_KEY);
        }
        if (args != null && args.containsKey(CURRENT_NUMBER_KEY)) {
            this.mCurrentNumber = Integer.valueOf(args.getInt(CURRENT_NUMBER_KEY));
        }
        if (args != null && args.containsKey(CURRENT_DECIMAL_KEY)) {
            this.mCurrentDecimal = Double.valueOf(args.getDouble(CURRENT_DECIMAL_KEY));
        }
        if (args != null && args.containsKey(CURRENT_SIGN_KEY)) {
            this.mCurrentSign = Integer.valueOf(args.getInt(CURRENT_SIGN_KEY));
        }
        setStyle(1, 0);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
        this.mDialogBackgroundResId = C0404R.drawable.dialog_full_holo_dark;
        if (this.mTheme != -1) {
            TypedArray a = getActivity().getApplicationContext().obtainStyledAttributes(this.mTheme, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpDividerColor, this.mDividerColor);
            this.mDialogBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDialogBackground, this.mDialogBackgroundResId);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(C0404R.layout.number_picker_dialog, null);
        this.mSet = (Button) v.findViewById(C0404R.id.set_button);
        this.mCancel = (Button) v.findViewById(C0404R.id.cancel_button);
        this.mCancel.setOnClickListener(new C04231());
        this.mPicker = (NumberPicker) v.findViewById(C0404R.id.number_picker);
        this.mPicker.setSetButton(this.mSet);
        this.mSet.setOnClickListener(new C04242());
        this.mDividerOne = v.findViewById(C0404R.id.divider_1);
        this.mDividerTwo = v.findViewById(C0404R.id.divider_2);
        this.mDividerOne.setBackgroundColor(this.mDividerColor);
        this.mDividerTwo.setBackgroundColor(this.mDividerColor);
        this.mSet.setTextColor(this.mTextColor);
        this.mSet.setBackgroundResource(this.mButtonBackgroundResId);
        this.mCancel.setTextColor(this.mTextColor);
        this.mCancel.setBackgroundResource(this.mButtonBackgroundResId);
        this.mPicker.setTheme(this.mTheme);
        getDialog().getWindow().setBackgroundDrawableResource(this.mDialogBackgroundResId);
        this.mPicker.setDecimalVisibility(this.mDecimalVisibility);
        this.mPicker.setPlusMinusVisibility(this.mPlusMinusVisibility);
        this.mPicker.setLabelText(this.mLabelText);
        if (this.mMinNumber != null) {
            this.mPicker.setMin(this.mMinNumber.intValue());
        }
        if (this.mMaxNumber != null) {
            this.mPicker.setMax(this.mMaxNumber.intValue());
        }
        this.mPicker.setNumber(this.mCurrentNumber, this.mCurrentDecimal, this.mCurrentSign);
        return v;
    }

    public void setNumberPickerDialogHandlers(Vector<NumberPickerDialogHandler> handlers) {
        this.mNumberPickerDialogHandlers = handlers;
    }
}
