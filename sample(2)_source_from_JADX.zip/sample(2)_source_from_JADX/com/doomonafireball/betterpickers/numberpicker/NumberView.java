package com.doomonafireball.betterpickers.numberpicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.widget.ZeroTopPaddingTextView;
import io.buildup.pkg20170504080645.BuildConfig;

public class NumberView extends LinearLayout {
    private final Typeface mAndroidClockMonoThin;
    private ZeroTopPaddingTextView mDecimal;
    private ZeroTopPaddingTextView mDecimalSeperator;
    private ZeroTopPaddingTextView mMinusLabel;
    private ZeroTopPaddingTextView mNumber;
    private Typeface mOriginalNumberTypeface;
    private ColorStateList mTextColor;

    public NumberView(Context context) {
        this(context, null);
    }

    public NumberView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mAndroidClockMonoThin = Typeface.createFromAsset(context.getAssets(), "fonts/AndroidClockMono-Thin.ttf");
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
    }

    public void setTheme(int themeResId) {
        if (themeResId != -1) {
            this.mTextColor = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment).getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
        }
        restyleViews();
    }

    private void restyleViews() {
        if (this.mNumber != null) {
            this.mNumber.setTextColor(this.mTextColor);
        }
        if (this.mDecimal != null) {
            this.mDecimal.setTextColor(this.mTextColor);
        }
        if (this.mDecimalSeperator != null) {
            this.mDecimalSeperator.setTextColor(this.mTextColor);
        }
        if (this.mMinusLabel != null) {
            this.mMinusLabel.setTextColor(this.mTextColor);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mNumber = (ZeroTopPaddingTextView) findViewById(C0404R.id.number);
        this.mDecimal = (ZeroTopPaddingTextView) findViewById(C0404R.id.decimal);
        this.mDecimalSeperator = (ZeroTopPaddingTextView) findViewById(C0404R.id.decimal_separator);
        this.mMinusLabel = (ZeroTopPaddingTextView) findViewById(C0404R.id.minus_label);
        if (this.mNumber != null) {
            this.mOriginalNumberTypeface = this.mNumber.getTypeface();
        }
        if (this.mNumber != null) {
            this.mNumber.setTypeface(this.mAndroidClockMonoThin);
            this.mNumber.updatePadding();
        }
        if (this.mDecimal != null) {
            this.mDecimal.setTypeface(this.mAndroidClockMonoThin);
            this.mDecimal.updatePadding();
        }
        restyleViews();
    }

    public void setNumber(String numbersDigit, String decimalDigit, boolean showDecimal, boolean isNegative) {
        int i = 0;
        this.mMinusLabel.setVisibility(isNegative ? 0 : 8);
        if (this.mNumber != null) {
            if (numbersDigit.equals(BuildConfig.FLAVOR)) {
                this.mNumber.setText("-");
                this.mNumber.setTypeface(this.mAndroidClockMonoThin);
                this.mNumber.setEnabled(false);
                this.mNumber.updatePadding();
                this.mNumber.setVisibility(0);
            } else if (showDecimal) {
                this.mNumber.setText(numbersDigit);
                this.mNumber.setTypeface(this.mOriginalNumberTypeface);
                this.mNumber.setEnabled(true);
                this.mNumber.updatePaddingForBoldDate();
                this.mNumber.setVisibility(0);
            } else {
                this.mNumber.setText(numbersDigit);
                this.mNumber.setTypeface(this.mAndroidClockMonoThin);
                this.mNumber.setEnabled(true);
                this.mNumber.updatePadding();
                this.mNumber.setVisibility(0);
            }
        }
        if (this.mDecimal != null) {
            if (decimalDigit.equals(BuildConfig.FLAVOR)) {
                this.mDecimal.setVisibility(8);
            } else {
                this.mDecimal.setText(decimalDigit);
                this.mDecimal.setTypeface(this.mAndroidClockMonoThin);
                this.mDecimal.setEnabled(true);
                this.mDecimal.updatePadding();
                this.mDecimal.setVisibility(0);
            }
        }
        if (this.mDecimalSeperator != null) {
            ZeroTopPaddingTextView zeroTopPaddingTextView = this.mDecimalSeperator;
            if (!showDecimal) {
                i = 8;
            }
            zeroTopPaddingTextView.setVisibility(i);
        }
    }
}
