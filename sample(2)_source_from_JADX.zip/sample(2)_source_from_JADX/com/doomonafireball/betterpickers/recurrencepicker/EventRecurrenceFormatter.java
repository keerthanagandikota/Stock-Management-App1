package com.doomonafireball.betterpickers.recurrencepicker;

import android.content.Context;
import android.content.res.Resources;
import android.text.format.DateUtils;
import android.text.format.Time;
import android.util.TimeFormatException;
import com.doomonafireball.betterpickers.C0404R;
import io.buildup.pkg20170504080645.BuildConfig;
import org.jraf.android.backport.switchwidget.C0678R;

public class EventRecurrenceFormatter {
    private static int[] mMonthRepeatByDayOfWeekIds;
    private static String[][] mMonthRepeatByDayOfWeekStrs;

    public static String getRepeatString(Context context, Resources r, EventRecurrence recurrence, boolean includeEndString) {
        StringBuilder sb;
        int i;
        String endString = BuildConfig.FLAVOR;
        if (includeEndString) {
            sb = new StringBuilder();
            if (recurrence.until != null) {
                try {
                    Time t = new Time();
                    t.parse(recurrence.until);
                    String dateStr = DateUtils.formatDateTime(context, t.toMillis(false), EventRecurrence.MO);
                    sb.append(r.getString(C0404R.string.endByDate, new Object[]{dateStr}));
                } catch (TimeFormatException e) {
                }
            }
            if (recurrence.count > 0) {
                i = C0404R.plurals.endByCount;
                int i2 = recurrence.count;
                Integer[] numArr = new Object[1];
                numArr[0] = Integer.valueOf(recurrence.count);
                sb.append(r.getQuantityString(i, i2, numArr));
            }
            endString = sb.toString();
        }
        i = recurrence.interval;
        int interval = r0 <= 1 ? 1 : recurrence.interval;
        switch (recurrence.freq) {
            case C0678R.styleable.Switch_asb_thumbTextPadding /*4*/:
                return r.getQuantityString(C0404R.plurals.daily, interval, new Object[]{Integer.valueOf(interval)}) + endString;
            case C0678R.styleable.Switch_asb_switchTextAppearance /*5*/:
                if (recurrence.repeatsOnEveryWeekDay()) {
                    return r.getString(C0404R.string.every_weekday) + endString;
                }
                String string;
                int dayOfWeekLength = 20;
                i = recurrence.bydayCount;
                if (r0 == 1) {
                    dayOfWeekLength = 10;
                }
                StringBuilder days = new StringBuilder();
                if (recurrence.bydayCount > 0) {
                    int count = recurrence.bydayCount - 1;
                    for (int i3 = 0; i3 < count; i3++) {
                        days.append(dayToString(recurrence.byday[i3], dayOfWeekLength));
                        days.append(", ");
                    }
                    days.append(dayToString(recurrence.byday[count], dayOfWeekLength));
                    string = days.toString();
                } else if (recurrence.startDate == null) {
                    return null;
                } else {
                    string = dayToString(EventRecurrence.timeDay2Day(recurrence.startDate.weekDay), 10);
                }
                return r.getQuantityString(C0404R.plurals.weekly, interval, new Object[]{Integer.valueOf(interval), string}) + endString;
            case C0678R.styleable.Switch_asb_switchMinWidth /*6*/:
                i = recurrence.bydayCount;
                if (r0 != 1) {
                    return r.getString(C0404R.string.monthly) + endString;
                } else if (recurrence.startDate == null) {
                    return null;
                } else {
                    int weekday = recurrence.startDate.weekDay;
                    cacheMonthRepeatStrings(r, weekday);
                    int dayNumber = (recurrence.startDate.monthDay - 1) / 7;
                    sb = new StringBuilder();
                    sb.append(r.getString(C0404R.string.monthly));
                    sb.append(" (");
                    sb.append(mMonthRepeatByDayOfWeekStrs[weekday][dayNumber]);
                    sb.append(")");
                    sb.append(endString);
                    return sb.toString();
                }
            case C0678R.styleable.Switch_asb_switchPadding /*7*/:
                return r.getString(C0404R.string.yearly_plain) + endString;
            default:
                return null;
        }
    }

    private static void cacheMonthRepeatStrings(Resources r, int weekday) {
        if (mMonthRepeatByDayOfWeekIds == null) {
            mMonthRepeatByDayOfWeekIds = new int[7];
            mMonthRepeatByDayOfWeekIds[0] = C0404R.array.repeat_by_nth_sun;
            mMonthRepeatByDayOfWeekIds[1] = C0404R.array.repeat_by_nth_mon;
            mMonthRepeatByDayOfWeekIds[2] = C0404R.array.repeat_by_nth_tues;
            mMonthRepeatByDayOfWeekIds[3] = C0404R.array.repeat_by_nth_wed;
            mMonthRepeatByDayOfWeekIds[4] = C0404R.array.repeat_by_nth_thurs;
            mMonthRepeatByDayOfWeekIds[5] = C0404R.array.repeat_by_nth_fri;
            mMonthRepeatByDayOfWeekIds[6] = C0404R.array.repeat_by_nth_sat;
        }
        if (mMonthRepeatByDayOfWeekStrs == null) {
            mMonthRepeatByDayOfWeekStrs = new String[7][];
        }
        if (mMonthRepeatByDayOfWeekStrs[weekday] == null) {
            mMonthRepeatByDayOfWeekStrs[weekday] = r.getStringArray(mMonthRepeatByDayOfWeekIds[weekday]);
        }
    }

    private static String dayToString(int day, int dayOfWeekLength) {
        return DateUtils.getDayOfWeekString(dayToUtilDay(day), dayOfWeekLength);
    }

    private static int dayToUtilDay(int day) {
        switch (day) {
            case EventRecurrence.SU /*65536*/:
                return 1;
            case EventRecurrence.MO /*131072*/:
                return 2;
            case EventRecurrence.TU /*262144*/:
                return 3;
            case EventRecurrence.WE /*524288*/:
                return 4;
            case EventRecurrence.TH /*1048576*/:
                return 5;
            case EventRecurrence.FR /*2097152*/:
                return 6;
            case EventRecurrence.SA /*4194304*/:
                return 7;
            default:
                throw new IllegalArgumentException("bad day argument: " + day);
        }
    }
}
