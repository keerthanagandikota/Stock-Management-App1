package com.doomonafireball.betterpickers.recurrencepicker;

import android.content.Context;
import java.util.Calendar;
import org.jraf.android.backport.switchwidget.C0678R;

public class Utils {
    private static final String TAG = "CalUtils";
    public static final int YEAR_MAX = 2036;
    public static final int YEAR_MIN = 1970;

    public static int getFirstDayOfWeek(Context context) {
        int startDay = Calendar.getInstance().getFirstDayOfWeek();
        if (startDay == 7) {
            return 6;
        }
        if (startDay == 2) {
            return 1;
        }
        return 0;
    }

    public static int getFirstDayOfWeekAsCalendar(Context context) {
        return convertDayOfWeekFromTimeToCalendar(getFirstDayOfWeek(context));
    }

    public static int convertDayOfWeekFromTimeToCalendar(int timeDayOfWeek) {
        switch (timeDayOfWeek) {
            case C0678R.styleable.Switch_asb_thumb /*0*/:
                return 1;
            case C0678R.styleable.Switch_asb_track /*1*/:
                return 2;
            case C0678R.styleable.Switch_asb_textOn /*2*/:
                return 3;
            case C0678R.styleable.Switch_asb_textOff /*3*/:
                return 4;
            case C0678R.styleable.Switch_asb_thumbTextPadding /*4*/:
                return 5;
            case C0678R.styleable.Switch_asb_switchTextAppearance /*5*/:
                return 6;
            case C0678R.styleable.Switch_asb_switchMinWidth /*6*/:
                return 7;
            default:
                throw new IllegalArgumentException("Argument must be between Time.SUNDAY and Time.SATURDAY");
        }
    }
}
