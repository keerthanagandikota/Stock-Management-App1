package com.doomonafireball.betterpickers.recurrencepicker;

import android.text.TextUtils;
import android.text.format.Time;
import android.util.Log;
import com.doomonafireball.betterpickers.TouchExplorationHelper;
import java.util.HashMap;
import org.jraf.android.backport.switchwidget.C0678R;

public class EventRecurrence {
    private static final boolean ALLOW_LOWER_CASE = true;
    public static final int DAILY = 4;
    public static final int FR = 2097152;
    public static final int HOURLY = 3;
    public static final int MINUTELY = 2;
    public static final int MO = 131072;
    public static final int MONTHLY = 6;
    private static final boolean ONLY_ONE_UNTIL_COUNT = false;
    private static final int PARSED_BYDAY = 128;
    private static final int PARSED_BYHOUR = 64;
    private static final int PARSED_BYMINUTE = 32;
    private static final int PARSED_BYMONTH = 2048;
    private static final int PARSED_BYMONTHDAY = 256;
    private static final int PARSED_BYSECOND = 16;
    private static final int PARSED_BYSETPOS = 4096;
    private static final int PARSED_BYWEEKNO = 1024;
    private static final int PARSED_BYYEARDAY = 512;
    private static final int PARSED_COUNT = 4;
    private static final int PARSED_FREQ = 1;
    private static final int PARSED_INTERVAL = 8;
    private static final int PARSED_UNTIL = 2;
    private static final int PARSED_WKST = 8192;
    public static final int SA = 4194304;
    public static final int SECONDLY = 1;
    public static final int SU = 65536;
    private static String TAG = null;
    public static final int TH = 1048576;
    public static final int TU = 262144;
    private static final boolean VALIDATE_UNTIL = false;
    public static final int WE = 524288;
    public static final int WEEKLY = 5;
    public static final int YEARLY = 7;
    private static final HashMap<String, Integer> sParseFreqMap;
    private static HashMap<String, PartParser> sParsePartMap;
    private static final HashMap<String, Integer> sParseWeekdayMap;
    public int[] byday;
    public int bydayCount;
    public int[] bydayNum;
    public int[] byhour;
    public int byhourCount;
    public int[] byminute;
    public int byminuteCount;
    public int[] bymonth;
    public int bymonthCount;
    public int[] bymonthday;
    public int bymonthdayCount;
    public int[] bysecond;
    public int bysecondCount;
    public int[] bysetpos;
    public int bysetposCount;
    public int[] byweekno;
    public int byweeknoCount;
    public int[] byyearday;
    public int byyeardayCount;
    public int count;
    public int freq;
    public int interval;
    public Time startDate;
    public String until;
    public int wkst;

    public static class InvalidFormatException extends RuntimeException {
        InvalidFormatException(String s) {
            super(s);
        }
    }

    static abstract class PartParser {
        public abstract int parsePart(String str, EventRecurrence eventRecurrence);

        PartParser() {
        }

        public static int parseIntRange(String str, int minVal, int maxVal, boolean allowZero) {
            try {
                if (str.charAt(0) == '+') {
                    str = str.substring(EventRecurrence.SECONDLY);
                }
                int val = Integer.parseInt(str);
                if (val >= minVal && val <= maxVal && (val != 0 || allowZero)) {
                    return val;
                }
                throw new InvalidFormatException("Integer value out of range: " + str);
            } catch (NumberFormatException e) {
                throw new InvalidFormatException("Invalid integer value: " + str);
            }
        }

        public static int[] parseNumberList(String listStr, int minVal, int maxVal, boolean allowZero) {
            if (listStr.indexOf(",") < 0) {
                int[] values = new int[EventRecurrence.SECONDLY];
                values[0] = parseIntRange(listStr, minVal, maxVal, allowZero);
                return values;
            }
            String[] valueStrs = listStr.split(",");
            int len = valueStrs.length;
            values = new int[len];
            for (int i = 0; i < len; i += EventRecurrence.SECONDLY) {
                values[i] = parseIntRange(valueStrs[i], minVal, maxVal, allowZero);
            }
            return values;
        }
    }

    private static class ParseByDay extends PartParser {
        private ParseByDay() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int bydayCount;
            int[] byday;
            int[] bydayNum;
            if (value.indexOf(",") < 0) {
                bydayCount = EventRecurrence.SECONDLY;
                byday = new int[EventRecurrence.SECONDLY];
                bydayNum = new int[EventRecurrence.SECONDLY];
                parseWday(value, byday, bydayNum, 0);
            } else {
                String[] wdays = value.split(",");
                int len = wdays.length;
                bydayCount = len;
                byday = new int[len];
                bydayNum = new int[len];
                for (int i = 0; i < len; i += EventRecurrence.SECONDLY) {
                    parseWday(wdays[i], byday, bydayNum, i);
                }
            }
            er.byday = byday;
            er.bydayNum = bydayNum;
            er.bydayCount = bydayCount;
            return EventRecurrence.PARSED_BYDAY;
        }

        private static void parseWday(String str, int[] byday, int[] bydayNum, int index) {
            String wdayStr;
            int wdayStrStart = str.length() - 2;
            if (wdayStrStart > 0) {
                bydayNum[index] = PartParser.parseIntRange(str.substring(0, wdayStrStart), -53, 53, EventRecurrence.VALIDATE_UNTIL);
                wdayStr = str.substring(wdayStrStart);
            } else {
                wdayStr = str;
            }
            Integer wday = (Integer) EventRecurrence.sParseWeekdayMap.get(wdayStr);
            if (wday == null) {
                throw new InvalidFormatException("Invalid BYDAY value: " + str);
            }
            byday[index] = wday.intValue();
        }
    }

    private static class ParseByHour extends PartParser {
        private ParseByHour() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] byhour = PartParser.parseNumberList(value, 0, 23, EventRecurrence.ALLOW_LOWER_CASE);
            er.byhour = byhour;
            er.byhourCount = byhour.length;
            return EventRecurrence.PARSED_BYHOUR;
        }
    }

    private static class ParseByMinute extends PartParser {
        private ParseByMinute() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] byminute = PartParser.parseNumberList(value, 0, 59, EventRecurrence.ALLOW_LOWER_CASE);
            er.byminute = byminute;
            er.byminuteCount = byminute.length;
            return EventRecurrence.PARSED_BYMINUTE;
        }
    }

    private static class ParseByMonth extends PartParser {
        private ParseByMonth() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] bymonth = PartParser.parseNumberList(value, EventRecurrence.SECONDLY, 12, EventRecurrence.VALIDATE_UNTIL);
            er.bymonth = bymonth;
            er.bymonthCount = bymonth.length;
            return EventRecurrence.PARSED_BYMONTH;
        }
    }

    private static class ParseByMonthDay extends PartParser {
        private ParseByMonthDay() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] bymonthday = PartParser.parseNumberList(value, -31, 31, EventRecurrence.VALIDATE_UNTIL);
            er.bymonthday = bymonthday;
            er.bymonthdayCount = bymonthday.length;
            return EventRecurrence.PARSED_BYMONTHDAY;
        }
    }

    private static class ParseBySecond extends PartParser {
        private ParseBySecond() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] bysecond = PartParser.parseNumberList(value, 0, 59, EventRecurrence.ALLOW_LOWER_CASE);
            er.bysecond = bysecond;
            er.bysecondCount = bysecond.length;
            return EventRecurrence.PARSED_BYSECOND;
        }
    }

    private static class ParseBySetPos extends PartParser {
        private ParseBySetPos() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] bysetpos = PartParser.parseNumberList(value, TouchExplorationHelper.INVALID_ID, ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED, EventRecurrence.ALLOW_LOWER_CASE);
            er.bysetpos = bysetpos;
            er.bysetposCount = bysetpos.length;
            return EventRecurrence.PARSED_BYSETPOS;
        }
    }

    private static class ParseByWeekNo extends PartParser {
        private ParseByWeekNo() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] byweekno = PartParser.parseNumberList(value, -53, 53, EventRecurrence.VALIDATE_UNTIL);
            er.byweekno = byweekno;
            er.byweeknoCount = byweekno.length;
            return EventRecurrence.PARSED_BYWEEKNO;
        }
    }

    private static class ParseByYearDay extends PartParser {
        private ParseByYearDay() {
        }

        public int parsePart(String value, EventRecurrence er) {
            int[] byyearday = PartParser.parseNumberList(value, -366, 366, EventRecurrence.VALIDATE_UNTIL);
            er.byyearday = byyearday;
            er.byyeardayCount = byyearday.length;
            return EventRecurrence.PARSED_BYYEARDAY;
        }
    }

    private static class ParseCount extends PartParser {
        private ParseCount() {
        }

        public int parsePart(String value, EventRecurrence er) {
            er.count = PartParser.parseIntRange(value, TouchExplorationHelper.INVALID_ID, ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED, EventRecurrence.ALLOW_LOWER_CASE);
            if (er.count < 0) {
                Log.d(EventRecurrence.TAG, "Invalid Count. Forcing COUNT to 1 from " + value);
                er.count = EventRecurrence.SECONDLY;
            }
            return EventRecurrence.PARSED_COUNT;
        }
    }

    private static class ParseFreq extends PartParser {
        private ParseFreq() {
        }

        public int parsePart(String value, EventRecurrence er) {
            Integer freq = (Integer) EventRecurrence.sParseFreqMap.get(value);
            if (freq == null) {
                throw new InvalidFormatException("Invalid FREQ value: " + value);
            }
            er.freq = freq.intValue();
            return EventRecurrence.SECONDLY;
        }
    }

    private static class ParseInterval extends PartParser {
        private ParseInterval() {
        }

        public int parsePart(String value, EventRecurrence er) {
            er.interval = PartParser.parseIntRange(value, TouchExplorationHelper.INVALID_ID, ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED, EventRecurrence.ALLOW_LOWER_CASE);
            if (er.interval < EventRecurrence.SECONDLY) {
                Log.d(EventRecurrence.TAG, "Invalid Interval. Forcing INTERVAL to 1 from " + value);
                er.interval = EventRecurrence.SECONDLY;
            }
            return EventRecurrence.PARSED_INTERVAL;
        }
    }

    private static class ParseUntil extends PartParser {
        private ParseUntil() {
        }

        public int parsePart(String value, EventRecurrence er) {
            er.until = value;
            return EventRecurrence.PARSED_UNTIL;
        }
    }

    private static class ParseWkst extends PartParser {
        private ParseWkst() {
        }

        public int parsePart(String value, EventRecurrence er) {
            Integer wkst = (Integer) EventRecurrence.sParseWeekdayMap.get(value);
            if (wkst == null) {
                throw new InvalidFormatException("Invalid WKST value: " + value);
            }
            er.wkst = wkst.intValue();
            return EventRecurrence.PARSED_WKST;
        }
    }

    static {
        TAG = "EventRecur";
        sParsePartMap = new HashMap();
        sParsePartMap.put("FREQ", new ParseFreq());
        sParsePartMap.put("UNTIL", new ParseUntil());
        sParsePartMap.put("COUNT", new ParseCount());
        sParsePartMap.put("INTERVAL", new ParseInterval());
        sParsePartMap.put("BYSECOND", new ParseBySecond());
        sParsePartMap.put("BYMINUTE", new ParseByMinute());
        sParsePartMap.put("BYHOUR", new ParseByHour());
        sParsePartMap.put("BYDAY", new ParseByDay());
        sParsePartMap.put("BYMONTHDAY", new ParseByMonthDay());
        sParsePartMap.put("BYYEARDAY", new ParseByYearDay());
        sParsePartMap.put("BYWEEKNO", new ParseByWeekNo());
        sParsePartMap.put("BYMONTH", new ParseByMonth());
        sParsePartMap.put("BYSETPOS", new ParseBySetPos());
        sParsePartMap.put("WKST", new ParseWkst());
        sParseFreqMap = new HashMap();
        sParseFreqMap.put("SECONDLY", Integer.valueOf(SECONDLY));
        sParseFreqMap.put("MINUTELY", Integer.valueOf(PARSED_UNTIL));
        sParseFreqMap.put("HOURLY", Integer.valueOf(HOURLY));
        sParseFreqMap.put("DAILY", Integer.valueOf(PARSED_COUNT));
        sParseFreqMap.put("WEEKLY", Integer.valueOf(WEEKLY));
        sParseFreqMap.put("MONTHLY", Integer.valueOf(MONTHLY));
        sParseFreqMap.put("YEARLY", Integer.valueOf(YEARLY));
        sParseWeekdayMap = new HashMap();
        sParseWeekdayMap.put("SU", Integer.valueOf(SU));
        sParseWeekdayMap.put("MO", Integer.valueOf(MO));
        sParseWeekdayMap.put("TU", Integer.valueOf(TU));
        sParseWeekdayMap.put("WE", Integer.valueOf(WE));
        sParseWeekdayMap.put("TH", Integer.valueOf(TH));
        sParseWeekdayMap.put("FR", Integer.valueOf(FR));
        sParseWeekdayMap.put("SA", Integer.valueOf(SA));
    }

    public void setStartDate(Time date) {
        this.startDate = date;
    }

    public static int calendarDay2Day(int day) {
        switch (day) {
            case SECONDLY /*1*/:
                return SU;
            case PARSED_UNTIL /*2*/:
                return MO;
            case HOURLY /*3*/:
                return TU;
            case PARSED_COUNT /*4*/:
                return WE;
            case WEEKLY /*5*/:
                return TH;
            case MONTHLY /*6*/:
                return FR;
            case YEARLY /*7*/:
                return SA;
            default:
                throw new RuntimeException("bad day of week: " + day);
        }
    }

    public static int timeDay2Day(int day) {
        switch (day) {
            case C0678R.styleable.Switch_asb_thumb /*0*/:
                return SU;
            case SECONDLY /*1*/:
                return MO;
            case PARSED_UNTIL /*2*/:
                return TU;
            case HOURLY /*3*/:
                return WE;
            case PARSED_COUNT /*4*/:
                return TH;
            case WEEKLY /*5*/:
                return FR;
            case MONTHLY /*6*/:
                return SA;
            default:
                throw new RuntimeException("bad day of week: " + day);
        }
    }

    public static int day2TimeDay(int day) {
        switch (day) {
            case SU /*65536*/:
                return 0;
            case MO /*131072*/:
                return SECONDLY;
            case TU /*262144*/:
                return PARSED_UNTIL;
            case WE /*524288*/:
                return HOURLY;
            case TH /*1048576*/:
                return PARSED_COUNT;
            case FR /*2097152*/:
                return WEEKLY;
            case SA /*4194304*/:
                return MONTHLY;
            default:
                throw new RuntimeException("bad day of week: " + day);
        }
    }

    public static int day2CalendarDay(int day) {
        switch (day) {
            case SU /*65536*/:
                return SECONDLY;
            case MO /*131072*/:
                return PARSED_UNTIL;
            case TU /*262144*/:
                return HOURLY;
            case WE /*524288*/:
                return PARSED_COUNT;
            case TH /*1048576*/:
                return WEEKLY;
            case FR /*2097152*/:
                return MONTHLY;
            case SA /*4194304*/:
                return YEARLY;
            default:
                throw new RuntimeException("bad day of week: " + day);
        }
    }

    private static String day2String(int day) {
        switch (day) {
            case SU /*65536*/:
                return "SU";
            case MO /*131072*/:
                return "MO";
            case TU /*262144*/:
                return "TU";
            case WE /*524288*/:
                return "WE";
            case TH /*1048576*/:
                return "TH";
            case FR /*2097152*/:
                return "FR";
            case SA /*4194304*/:
                return "SA";
            default:
                throw new IllegalArgumentException("bad day argument: " + day);
        }
    }

    private static void appendNumbers(StringBuilder s, String label, int count, int[] values) {
        if (count > 0) {
            s.append(label);
            count--;
            for (int i = 0; i < count; i += SECONDLY) {
                s.append(values[i]);
                s.append(",");
            }
            s.append(values[count]);
        }
    }

    private void appendByDay(StringBuilder s, int i) {
        int n = this.bydayNum[i];
        if (n != 0) {
            s.append(n);
        }
        s.append(day2String(this.byday[i]));
    }

    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append("FREQ=");
        switch (this.freq) {
            case SECONDLY /*1*/:
                s.append("SECONDLY");
                break;
            case PARSED_UNTIL /*2*/:
                s.append("MINUTELY");
                break;
            case HOURLY /*3*/:
                s.append("HOURLY");
                break;
            case PARSED_COUNT /*4*/:
                s.append("DAILY");
                break;
            case WEEKLY /*5*/:
                s.append("WEEKLY");
                break;
            case MONTHLY /*6*/:
                s.append("MONTHLY");
                break;
            case YEARLY /*7*/:
                s.append("YEARLY");
                break;
        }
        if (!TextUtils.isEmpty(this.until)) {
            s.append(";UNTIL=");
            s.append(this.until);
        }
        if (this.count != 0) {
            s.append(";COUNT=");
            s.append(this.count);
        }
        if (this.interval != 0) {
            s.append(";INTERVAL=");
            s.append(this.interval);
        }
        if (this.wkst != 0) {
            s.append(";WKST=");
            s.append(day2String(this.wkst));
        }
        appendNumbers(s, ";BYSECOND=", this.bysecondCount, this.bysecond);
        appendNumbers(s, ";BYMINUTE=", this.byminuteCount, this.byminute);
        appendNumbers(s, ";BYSECOND=", this.byhourCount, this.byhour);
        int count = this.bydayCount;
        if (count > 0) {
            s.append(";BYDAY=");
            count--;
            for (int i = 0; i < count; i += SECONDLY) {
                appendByDay(s, i);
                s.append(",");
            }
            appendByDay(s, count);
        }
        appendNumbers(s, ";BYMONTHDAY=", this.bymonthdayCount, this.bymonthday);
        appendNumbers(s, ";BYYEARDAY=", this.byyeardayCount, this.byyearday);
        appendNumbers(s, ";BYWEEKNO=", this.byweeknoCount, this.byweekno);
        appendNumbers(s, ";BYMONTH=", this.bymonthCount, this.bymonth);
        appendNumbers(s, ";BYSETPOS=", this.bysetposCount, this.bysetpos);
        return s.toString();
    }

    public boolean repeatsOnEveryWeekDay() {
        if (this.freq != WEEKLY) {
            return VALIDATE_UNTIL;
        }
        int count = this.bydayCount;
        if (count != WEEKLY) {
            return VALIDATE_UNTIL;
        }
        for (int i = 0; i < count; i += SECONDLY) {
            int day = this.byday[i];
            if (day == SU || day == SA) {
                return VALIDATE_UNTIL;
            }
        }
        return ALLOW_LOWER_CASE;
    }

    public boolean repeatsMonthlyOnDayCount() {
        if (this.freq == MONTHLY && this.bydayCount == SECONDLY && this.bymonthdayCount == 0 && this.bydayNum[0] > 0) {
            return ALLOW_LOWER_CASE;
        }
        return VALIDATE_UNTIL;
    }

    private static boolean arraysEqual(int[] array1, int count1, int[] array2, int count2) {
        if (count1 != count2) {
            return VALIDATE_UNTIL;
        }
        for (int i = 0; i < count1; i += SECONDLY) {
            if (array1[i] != array2[i]) {
                return VALIDATE_UNTIL;
            }
        }
        return ALLOW_LOWER_CASE;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r8) {
        /*
        r7 = this;
        r1 = 1;
        r2 = 0;
        if (r7 != r8) goto L_0x0005;
    L_0x0004:
        return r1;
    L_0x0005:
        r3 = r8 instanceof com.doomonafireball.betterpickers.recurrencepicker.EventRecurrence;
        if (r3 != 0) goto L_0x000b;
    L_0x0009:
        r1 = r2;
        goto L_0x0004;
    L_0x000b:
        r0 = r8;
        r0 = (com.doomonafireball.betterpickers.recurrencepicker.EventRecurrence) r0;
        r3 = r7.startDate;
        if (r3 != 0) goto L_0x00c5;
    L_0x0012:
        r3 = r0.startDate;
        if (r3 != 0) goto L_0x00c2;
    L_0x0016:
        r3 = r7.freq;
        r4 = r0.freq;
        if (r3 != r4) goto L_0x00c2;
    L_0x001c:
        r3 = r7.until;
        if (r3 != 0) goto L_0x00d1;
    L_0x0020:
        r3 = r0.until;
        if (r3 != 0) goto L_0x00c2;
    L_0x0024:
        r3 = r7.count;
        r4 = r0.count;
        if (r3 != r4) goto L_0x00c2;
    L_0x002a:
        r3 = r7.interval;
        r4 = r0.interval;
        if (r3 != r4) goto L_0x00c2;
    L_0x0030:
        r3 = r7.wkst;
        r4 = r0.wkst;
        if (r3 != r4) goto L_0x00c2;
    L_0x0036:
        r3 = r7.bysecond;
        r4 = r7.bysecondCount;
        r5 = r0.bysecond;
        r6 = r0.bysecondCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x0044:
        r3 = r7.byminute;
        r4 = r7.byminuteCount;
        r5 = r0.byminute;
        r6 = r0.byminuteCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x0052:
        r3 = r7.byhour;
        r4 = r7.byhourCount;
        r5 = r0.byhour;
        r6 = r0.byhourCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x0060:
        r3 = r7.byday;
        r4 = r7.bydayCount;
        r5 = r0.byday;
        r6 = r0.bydayCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x006e:
        r3 = r7.bydayNum;
        r4 = r7.bydayCount;
        r5 = r0.bydayNum;
        r6 = r0.bydayCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x007c:
        r3 = r7.bymonthday;
        r4 = r7.bymonthdayCount;
        r5 = r0.bymonthday;
        r6 = r0.bymonthdayCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x008a:
        r3 = r7.byyearday;
        r4 = r7.byyeardayCount;
        r5 = r0.byyearday;
        r6 = r0.byyeardayCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x0098:
        r3 = r7.byweekno;
        r4 = r7.byweeknoCount;
        r5 = r0.byweekno;
        r6 = r0.byweeknoCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x00a6:
        r3 = r7.bymonth;
        r4 = r7.bymonthCount;
        r5 = r0.bymonth;
        r6 = r0.bymonthCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 == 0) goto L_0x00c2;
    L_0x00b4:
        r3 = r7.bysetpos;
        r4 = r7.bysetposCount;
        r5 = r0.bysetpos;
        r6 = r0.bysetposCount;
        r3 = arraysEqual(r3, r4, r5, r6);
        if (r3 != 0) goto L_0x0004;
    L_0x00c2:
        r1 = r2;
        goto L_0x0004;
    L_0x00c5:
        r3 = r7.startDate;
        r4 = r0.startDate;
        r3 = android.text.format.Time.compare(r3, r4);
        if (r3 != 0) goto L_0x00c2;
    L_0x00cf:
        goto L_0x0016;
    L_0x00d1:
        r3 = r7.until;
        r4 = r0.until;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x00c2;
    L_0x00db:
        goto L_0x0024;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.doomonafireball.betterpickers.recurrencepicker.EventRecurrence.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        throw new UnsupportedOperationException();
    }

    private void resetFields() {
        this.until = null;
        this.bysetposCount = 0;
        this.bymonthCount = 0;
        this.byweeknoCount = 0;
        this.byyeardayCount = 0;
        this.bymonthdayCount = 0;
        this.bydayCount = 0;
        this.byhourCount = 0;
        this.byminuteCount = 0;
        this.bysecondCount = 0;
        this.interval = 0;
        this.count = 0;
        this.freq = 0;
    }

    public void parse(String recur) {
        resetFields();
        int parseFlags = 0;
        String[] parts = recur.toUpperCase().split(";");
        int length = parts.length;
        for (int i = 0; i < length; i += SECONDLY) {
            String part = parts[i];
            if (!TextUtils.isEmpty(part)) {
                int equalIndex = part.indexOf(61);
                if (equalIndex <= 0) {
                    throw new InvalidFormatException("Missing LHS in " + part);
                }
                String lhs = part.substring(0, equalIndex);
                String rhs = part.substring(equalIndex + SECONDLY);
                if (rhs.length() == 0) {
                    throw new InvalidFormatException("Missing RHS in " + part);
                }
                PartParser parser = (PartParser) sParsePartMap.get(lhs);
                if (parser != null) {
                    int flag = parser.parsePart(rhs, this);
                    if ((parseFlags & flag) != 0) {
                        throw new InvalidFormatException("Part " + lhs + " was specified twice");
                    }
                    parseFlags |= flag;
                } else if (!lhs.startsWith("X-")) {
                    throw new InvalidFormatException("Couldn't find parser for " + lhs);
                }
            }
        }
        if ((parseFlags & PARSED_WKST) == 0) {
            this.wkst = MO;
        }
        if ((parseFlags & SECONDLY) == 0) {
            throw new InvalidFormatException("Must specify a FREQ value");
        } else if ((parseFlags & MONTHLY) == MONTHLY) {
            Log.w(TAG, "Warning: rrule has both UNTIL and COUNT: " + recur);
        }
    }
}
