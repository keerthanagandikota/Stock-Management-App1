package com.doomonafireball.betterpickers.expirationpicker;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.OnClickListener;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.widget.PickerLinearLayout;
import com.doomonafireball.betterpickers.widget.UnderlinePageIndicatorPicker;
import com.doomonafireball.betterpickers.widget.ZeroTopPaddingTextView;
import io.buildup.pkg20170504080645.BuildConfig;

public class ExpirationView extends PickerLinearLayout {
    private final Typeface mAndroidClockMonoThin;
    private ZeroTopPaddingTextView mMonth;
    private Typeface mOriginalNumberTypeface;
    private ZeroTopPaddingTextView mSeperator;
    private ColorStateList mTitleColor;
    private UnderlinePageIndicatorPicker mUnderlinePageIndicatorPicker;
    private ZeroTopPaddingTextView mYearLabel;

    public ExpirationView(Context context) {
        this(context, null);
    }

    public ExpirationView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mAndroidClockMonoThin = Typeface.createFromAsset(context.getAssets(), "fonts/AndroidClockMono-Thin.ttf");
        this.mOriginalNumberTypeface = Typeface.createFromAsset(context.getAssets(), "fonts/Roboto-Bold.ttf");
        this.mTitleColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        setWillNotDraw(false);
    }

    public void setTheme(int themeResId) {
        if (themeResId != -1) {
            this.mTitleColor = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment).getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTitleColor);
        }
        restyleViews();
    }

    private void restyleViews() {
        if (this.mMonth != null) {
            this.mMonth.setTextColor(this.mTitleColor);
        }
        if (this.mYearLabel != null) {
            this.mYearLabel.setTextColor(this.mTitleColor);
        }
        if (this.mSeperator != null) {
            this.mSeperator.setTextColor(this.mTitleColor);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mMonth = (ZeroTopPaddingTextView) findViewById(C0404R.id.month);
        this.mYearLabel = (ZeroTopPaddingTextView) findViewById(C0404R.id.year_label);
        this.mSeperator = (ZeroTopPaddingTextView) findViewById(C0404R.id.expiration_seperator);
        if (this.mMonth != null) {
            this.mMonth.setTypeface(this.mAndroidClockMonoThin);
            this.mMonth.updatePadding();
        }
        if (this.mYearLabel != null) {
            this.mYearLabel.setTypeface(this.mAndroidClockMonoThin);
        }
        if (this.mSeperator != null) {
            this.mSeperator.setTypeface(this.mAndroidClockMonoThin);
        }
        restyleViews();
    }

    public void setExpiration(String month, int year) {
        if (this.mMonth != null) {
            if (month.equals(BuildConfig.FLAVOR)) {
                this.mMonth.setText("--");
                this.mMonth.setEnabled(false);
                this.mMonth.updatePadding();
            } else {
                this.mMonth.setText(month);
                this.mMonth.setEnabled(true);
                this.mMonth.updatePadding();
            }
        }
        if (this.mYearLabel == null) {
            return;
        }
        if (year <= 0) {
            this.mYearLabel.setText("----");
            this.mYearLabel.setEnabled(false);
            this.mYearLabel.updatePadding();
            return;
        }
        String yearString = Integer.toString(year);
        while (yearString.length() < 4) {
            yearString = yearString + "-";
        }
        this.mYearLabel.setText(yearString);
        this.mYearLabel.setEnabled(true);
        this.mYearLabel.updatePadding();
    }

    public void setUnderlinePage(UnderlinePageIndicatorPicker indicator) {
        this.mUnderlinePageIndicatorPicker = indicator;
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        this.mUnderlinePageIndicatorPicker.setTitleView(this);
    }

    public void setOnClick(OnClickListener mOnClickListener) {
        this.mMonth.setOnClickListener(mOnClickListener);
        this.mYearLabel.setOnClickListener(mOnClickListener);
    }

    public ZeroTopPaddingTextView getMonth() {
        return this.mMonth;
    }

    public ZeroTopPaddingTextView getYear() {
        return this.mYearLabel;
    }

    public View getViewAt(int index) {
        int[] actualIndex = new int[]{0, 2};
        if (index > actualIndex.length) {
            return null;
        }
        return getChildAt(actualIndex[index]);
    }
}
