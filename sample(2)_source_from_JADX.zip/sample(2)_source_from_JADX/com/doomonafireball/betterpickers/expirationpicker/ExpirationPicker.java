package com.doomonafireball.betterpickers.expirationpicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import com.doomonafireball.betterpickers.C0404R;
import com.doomonafireball.betterpickers.datepicker.DatePicker;
import com.doomonafireball.betterpickers.widget.UnderlinePageIndicatorPicker;
import io.buildup.pkg20170504080645.BuildConfig;
import java.util.Calendar;

public class ExpirationPicker extends LinearLayout implements OnClickListener, OnLongClickListener {
    private static final int EXPIRATION_MONTH_POSITION = 0;
    private static final int EXPIRATION_YEAR_POSITION = 1;
    private static final String KEYBOARD_MONTH = "month";
    private static final String KEYBOARD_YEAR = "year";
    private static int sMonthKeyboardPosition;
    private static int sYearKeyboardPosition;
    private int mButtonBackgroundResId;
    private int mCheckDrawableSrcResId;
    protected final Context mContext;
    private char[] mDateFormatOrder;
    protected ImageButton mDelete;
    private int mDeleteDrawableSrcResId;
    protected View mDivider;
    protected ExpirationView mEnteredExpiration;
    private int mKeyBackgroundResId;
    protected UnderlinePageIndicatorPicker mKeyboardIndicator;
    private int mKeyboardIndicatorColor;
    protected ViewPager mKeyboardPager;
    protected KeyboardPagerAdapter mKeyboardPagerAdapter;
    protected int mMinimumYear;
    protected String[] mMonthAbbreviations;
    protected int mMonthInput;
    protected final Button[] mMonths;
    private Button mSetButton;
    private ColorStateList mTextColor;
    private int mTheme;
    private int mTitleDividerColor;
    protected int[] mYearInput;
    protected int mYearInputPointer;
    protected int mYearInputSize;
    protected Button mYearLeft;
    protected final Button[] mYearNumbers;
    protected Button mYearRight;

    private class KeyboardPagerAdapter extends PagerAdapter {
        private LayoutInflater mInflater;

        public KeyboardPagerAdapter(LayoutInflater inflater) {
            this.mInflater = inflater;
        }

        public Object instantiateItem(ViewGroup collection, int position) {
            View view;
            Resources res = ExpirationPicker.this.mContext.getResources();
            View v1;
            View v2;
            View v3;
            View v4;
            int i;
            Button button;
            Object[] objArr;
            if (position == 0) {
                ExpirationPicker.sMonthKeyboardPosition = position;
                view = this.mInflater.inflate(C0404R.layout.keyboard_text, null);
                v1 = view.findViewById(C0404R.id.first);
                v2 = view.findViewById(C0404R.id.second);
                v3 = view.findViewById(C0404R.id.third);
                v4 = view.findViewById(C0404R.id.fourth);
                ExpirationPicker.this.mMonths[ExpirationPicker.EXPIRATION_MONTH_POSITION] = (Button) v1.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mMonths[ExpirationPicker.EXPIRATION_YEAR_POSITION] = (Button) v1.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mMonths[2] = (Button) v1.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mMonths[3] = (Button) v2.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mMonths[4] = (Button) v2.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mMonths[5] = (Button) v2.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mMonths[6] = (Button) v3.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mMonths[7] = (Button) v3.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mMonths[8] = (Button) v3.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mMonths[9] = (Button) v4.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mMonths[10] = (Button) v4.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mMonths[11] = (Button) v4.findViewById(C0404R.id.key_right);
                for (i = ExpirationPicker.EXPIRATION_MONTH_POSITION; i < 12; i += ExpirationPicker.EXPIRATION_YEAR_POSITION) {
                    ExpirationPicker.this.mMonths[i].setOnClickListener(ExpirationPicker.this);
                    button = ExpirationPicker.this.mMonths[i];
                    objArr = new Object[ExpirationPicker.EXPIRATION_YEAR_POSITION];
                    objArr[ExpirationPicker.EXPIRATION_MONTH_POSITION] = Integer.valueOf(i + ExpirationPicker.EXPIRATION_YEAR_POSITION);
                    button.setText(String.format("%02d", objArr));
                    ExpirationPicker.this.mMonths[i].setTextColor(ExpirationPicker.this.mTextColor);
                    ExpirationPicker.this.mMonths[i].setBackgroundResource(ExpirationPicker.this.mKeyBackgroundResId);
                    ExpirationPicker.this.mMonths[i].setTag(C0404R.id.date_keyboard, ExpirationPicker.KEYBOARD_MONTH);
                    ExpirationPicker.this.mMonths[i].setTag(C0404R.id.date_month_int, Integer.valueOf(i + ExpirationPicker.EXPIRATION_YEAR_POSITION));
                }
            } else if (position == ExpirationPicker.EXPIRATION_YEAR_POSITION) {
                ExpirationPicker.sYearKeyboardPosition = position;
                view = this.mInflater.inflate(C0404R.layout.keyboard, null);
                v1 = view.findViewById(C0404R.id.first);
                v2 = view.findViewById(C0404R.id.second);
                v3 = view.findViewById(C0404R.id.third);
                v4 = view.findViewById(C0404R.id.fourth);
                ExpirationPicker.this.mYearNumbers[ExpirationPicker.EXPIRATION_YEAR_POSITION] = (Button) v1.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mYearNumbers[2] = (Button) v1.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mYearNumbers[3] = (Button) v1.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mYearNumbers[4] = (Button) v2.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mYearNumbers[5] = (Button) v2.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mYearNumbers[6] = (Button) v2.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mYearNumbers[7] = (Button) v3.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mYearNumbers[8] = (Button) v3.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mYearNumbers[9] = (Button) v3.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mYearLeft = (Button) v4.findViewById(C0404R.id.key_left);
                ExpirationPicker.this.mYearLeft.setTextColor(ExpirationPicker.this.mTextColor);
                ExpirationPicker.this.mYearLeft.setBackgroundResource(ExpirationPicker.this.mKeyBackgroundResId);
                ExpirationPicker.this.mYearNumbers[ExpirationPicker.EXPIRATION_MONTH_POSITION] = (Button) v4.findViewById(C0404R.id.key_middle);
                ExpirationPicker.this.mYearRight = (Button) v4.findViewById(C0404R.id.key_right);
                ExpirationPicker.this.mYearRight.setTextColor(ExpirationPicker.this.mTextColor);
                ExpirationPicker.this.mYearRight.setBackgroundResource(ExpirationPicker.this.mKeyBackgroundResId);
                for (i = ExpirationPicker.EXPIRATION_MONTH_POSITION; i < 10; i += ExpirationPicker.EXPIRATION_YEAR_POSITION) {
                    ExpirationPicker.this.mYearNumbers[i].setOnClickListener(ExpirationPicker.this);
                    button = ExpirationPicker.this.mYearNumbers[i];
                    objArr = new Object[ExpirationPicker.EXPIRATION_YEAR_POSITION];
                    objArr[ExpirationPicker.EXPIRATION_MONTH_POSITION] = Integer.valueOf(i);
                    button.setText(String.format("%d", objArr));
                    ExpirationPicker.this.mYearNumbers[i].setTextColor(ExpirationPicker.this.mTextColor);
                    ExpirationPicker.this.mYearNumbers[i].setBackgroundResource(ExpirationPicker.this.mKeyBackgroundResId);
                    ExpirationPicker.this.mYearNumbers[i].setTag(C0404R.id.date_keyboard, ExpirationPicker.KEYBOARD_YEAR);
                    ExpirationPicker.this.mYearNumbers[i].setTag(C0404R.id.numbers_key, Integer.valueOf(i));
                }
            } else {
                view = new View(ExpirationPicker.this.mContext);
            }
            ExpirationPicker.this.setLeftRightEnabled();
            ExpirationPicker.this.updateExpiration();
            ExpirationPicker.this.updateKeypad();
            collection.addView(view, ExpirationPicker.EXPIRATION_MONTH_POSITION);
            return view;
        }

        public void destroyItem(ViewGroup container, int position, Object object) {
            container.removeView((View) object);
        }

        public int getCount() {
            return 2;
        }

        public boolean isViewFromObject(View view, Object o) {
            return view == o;
        }
    }

    private static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR;
        int mMonthInput;
        int[] mYearInput;
        int mYearInputPointer;

        /* renamed from: com.doomonafireball.betterpickers.expirationpicker.ExpirationPicker.SavedState.1 */
        static class C04141 implements Creator<SavedState> {
            C04141() {
            }

            public SavedState createFromParcel(Parcel in) {
                return new SavedState(null);
            }

            public SavedState[] newArray(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.mYearInputPointer = in.readInt();
            in.readIntArray(this.mYearInput);
            this.mMonthInput = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.mYearInputPointer);
            dest.writeIntArray(this.mYearInput);
            dest.writeInt(this.mMonthInput);
        }

        static {
            CREATOR = new C04141();
        }
    }

    static {
        sMonthKeyboardPosition = -1;
        sYearKeyboardPosition = -1;
    }

    public ExpirationPicker(Context context) {
        this(context, null);
    }

    public ExpirationPicker(Context context, AttributeSet attrs) {
        super(context, attrs);
        this.mYearInputSize = 4;
        this.mMonthInput = -1;
        this.mYearInput = new int[this.mYearInputSize];
        this.mYearInputPointer = -1;
        this.mMonths = new Button[12];
        this.mYearNumbers = new Button[10];
        this.mTheme = -1;
        this.mContext = context;
        this.mDateFormatOrder = DateFormat.getDateFormatOrder(this.mContext);
        this.mMonthAbbreviations = DatePicker.makeLocalizedMonthAbbreviations();
        ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(getLayoutId(), this);
        this.mTextColor = getResources().getColorStateList(C0404R.color.dialog_text_color_holo_dark);
        this.mKeyBackgroundResId = C0404R.drawable.key_background_dark;
        this.mButtonBackgroundResId = C0404R.drawable.button_background_dark;
        this.mTitleDividerColor = getResources().getColor(C0404R.color.default_divider_color_dark);
        this.mKeyboardIndicatorColor = getResources().getColor(C0404R.color.default_keyboard_indicator_color_dark);
        this.mDeleteDrawableSrcResId = C0404R.drawable.ic_backspace_dark;
        this.mCheckDrawableSrcResId = C0404R.drawable.ic_check_dark;
        this.mMinimumYear = Calendar.getInstance().get(EXPIRATION_YEAR_POSITION);
    }

    protected int getLayoutId() {
        return C0404R.layout.expiration_picker_view;
    }

    public void setTheme(int themeResId) {
        this.mTheme = themeResId;
        if (this.mTheme != -1) {
            TypedArray a = getContext().obtainStyledAttributes(themeResId, C0404R.styleable.BetterPickersDialogFragment);
            this.mTextColor = a.getColorStateList(C0404R.styleable.BetterPickersDialogFragment_bpTextColor);
            this.mKeyBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpKeyBackground, this.mKeyBackgroundResId);
            this.mButtonBackgroundResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpButtonBackground, this.mButtonBackgroundResId);
            this.mCheckDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpCheckIcon, this.mCheckDrawableSrcResId);
            this.mTitleDividerColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpTitleDividerColor, this.mTitleDividerColor);
            this.mKeyboardIndicatorColor = a.getColor(C0404R.styleable.BetterPickersDialogFragment_bpKeyboardIndicatorColor, this.mKeyboardIndicatorColor);
            this.mDeleteDrawableSrcResId = a.getResourceId(C0404R.styleable.BetterPickersDialogFragment_bpDeleteIcon, this.mDeleteDrawableSrcResId);
        }
        restyleViews();
    }

    public void setMinYear(int year) {
        this.mMinimumYear = year;
    }

    private void restyleViews() {
        int i = EXPIRATION_MONTH_POSITION;
        Button[] buttonArr = this.mMonths;
        int length = buttonArr.length;
        for (int i2 = EXPIRATION_MONTH_POSITION; i2 < length; i2 += EXPIRATION_YEAR_POSITION) {
            Button month = buttonArr[i2];
            if (month != null) {
                month.setTextColor(this.mTextColor);
                month.setBackgroundResource(this.mKeyBackgroundResId);
            }
        }
        Button[] buttonArr2 = this.mYearNumbers;
        int length2 = buttonArr2.length;
        while (i < length2) {
            Button yearNumber = buttonArr2[i];
            if (yearNumber != null) {
                yearNumber.setTextColor(this.mTextColor);
                yearNumber.setBackgroundResource(this.mKeyBackgroundResId);
            }
            i += EXPIRATION_YEAR_POSITION;
        }
        if (this.mKeyboardIndicator != null) {
            this.mKeyboardIndicator.setSelectedColor(this.mKeyboardIndicatorColor);
        }
        if (this.mDivider != null) {
            this.mDivider.setBackgroundColor(this.mTitleDividerColor);
        }
        if (this.mDelete != null) {
            this.mDelete.setBackgroundResource(this.mButtonBackgroundResId);
            this.mDelete.setImageDrawable(getResources().getDrawable(this.mDeleteDrawableSrcResId));
        }
        if (this.mYearLeft != null) {
            this.mYearLeft.setTextColor(this.mTextColor);
            this.mYearLeft.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mYearRight != null) {
            this.mYearRight.setTextColor(this.mTextColor);
            this.mYearRight.setBackgroundResource(this.mKeyBackgroundResId);
        }
        if (this.mEnteredExpiration != null) {
            this.mEnteredExpiration.setTheme(this.mTheme);
        }
    }

    protected void onFinishInflate() {
        super.onFinishInflate();
        this.mDivider = findViewById(C0404R.id.divider);
        for (int i = EXPIRATION_MONTH_POSITION; i < this.mYearInput.length; i += EXPIRATION_YEAR_POSITION) {
            this.mYearInput[i] = EXPIRATION_MONTH_POSITION;
        }
        this.mKeyboardIndicator = (UnderlinePageIndicatorPicker) findViewById(C0404R.id.keyboard_indicator);
        this.mKeyboardPager = (ViewPager) findViewById(C0404R.id.keyboard_pager);
        this.mKeyboardPager.setOffscreenPageLimit(2);
        this.mKeyboardPagerAdapter = new KeyboardPagerAdapter((LayoutInflater) this.mContext.getSystemService("layout_inflater"));
        this.mKeyboardPager.setAdapter(this.mKeyboardPagerAdapter);
        this.mKeyboardIndicator.setViewPager(this.mKeyboardPager);
        this.mKeyboardPager.setCurrentItem(EXPIRATION_MONTH_POSITION);
        this.mEnteredExpiration = (ExpirationView) findViewById(C0404R.id.date_text);
        this.mEnteredExpiration.setTheme(this.mTheme);
        this.mEnteredExpiration.setUnderlinePage(this.mKeyboardIndicator);
        this.mEnteredExpiration.setOnClick(this);
        this.mDelete = (ImageButton) findViewById(C0404R.id.delete);
        this.mDelete.setOnClickListener(this);
        this.mDelete.setOnLongClickListener(this);
        addClickedYearNumber(this.mMinimumYear / 1000);
        addClickedYearNumber((this.mMinimumYear % 1000) / 100);
        this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() - 1, true);
        setLeftRightEnabled();
        updateExpiration();
        updateKeypad();
    }

    public void updateDeleteButton() {
        boolean enabled = (this.mMonthInput == -1 && this.mYearInputPointer == -1) ? false : true;
        if (this.mDelete != null) {
            this.mDelete.setEnabled(enabled);
        }
    }

    public void onClick(View v) {
        v.performHapticFeedback(EXPIRATION_YEAR_POSITION);
        doOnClick(v);
        updateDeleteButton();
    }

    protected void doOnClick(View v) {
        if (v == this.mDelete) {
            switch (this.mKeyboardPager.getCurrentItem()) {
                case EXPIRATION_MONTH_POSITION /*0*/:
                    if (this.mMonthInput != -1) {
                        this.mMonthInput = -1;
                        break;
                    }
                    break;
                case EXPIRATION_YEAR_POSITION /*1*/:
                    if (this.mYearInputPointer < 2) {
                        if (this.mKeyboardPager.getCurrentItem() > 0) {
                            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() - 1, true);
                            break;
                        }
                    }
                    for (int i = EXPIRATION_MONTH_POSITION; i < this.mYearInputPointer; i += EXPIRATION_YEAR_POSITION) {
                        this.mYearInput[i] = this.mYearInput[i + EXPIRATION_YEAR_POSITION];
                    }
                    this.mYearInput[this.mYearInputPointer] = EXPIRATION_MONTH_POSITION;
                    this.mYearInputPointer--;
                    break;
                    break;
            }
        } else if (v == this.mEnteredExpiration.getMonth()) {
            this.mKeyboardPager.setCurrentItem(sMonthKeyboardPosition);
        } else if (v == this.mEnteredExpiration.getYear()) {
            this.mKeyboardPager.setCurrentItem(sYearKeyboardPosition);
        } else if (v.getTag(C0404R.id.date_keyboard).equals(KEYBOARD_MONTH)) {
            this.mMonthInput = ((Integer) v.getTag(C0404R.id.date_month_int)).intValue();
            if (this.mKeyboardPager.getCurrentItem() < 2) {
                this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() + EXPIRATION_YEAR_POSITION, true);
            }
        } else if (v.getTag(C0404R.id.date_keyboard).equals(KEYBOARD_YEAR)) {
            addClickedYearNumber(((Integer) v.getTag(C0404R.id.numbers_key)).intValue());
        }
        updateKeypad();
    }

    public boolean onLongClick(View v) {
        v.performHapticFeedback(EXPIRATION_MONTH_POSITION);
        if (v != this.mDelete) {
            return false;
        }
        this.mDelete.setPressed(false);
        reset();
        updateKeypad();
        return true;
    }

    private void updateKeypad() {
        updateExpiration();
        enableSetButton();
        updateDeleteButton();
        updateMonthKeys();
        updateYearKeys();
    }

    public void reset() {
        for (int i = EXPIRATION_MONTH_POSITION; i < this.mYearInputSize; i += EXPIRATION_YEAR_POSITION) {
            this.mYearInput[i] = EXPIRATION_MONTH_POSITION;
        }
        this.mYearInputPointer = -1;
        this.mMonthInput = -1;
        this.mKeyboardPager.setCurrentItem(EXPIRATION_MONTH_POSITION, true);
        updateExpiration();
    }

    @SuppressLint({"DefaultLocale"})
    protected void updateExpiration() {
        String month;
        if (this.mMonthInput < 0) {
            month = BuildConfig.FLAVOR;
        } else {
            Object[] objArr = new Object[EXPIRATION_YEAR_POSITION];
            objArr[EXPIRATION_MONTH_POSITION] = Integer.valueOf(this.mMonthInput);
            month = String.format("%02d", objArr);
        }
        this.mEnteredExpiration.setExpiration(month, getYear());
    }

    protected void setLeftRightEnabled() {
        if (this.mYearLeft != null) {
            this.mYearLeft.setEnabled(false);
        }
        if (this.mYearRight != null) {
            this.mYearRight.setEnabled(false);
        }
    }

    private void addClickedYearNumber(int val) {
        if (this.mYearInputPointer < this.mYearInputSize - 1) {
            for (int i = this.mYearInputPointer; i >= 0; i--) {
                this.mYearInput[i + EXPIRATION_YEAR_POSITION] = this.mYearInput[i];
            }
            this.mYearInputPointer += EXPIRATION_YEAR_POSITION;
            this.mYearInput[EXPIRATION_MONTH_POSITION] = val;
        }
        if (this.mKeyboardPager.getCurrentItem() < 2) {
            this.mKeyboardPager.setCurrentItem(this.mKeyboardPager.getCurrentItem() + EXPIRATION_YEAR_POSITION, true);
        }
    }

    private void updateMonthKeys() {
        for (int i = EXPIRATION_MONTH_POSITION; i < this.mMonths.length; i += EXPIRATION_YEAR_POSITION) {
            if (this.mMonths[i] != null) {
                this.mMonths[i].setEnabled(true);
            }
        }
    }

    private void updateYearKeys() {
        if (this.mYearInputPointer == EXPIRATION_YEAR_POSITION) {
            setYearMinKeyRange((this.mMinimumYear % 100) / 10);
        } else if (this.mYearInputPointer == 2) {
            setYearMinKeyRange(Math.max(EXPIRATION_MONTH_POSITION, (this.mMinimumYear % 100) - (this.mYearInput[EXPIRATION_MONTH_POSITION] * 10)));
        } else if (this.mYearInputPointer == 3) {
            setYearKeyRange(-1);
        }
    }

    private void setYearKeyRange(int maxKey) {
        int i = EXPIRATION_MONTH_POSITION;
        while (i < this.mYearNumbers.length) {
            if (this.mYearNumbers[i] != null) {
                this.mYearNumbers[i].setEnabled(i <= maxKey);
            }
            i += EXPIRATION_YEAR_POSITION;
        }
    }

    private void setYearMinKeyRange(int minKey) {
        int i = EXPIRATION_MONTH_POSITION;
        while (i < this.mYearNumbers.length) {
            if (this.mYearNumbers[i] != null) {
                this.mYearNumbers[i].setEnabled(i >= minKey);
            }
            i += EXPIRATION_YEAR_POSITION;
        }
    }

    private void enableSetButton() {
        if (this.mSetButton != null) {
            Button button = this.mSetButton;
            boolean z = getYear() >= this.mMinimumYear && getMonthOfYear() > 0;
            button.setEnabled(z);
        }
    }

    public void setSetButton(Button b) {
        this.mSetButton = b;
        enableSetButton();
    }

    public int getYear() {
        return (((this.mYearInput[3] * 1000) + (this.mYearInput[2] * 100)) + (this.mYearInput[EXPIRATION_YEAR_POSITION] * 10)) + this.mYearInput[EXPIRATION_MONTH_POSITION];
    }

    public int getMonthOfYear() {
        return this.mMonthInput;
    }

    public void setExpiration(int year, int monthOfYear) {
        if (year == 0 || year >= this.mMinimumYear) {
            this.mMonthInput = monthOfYear;
            this.mYearInput[3] = year / 1000;
            this.mYearInput[2] = (year % 1000) / 100;
            this.mYearInput[EXPIRATION_YEAR_POSITION] = (year % 100) / 10;
            this.mYearInput[EXPIRATION_MONTH_POSITION] = year % 10;
            if (year >= 1000) {
                this.mYearInputPointer = 3;
            } else if (year >= 100) {
                this.mYearInputPointer = 2;
            } else if (year >= 10) {
                this.mYearInputPointer = EXPIRATION_YEAR_POSITION;
            } else if (year > 0) {
                this.mYearInputPointer = EXPIRATION_MONTH_POSITION;
            }
            int i = EXPIRATION_MONTH_POSITION;
            while (i < this.mDateFormatOrder.length) {
                char c = this.mDateFormatOrder[i];
                if (c != 'M' || monthOfYear != -1) {
                    if (c == 'y' && year <= 0) {
                        this.mKeyboardPager.setCurrentItem(i, true);
                        break;
                    }
                    i += EXPIRATION_YEAR_POSITION;
                } else {
                    this.mKeyboardPager.setCurrentItem(i, true);
                    break;
                }
            }
            updateKeypad();
            return;
        }
        throw new IllegalArgumentException("Years past the minimum set year are not allowed. Specify " + this.mMinimumYear + " or above.");
    }

    public Parcelable onSaveInstanceState() {
        SavedState state = new SavedState(super.onSaveInstanceState());
        state.mMonthInput = this.mMonthInput;
        state.mYearInput = this.mYearInput;
        state.mYearInputPointer = this.mYearInputPointer;
        return state;
    }

    protected void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState savedState = (SavedState) state;
            super.onRestoreInstanceState(savedState.getSuperState());
            this.mYearInputPointer = savedState.mYearInputPointer;
            this.mYearInput = savedState.mYearInput;
            if (this.mYearInput == null) {
                this.mYearInput = new int[this.mYearInputSize];
                this.mYearInputPointer = -1;
            }
            this.mMonthInput = savedState.mMonthInput;
            updateKeypad();
            return;
        }
        super.onRestoreInstanceState(state);
    }
}
