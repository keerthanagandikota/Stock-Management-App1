package com.doomonafireball.betterpickers.expirationpicker;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import com.doomonafireball.betterpickers.expirationpicker.ExpirationPickerDialogFragment.ExpirationPickerDialogHandler;
import java.util.Vector;

public class ExpirationPickerBuilder {
    private Vector<ExpirationPickerDialogHandler> mExpirationPickerDialogHandlers;
    private int mReference;
    private FragmentManager manager;
    private Integer minimumYear;
    private Integer monthOfYear;
    private Integer styleResId;
    private Fragment targetFragment;
    private Integer year;

    public ExpirationPickerBuilder() {
        this.mReference = -1;
        this.mExpirationPickerDialogHandlers = new Vector();
    }

    public ExpirationPickerBuilder setFragmentManager(FragmentManager manager) {
        this.manager = manager;
        return this;
    }

    public ExpirationPickerBuilder setStyleResId(int styleResId) {
        this.styleResId = Integer.valueOf(styleResId);
        return this;
    }

    public ExpirationPickerBuilder setTargetFragment(Fragment targetFragment) {
        this.targetFragment = targetFragment;
        return this;
    }

    public ExpirationPickerBuilder setReference(int reference) {
        this.mReference = reference;
        return this;
    }

    public ExpirationPickerBuilder setMinYear(int year) {
        this.minimumYear = Integer.valueOf(year);
        return this;
    }

    public ExpirationPickerBuilder setMonthOfYear(int monthOfYear) {
        this.monthOfYear = Integer.valueOf(monthOfYear);
        return this;
    }

    public ExpirationPickerBuilder setYear(int year) {
        this.year = Integer.valueOf(year);
        return this;
    }

    public ExpirationPickerBuilder addExpirationPickerDialogHandler(ExpirationPickerDialogHandler handler) {
        this.mExpirationPickerDialogHandlers.add(handler);
        return this;
    }

    public ExpirationPickerBuilder removeExpirationPickerDialogHandler(ExpirationPickerDialogHandler handler) {
        this.mExpirationPickerDialogHandlers.remove(handler);
        return this;
    }

    public void show() {
        if (this.manager == null || this.styleResId == null) {
            Log.e("ExpirationPickerBuilder", "setFragmentManager() and setStyleResId() must be called.");
            return;
        }
        FragmentTransaction ft = this.manager.beginTransaction();
        Fragment prev = this.manager.findFragmentByTag("expiration_dialog");
        if (prev != null) {
            ft.remove(prev);
        }
        ft.addToBackStack(null);
        ExpirationPickerDialogFragment fragment = ExpirationPickerDialogFragment.newInstance(this.mReference, this.styleResId.intValue(), this.monthOfYear, this.year, this.minimumYear);
        if (this.targetFragment != null) {
            fragment.setTargetFragment(this.targetFragment, 0);
        }
        fragment.setExpirationPickerDialogHandlers(this.mExpirationPickerDialogHandlers);
        fragment.show(ft, "expiration_dialog");
    }
}
