package com.squareup.picasso;

import android.net.NetworkInfo;
import com.squareup.picasso.Picasso.Priority;
import io.buildup.pkg20170504080645.C0585R;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.jraf.android.backport.switchwidget.C0678R;

class PicassoExecutorService extends ThreadPoolExecutor {
    private static final int DEFAULT_THREAD_COUNT = 3;

    private static final class PicassoFutureTask extends FutureTask<BitmapHunter> implements Comparable<PicassoFutureTask> {
        private final BitmapHunter hunter;

        public PicassoFutureTask(BitmapHunter hunter) {
            super(hunter, null);
            this.hunter = hunter;
        }

        public int compareTo(PicassoFutureTask other) {
            Priority p1 = this.hunter.getPriority();
            Priority p2 = other.hunter.getPriority();
            return p1 == p2 ? this.hunter.sequence - other.hunter.sequence : p2.ordinal() - p1.ordinal();
        }
    }

    PicassoExecutorService() {
        super(DEFAULT_THREAD_COUNT, DEFAULT_THREAD_COUNT, 0, TimeUnit.MILLISECONDS, new PriorityBlockingQueue(), new PicassoThreadFactory());
    }

    void adjustThreadCount(NetworkInfo info) {
        if (info == null || !info.isConnectedOrConnecting()) {
            setThreadCount(DEFAULT_THREAD_COUNT);
            return;
        }
        switch (info.getType()) {
            case C0678R.styleable.Switch_asb_thumb /*0*/:
                switch (info.getSubtype()) {
                    case C0678R.styleable.Switch_asb_track /*1*/:
                    case C0678R.styleable.Switch_asb_textOn /*2*/:
                        setThreadCount(1);
                    case DEFAULT_THREAD_COUNT /*3*/:
                    case C0678R.styleable.Switch_asb_thumbTextPadding /*4*/:
                    case C0678R.styleable.Switch_asb_switchTextAppearance /*5*/:
                    case C0678R.styleable.Switch_asb_switchMinWidth /*6*/:
                    case C0585R.styleable.Toolbar_titleMargins /*12*/:
                        setThreadCount(2);
                    case C0585R.styleable.Toolbar_titleMarginStart /*13*/:
                    case C0585R.styleable.Toolbar_titleMarginEnd /*14*/:
                    case C0585R.styleable.Toolbar_titleMarginTop /*15*/:
                        setThreadCount(DEFAULT_THREAD_COUNT);
                    default:
                        setThreadCount(DEFAULT_THREAD_COUNT);
                }
            case C0678R.styleable.Switch_asb_track /*1*/:
            case C0678R.styleable.Switch_asb_switchMinWidth /*6*/:
            case C0585R.styleable.Toolbar_popupTheme /*9*/:
                setThreadCount(4);
            default:
                setThreadCount(DEFAULT_THREAD_COUNT);
        }
    }

    private void setThreadCount(int threadCount) {
        setCorePoolSize(threadCount);
        setMaximumPoolSize(threadCount);
    }

    public Future<?> submit(Runnable task) {
        PicassoFutureTask ftask = new PicassoFutureTask((BitmapHunter) task);
        execute(ftask);
        return ftask;
    }
}
