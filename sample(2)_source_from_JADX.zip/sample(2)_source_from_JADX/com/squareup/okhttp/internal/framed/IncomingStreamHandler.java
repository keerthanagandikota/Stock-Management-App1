package com.squareup.okhttp.internal.framed;

import java.io.IOException;

public interface IncomingStreamHandler {
    public static final IncomingStreamHandler REFUSE_INCOMING_STREAMS;

    /* renamed from: com.squareup.okhttp.internal.framed.IncomingStreamHandler.1 */
    static class C05581 implements IncomingStreamHandler {
        C05581() {
        }

        public void receive(FramedStream stream) throws IOException {
            stream.close(ErrorCode.REFUSED_STREAM);
        }
    }

    void receive(FramedStream framedStream) throws IOException;

    static {
        REFUSE_INCOMING_STREAMS = new C05581();
    }
}
